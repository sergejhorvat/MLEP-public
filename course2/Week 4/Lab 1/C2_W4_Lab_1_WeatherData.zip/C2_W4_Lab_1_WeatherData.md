# Ungraded Lab: Feature Engineering with Weather Data

In this 1st exercise on feature engineering with time series data, you will practice data transformation with the [`weather dataset`](https://www.bgc-jena.mpg.de/wetter/) recorded by the [Max Planck Institute for Biogeochemistry](https://www.bgc-jena.mpg.de/). 

This dataset contains 14 different features such as air temperature, atmospheric pressure, and humidity. 

These were collected every 10 minutes, beginning in 2003. For this lab, you will use only the data collected between 2009 and 2016. This section of the dataset was prepared by François Chollet for his book *Deep Learning with Python*.

The table below shows the column names, their value formats, and their description.

Index| Features      |Format             |Description
-----|---------------|-------------------|-----------------------
1    |Date Time      |01.01.2009 00:10:00|Date-time reference
2    |p (mbar)       |996.52             |The pascal SI derived unit of pressure used to quantify internal pressure. Meteorological reports typically state atmospheric pressure in millibars.
3    |T (degC)       |-8.02              |Temperature in Celsius
4    |Tpot (K)       |265.4              |Temperature in Kelvin
5    |Tdew (degC)    |-8.9               |Temperature in Celsius relative to humidity. Dew Point is a measure of the absolute amount of water in the air, the DP is the temperature at which the air cannot hold all the moisture in it and water condenses.
6    |rh (%)         |93.3               |Relative Humidity is a measure of how saturated the air is with water vapor, the %RH determines the amount of water contained within collection objects.
7    |VPmax (mbar)   |3.33               |Saturation vapor pressure
8    |VPact (mbar)   |3.11               |Vapor pressure
9    |VPdef (mbar)   |0.22               |Vapor pressure deficit
10   |sh (g/kg)      |1.94               |Specific humidity
11   |H2OC (mmol/mol)|3.12               |Water vapor concentration
12   |rho (g/m ** 3) |1307.75            |Airtight
13   |wv (m/s)       |1.03               |Wind speed
14   |max. wv (m/s)  |1.75               |Maximum wind speed
15   |wd (deg)       |152.3              |Wind direction in degrees

You will perform data preprocessing so that the features can be used to train an LSTM using TensorFlow and Keras downstream. You will not be asked to train a model as the focus is on feature preprocessing. However in later courses of this specialization, you will get to learn more about time series forecasting, at which point you can retreive your saved tfrecords and train a neural net model for weather forecasting.

Upon completion, you will have

* Explored and visualized the weather time series dataset and declared its schema
* Transformed the data for modeling using TF Transform
* Prepared Training Dataset Windows from `TFTransformOutput`

## Imports


```python
import os
import pprint
import tempfile
import urllib
import pandas as pd
import numpy as np

import absl
import tensorflow as tf
tf.get_logger().propagate = False
pp = pprint.PrettyPrinter()

import tfx
from tfx.components import CsvExampleGen
from tfx.components import ExampleValidator
from tfx.components import SchemaGen
from tfx.components import StatisticsGen
from tfx.orchestration.experimental.interactive.interactive_context import InteractiveContext
from tfx.types import Channel
from tfx.utils.dsl_utils import external_input
from tfx.components.transform.component import Transform

from google.protobuf.json_format import MessageToDict

print(f'TFX version: {tfx.__version__}')
print(f'Tensorflow version: {tf.__version__}')
```

    TFX version: 0.24.0
    Tensorflow version: 2.4.1


## Setup dataset and directories

Let's then download the dataset and setup your pipeline directory.


```python
# Create pipeline directory
!mkdir pipeline

# Create data directory
!mkdir -p data/climate

# Location of the pipeline metadata store
_pipeline_root = './pipeline/'

# Directory of the raw data files
_data_root = './data/climate'

# Path to the raw training data
_data_filepath = os.path.join(_data_root, 'jena_climate_2009_2016.csv')
```


```python
# Download the dataset.
!wget -nc https://raw.githubusercontent.com/https-deeplearning-ai/MLEP-public/main/course2/week4-ungraded-lab/data/jena_climate_2009_2016.csv -P {_data_root}
```

    --2021-07-14 09:28:58--  https://raw.githubusercontent.com/https-deeplearning-ai/MLEP-public/main/course2/week4-ungraded-lab/data/jena_climate_2009_2016.csv
    Resolving proxy-coursera-apps.org (proxy-coursera-apps.org)... 10.0.0.170
    Connecting to proxy-coursera-apps.org (proxy-coursera-apps.org)|10.0.0.170|:3128... connected.
    Proxy request sent, awaiting response... 200 OK
    Length: 43164220 (41M) [text/plain]
    Saving to: ‘./data/climate/jena_climate_2009_2016.csv’
    
    jena_climate_2009_2 100%[===================>]  41.16M   223MB/s    in 0.2s    
    
    2021-07-14 09:28:59 (223 MB/s) - ‘./data/climate/jena_climate_2009_2016.csv’ saved [43164220/43164220]
    


Let's preview the first few rows. You will notice that almost all the features are numeric.


```python
# Preview the dataset
!head {_data_filepath}
```

    "Date Time","p (mbar)","T (degC)","Tpot (K)","Tdew (degC)","rh (%)","VPmax (mbar)","VPact (mbar)","VPdef (mbar)","sh (g/kg)","H2OC (mmol/mol)","rho (g/m**3)","wv (m/s)","max. wv (m/s)","wd (deg)"
    01.01.2009 00:10:00,996.52,-8.02,265.40,-8.90,93.30,3.33,3.11,0.22,1.94,3.12,1307.75,1.03,1.75,152.30
    01.01.2009 00:20:00,996.57,-8.41,265.01,-9.28,93.40,3.23,3.02,0.21,1.89,3.03,1309.80,0.72,1.50,136.10
    01.01.2009 00:30:00,996.53,-8.51,264.91,-9.31,93.90,3.21,3.01,0.20,1.88,3.02,1310.24,0.19,0.63,171.60
    01.01.2009 00:40:00,996.51,-8.31,265.12,-9.07,94.20,3.26,3.07,0.19,1.92,3.08,1309.19,0.34,0.50,198.00
    01.01.2009 00:50:00,996.51,-8.27,265.15,-9.04,94.10,3.27,3.08,0.19,1.92,3.09,1309.00,0.32,0.63,214.30
    01.01.2009 01:00:00,996.50,-8.05,265.38,-8.78,94.40,3.33,3.14,0.19,1.96,3.15,1307.86,0.21,0.63,192.70
    01.01.2009 01:10:00,996.50,-7.62,265.81,-8.30,94.80,3.44,3.26,0.18,2.04,3.27,1305.68,0.18,0.63,166.50
    01.01.2009 01:20:00,996.50,-7.62,265.81,-8.36,94.40,3.44,3.25,0.19,2.03,3.26,1305.69,0.19,0.50,118.60
    01.01.2009 01:30:00,996.50,-7.91,265.52,-8.73,93.80,3.36,3.15,0.21,1.97,3.16,1307.17,0.28,0.75,188.50


You will also notice that there are quotes in the column names. It is up to you if you should keep it but for this exercise, it would be better to remove it so we don't have to factor it in when we're declaring the keys in the Transform module. Let's do that below.


```python
# Load the CSV into a dataframe
df = pd.read_csv(f'{_data_filepath}')

# Remove the quotes in the column names
df.columns=df.columns.str.replace('"','')

# Save the changes
df.to_csv(f'{_data_filepath}', index=False)

# See the result
!head {_data_filepath}
```

    Date Time,p (mbar),T (degC),Tpot (K),Tdew (degC),rh (%),VPmax (mbar),VPact (mbar),VPdef (mbar),sh (g/kg),H2OC (mmol/mol),rho (g/m**3),wv (m/s),max. wv (m/s),wd (deg)
    01.01.2009 00:10:00,996.52,-8.02,265.4,-8.9,93.3,3.33,3.11,0.22,1.94,3.12,1307.75,1.03,1.75,152.3
    01.01.2009 00:20:00,996.57,-8.41,265.01,-9.28,93.4,3.23,3.02,0.21,1.89,3.03,1309.8,0.72,1.5,136.1
    01.01.2009 00:30:00,996.53,-8.51,264.91,-9.31,93.9,3.21,3.01,0.2,1.88,3.02,1310.24,0.19,0.63,171.6
    01.01.2009 00:40:00,996.51,-8.31,265.12,-9.07,94.2,3.26,3.07,0.19,1.92,3.08,1309.19,0.34,0.5,198.0
    01.01.2009 00:50:00,996.51,-8.27,265.15,-9.04,94.1,3.27,3.08,0.19,1.92,3.09,1309.0,0.32,0.63,214.3
    01.01.2009 01:00:00,996.5,-8.05,265.38,-8.78,94.4,3.33,3.14,0.19,1.96,3.15,1307.86,0.21,0.63,192.7
    01.01.2009 01:10:00,996.5,-7.62,265.81,-8.3,94.8,3.44,3.26,0.18,2.04,3.27,1305.68,0.18,0.63,166.5
    01.01.2009 01:20:00,996.5,-7.62,265.81,-8.36,94.4,3.44,3.25,0.19,2.03,3.26,1305.69,0.19,0.5,118.6
    01.01.2009 01:30:00,996.5,-7.91,265.52,-8.73,93.8,3.36,3.15,0.21,1.97,3.16,1307.17,0.28,0.75,188.5


## Data Pipeline

Since you already know how to run TFX pipelines, we will just quickly go over the first few components. The main difference we need to discuss will be in the Transform part where you need to transform certain columns into usable signals.

## Create the InteractiveContext

As usual, you need to initialize the `InteractiveContext` so you can run the components in the notebook.


```python
# Initialize the InteractiveContext
context = InteractiveContext(pipeline_root=_pipeline_root)
```

    WARNING:absl:InteractiveContext metadata_connection_config not provided: using SQLite ML Metadata database at ./pipeline/metadata.sqlite.


## ExampleGen

You will then ingest the data from the dataframe you defined earlier. As with earlier labs, you may want to remove notebook checkpoints in case you get an error about different headers.


```python
# Run CSV ExampleGen
example_gen = CsvExampleGen(input_base=_data_root)  
context.run(example_gen)
```






<style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object expanded"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExecutionResult</span><span class="deemphasize"> at 0x7f27f04d1940</span></div><table class="attr-table"><tr><td class="attr-name">.execution_id</td><td class = "attrvalue">1</td></tr><tr><td class="attr-name">.component</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">CsvExampleGen</span><span class="deemphasize"> at 0x7f27f049a460</span></div><table class="attr-table"><tr><td class="attr-name">.inputs</td><td class = "attrvalue">{}</td></tr><tr><td class="attr-name">.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.exec_properties</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['input_base']</td><td class = "attrvalue">./data/climate</td></tr><tr><td class="attr-name">['input_config']</td><td class = "attrvalue">{
  &quot;splits&quot;: [
    {
      &quot;name&quot;: &quot;single_split&quot;,
      &quot;pattern&quot;: &quot;*&quot;
    }
  ]
}</td></tr><tr><td class="attr-name">['output_config']</td><td class = "attrvalue">{
  &quot;split_config&quot;: {
    &quot;splits&quot;: [
      {
        &quot;hash_buckets&quot;: 2,
        &quot;name&quot;: &quot;train&quot;
      },
      {
        &quot;hash_buckets&quot;: 1,
        &quot;name&quot;: &quot;eval&quot;
      }
    ]
  }
}</td></tr><tr><td class="attr-name">['output_data_format']</td><td class = "attrvalue">6</td></tr><tr><td class="attr-name">['custom_config']</td><td class = "attrvalue">None</td></tr><tr><td class="attr-name">['span']</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">['version']</td><td class = "attrvalue">None</td></tr><tr><td class="attr-name">['input_fingerprint']</td><td class = "attrvalue">split:single_split,num_files:1,total_bytes:41987089,xor_checksum:1626254947,sum_checksum:1626254947</td></tr><tr><td class="attr-name">['_beam_pipeline_args']</td><td class = "attrvalue">[]</td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">.component.inputs</td><td class = "attrvalue">{}</td></tr><tr><td class="attr-name">.component.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr></table></div>



## StatisticsGen

Next, you will generate the statistics that will be used by the next components. Feel free to also explore it when you run `context.show()`.


```python
# Instantiate StatisticsGen with the ExampleGen ingested dataset
statistics_gen = StatisticsGen(
    examples=example_gen.outputs['examples'])

# Execute the component
context.run(statistics_gen)
```




<style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object expanded"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExecutionResult</span><span class="deemphasize"> at 0x7f27f049a0a0</span></div><table class="attr-table"><tr><td class="attr-name">.execution_id</td><td class = "attrvalue">2</td></tr><tr><td class="attr-name">.component</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">StatisticsGen</span><span class="deemphasize"> at 0x7f27d7807880</span></div><table class="attr-table"><tr><td class="attr-name">.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.exec_properties</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['stats_options_json']</td><td class = "attrvalue">None</td></tr><tr><td class="attr-name">['exclude_splits']</td><td class = "attrvalue">[]</td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">.component.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.component.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr></table></div>




```python
# Show the output statistics
context.show(statistics_gen.outputs['statistics'])
```


<b>Artifact at ./pipeline/StatisticsGen/statistics/2</b><br/><br/>



<div><b>'train' split:</b></div><br/>


    WARNING:tensorflow:From /opt/conda/lib/python3.8/site-packages/tensorflow_data_validation/utils/stats_util.py:229: tf_record_iterator (from tensorflow.python.lib.io.tf_record) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use eager execution and: 
    `tf.data.TFRecordDataset(path)`



<iframe id='facets-iframe' width="100%" height="500px"></iframe>
        <script>
        facets_iframe = document.getElementById('facets-iframe');
        facets_html = '<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"><\/script><link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/master/facets-dist/facets-jupyter.html"><facets-overview proto-input="CsiYAwoObGhzX3N0YXRpc3RpY3MQzIgRGseuAhACIrSuAgq4AgjMiBEYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQCABQMyIERCChxEaHhITMjEuMDMuMjAxNCAxNzoyMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE2OjMwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTY6MTA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxNjowMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE1OjMwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTU6MjA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxNTowMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE0OjMwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTQ6MTA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMzoyMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDEzOjEwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTM6MDA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMjo1MDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDEyOjQwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTI6MzA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMjoxMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDEyOjAwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTE6MjA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMToxMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDExOjAwOjAwGQAAAAAAAABAJQAAmEEq7KYCCh4iEzIxLjAzLjIwMTQgMTc6MjA6MDApAAAAAAAAAEAKIggBEAEiEzIxLjAzLjIwMTQgMTY6MzA6MDApAAAAAAAAAEAKIggCEAIiEzIxLjAzLjIwMTQgMTY6MTA6MDApAAAAAAAAAEAKIggDEAMiEzIxLjAzLjIwMTQgMTY6MDA6MDApAAAAAAAAAEAKIggEEAQiEzIxLjAzLjIwMTQgMTU6MzA6MDApAAAAAAAAAEAKIggFEAUiEzIxLjAzLjIwMTQgMTU6MjA6MDApAAAAAAAAAEAKIggGEAYiEzIxLjAzLjIwMTQgMTU6MDA6MDApAAAAAAAAAEAKIggHEAciEzIxLjAzLjIwMTQgMTQ6MzA6MDApAAAAAAAAAEAKIggIEAgiEzIxLjAzLjIwMTQgMTQ6MTA6MDApAAAAAAAAAEAKIggJEAkiEzIxLjAzLjIwMTQgMTM6MjA6MDApAAAAAAAAAEAKIggKEAoiEzIxLjAzLjIwMTQgMTM6MTA6MDApAAAAAAAAAEAKIggLEAsiEzIxLjAzLjIwMTQgMTM6MDA6MDApAAAAAAAAAEAKIggMEAwiEzIxLjAzLjIwMTQgMTI6NTA6MDApAAAAAAAAAEAKIggNEA0iEzIxLjAzLjIwMTQgMTI6NDA6MDApAAAAAAAAAEAKIggOEA4iEzIxLjAzLjIwMTQgMTI6MzA6MDApAAAAAAAAAEAKIggPEA8iEzIxLjAzLjIwMTQgMTI6MTA6MDApAAAAAAAAAEAKIggQEBAiEzIxLjAzLjIwMTQgMTI6MDA6MDApAAAAAAAAAEAKIggREBEiEzIxLjAzLjIwMTQgMTE6MjA6MDApAAAAAAAAAEAKIggSEBIiEzIxLjAzLjIwMTQgMTE6MTA6MDApAAAAAAAAAEAKIggTEBMiEzIxLjAzLjIwMTQgMTE6MDA6MDApAAAAAAAAAEAKIggUEBQiEzIxLjAzLjIwMTQgMTA6MzA6MDApAAAAAAAAAEAKIggVEBUiEzIxLjAzLjIwMTQgMTA6MjA6MDApAAAAAAAAAEAKIggWEBYiEzIxLjAzLjIwMTQgMDk6NDA6MDApAAAAAAAAAEAKIggXEBciEzIxLjAzLjIwMTQgMDk6MzA6MDApAAAAAAAAAEAKIggYEBgiEzIxLjAzLjIwMTQgMDk6MjA6MDApAAAAAAAAAEAKIggZEBkiEzIxLjAzLjIwMTQgMDk6MTA6MDApAAAAAAAAAEAKIggaEBoiEzIxLjAzLjIwMTQgMDk6MDA6MDApAAAAAAAAAEAKIggbEBsiEzIxLjAzLjIwMTQgMDg6NDA6MDApAAAAAAAAAEAKIggcEBwiEzIxLjAzLjIwMTQgMDg6MzA6MDApAAAAAAAAAEAKIggdEB0iEzIxLjAzLjIwMTQgMDg6MjA6MDApAAAAAAAAAEAKIggeEB4iEzIxLjAzLjIwMTQgMDg6MDA6MDApAAAAAAAAAEAKIggfEB8iEzIxLjAzLjIwMTQgMDc6NTA6MDApAAAAAAAAAEAKIgggECAiEzIxLjAzLjIwMTQgMDc6MzA6MDApAAAAAAAAAEAKIgghECEiEzIxLjAzLjIwMTQgMDc6MjA6MDApAAAAAAAAAEAKIggiECIiEzIxLjAzLjIwMTQgMDc6MTA6MDApAAAAAAAAAEAKIggjECMiEzIxLjAzLjIwMTQgMDY6NDA6MDApAAAAAAAAAEAKIggkECQiEzIxLjAzLjIwMTQgMDY6MzA6MDApAAAAAAAAAEAKIgglECUiEzIxLjAzLjIwMTQgMDY6MTA6MDApAAAAAAAAAEAKIggmECYiEzIxLjAzLjIwMTQgMDY6MDA6MDApAAAAAAAAAEAKIggnECciEzIxLjAzLjIwMTQgMDU6NDA6MDApAAAAAAAAAEAKIggoECgiEzIxLjAzLjIwMTQgMDQ6NDA6MDApAAAAAAAAAEAKIggpECkiEzIxLjAzLjIwMTQgMDQ6MjA6MDApAAAAAAAAAEAKIggqECoiEzIxLjAzLjIwMTQgMDQ6MTA6MDApAAAAAAAAAEAKIggrECsiEzIxLjAzLjIwMTQgMDQ6MDA6MDApAAAAAAAAAEAKIggsECwiEzIxLjAzLjIwMTQgMDM6NTA6MDApAAAAAAAAAEAKIggtEC0iEzIxLjAzLjIwMTQgMDM6NDA6MDApAAAAAAAAAEAKIgguEC4iEzIxLjAzLjIwMTQgMDM6MTA6MDApAAAAAAAAAEAKIggvEC8iEzIxLjAzLjIwMTQgMDI6NDA6MDApAAAAAAAAAEAKIggwEDAiEzIxLjAzLjIwMTQgMDI6MzA6MDApAAAAAAAAAEAKIggxEDEiEzIxLjAzLjIwMTQgMDI6MjA6MDApAAAAAAAAAEAKIggyEDIiEzIxLjAzLjIwMTQgMDI6MDA6MDApAAAAAAAAAEAKIggzEDMiEzIxLjAzLjIwMTQgMDE6MzA6MDApAAAAAAAAAEAKIgg0EDQiEzIxLjAzLjIwMTQgMDE6MTA6MDApAAAAAAAAAEAKIgg1EDUiEzIxLjAzLjIwMTQgMDE6MDA6MDApAAAAAAAAAEAKIgg2EDYiEzIxLjAzLjIwMTQgMDA6NTA6MDApAAAAAAAAAEAKIgg3EDciEzIxLjAzLjIwMTQgMDA6NDA6MDApAAAAAAAAAEAKIgg4EDgiEzIxLjAzLjIwMTQgMDA6MzA6MDApAAAAAAAAAEAKIgg5EDkiEzIxLjAzLjIwMTQgMDA6MjA6MDApAAAAAAAAAEAKIgg6EDoiEzIxLjAzLjIwMTQgMDA6MTA6MDApAAAAAAAAAEAKIgg7EDsiEzIxLjAzLjIwMTQgMDA6MDA6MDApAAAAAAAAAEAKIgg8EDwiEzIwLjAzLjIwMTQgMjM6NTA6MDApAAAAAAAAAEAKIgg9ED0iEzIwLjAzLjIwMTQgMjM6MjA6MDApAAAAAAAAAEAKIgg+ED4iEzIwLjAzLjIwMTQgMjM6MDA6MDApAAAAAAAAAEAKIgg/ED8iEzIwLjAzLjIwMTQgMjI6NTA6MDApAAAAAAAAAEAKIghAEEAiEzIwLjAzLjIwMTQgMjI6NDA6MDApAAAAAAAAAEAKIghBEEEiEzIwLjAzLjIwMTQgMjI6MjA6MDApAAAAAAAAAEAKIghCEEIiEzIwLjAzLjIwMTQgMjE6NTA6MDApAAAAAAAAAEAKIghDEEMiEzIwLjAzLjIwMTQgMjE6MDA6MDApAAAAAAAAAEAKIghEEEQiEzIwLjAzLjIwMTQgMjA6NDA6MDApAAAAAAAAAEAKIghFEEUiEzIwLjAzLjIwMTQgMjA6MzA6MDApAAAAAAAAAEAKIghGEEYiEzIwLjAzLjIwMTQgMjA6MTA6MDApAAAAAAAAAEAKIghHEEciEzIwLjAzLjIwMTQgMjA6MDA6MDApAAAAAAAAAEAKIghIEEgiEzIwLjAzLjIwMTQgMTk6MjA6MDApAAAAAAAAAEAKIghJEEkiEzIwLjAzLjIwMTQgMTk6MDA6MDApAAAAAAAAAEAKIghKEEoiEzIwLjAzLjIwMTQgMTg6NTA6MDApAAAAAAAAAEAKIghLEEsiEzIwLjAzLjIwMTQgMTg6MTA6MDApAAAAAAAAAEAKIghMEEwiEzIwLjAzLjIwMTQgMTg6MDA6MDApAAAAAAAAAEAKIghNEE0iEzIwLjAzLjIwMTQgMTc6NDA6MDApAAAAAAAAAEAKIghOEE4iEzIwLjAzLjIwMTQgMTc6MzA6MDApAAAAAAAAAEAKIghPEE8iEzIwLjAzLjIwMTQgMTc6MjA6MDApAAAAAAAAAEAKIghQEFAiEzIwLjAzLjIwMTQgMTY6NTA6MDApAAAAAAAAAEAKIghREFEiEzIwLjAzLjIwMTQgMTY6MzA6MDApAAAAAAAAAEAKIghSEFIiEzIwLjAzLjIwMTQgMTY6MjA6MDApAAAAAAAAAEAKIghTEFMiEzIwLjAzLjIwMTQgMTY6MTA6MDApAAAAAAAAAEAKIghUEFQiEzIwLjAzLjIwMTQgMTY6MDA6MDApAAAAAAAAAEAKIghVEFUiEzIwLjAzLjIwMTQgMTU6NTA6MDApAAAAAAAAAEAKIghWEFYiEzIwLjAzLjIwMTQgMTU6NDA6MDApAAAAAAAAAEAKIghXEFciEzIwLjAzLjIwMTQgMTU6MzA6MDApAAAAAAAAAEAKIghYEFgiEzIwLjAzLjIwMTQgMTU6MjA6MDApAAAAAAAAAEAKIghZEFkiEzIwLjAzLjIwMTQgMTQ6NTA6MDApAAAAAAAAAEAKIghaEFoiEzIwLjAzLjIwMTQgMTQ6MzA6MDApAAAAAAAAAEAKIghbEFsiEzIwLjAzLjIwMTQgMTQ6MjA6MDApAAAAAAAAAEAKIghcEFwiEzIwLjAzLjIwMTQgMTQ6MTA6MDApAAAAAAAAAEAKIghdEF0iEzIwLjAzLjIwMTQgMTQ6MDA6MDApAAAAAAAAAEAKIgheEF4iEzIwLjAzLjIwMTQgMTM6NTA6MDApAAAAAAAAAEAKIghfEF8iEzIwLjAzLjIwMTQgMTM6NDA6MDApAAAAAAAAAEAKIghgEGAiEzIwLjAzLjIwMTQgMTM6MTA6MDApAAAAAAAAAEAKIghhEGEiEzIwLjAzLjIwMTQgMTI6NTA6MDApAAAAAAAAAEAKIghiEGIiEzIwLjAzLjIwMTQgMTI6NDA6MDApAAAAAAAAAEAKIghjEGMiEzIwLjAzLjIwMTQgMTI6MzA6MDApAAAAAAAAAEAKIghkEGQiEzIwLjAzLjIwMTQgMTI6MTA6MDApAAAAAAAAAEAKIghlEGUiEzIwLjAzLjIwMTQgMTI6MDA6MDApAAAAAAAAAEAKIghmEGYiEzIwLjAzLjIwMTQgMTE6NTA6MDApAAAAAAAAAEAKIghnEGciEzIwLjAzLjIwMTQgMTE6MzA6MDApAAAAAAAAAEAKIghoEGgiEzIwLjAzLjIwMTQgMTE6MTA6MDApAAAAAAAAAEAKIghpEGkiEzIwLjAzLjIwMTQgMTE6MDA6MDApAAAAAAAAAEAKIghqEGoiEzAyLjA3LjIwMTAgMDA6MDA6MDApAAAAAAAAAEAKIghrEGsiEzAxLjA3LjIwMTAgMjM6NTA6MDApAAAAAAAAAEAKIghsEGwiEzAxLjA3LjIwMTAgMjM6NDA6MDApAAAAAAAAAEAKIghtEG0iEzAxLjA3LjIwMTAgMjM6MzA6MDApAAAAAAAAAEAKIghuEG4iEzAxLjA3LjIwMTAgMjM6MjA6MDApAAAAAAAAAEAKIghvEG8iEzAxLjA3LjIwMTAgMjI6NTA6MDApAAAAAAAAAEAKIghwEHAiEzAxLjA3LjIwMTAgMjI6MjA6MDApAAAAAAAAAEAKIghxEHEiEzAxLjA3LjIwMTAgMjI6MTA6MDApAAAAAAAAAEAKIghyEHIiEzAxLjA3LjIwMTAgMjE6NTA6MDApAAAAAAAAAEAKIghzEHMiEzAxLjA3LjIwMTAgMjE6MzA6MDApAAAAAAAAAEAKIgh0EHQiEzAxLjA3LjIwMTAgMjE6MjA6MDApAAAAAAAAAEAKIgh1EHUiEzAxLjA3LjIwMTAgMjE6MTA6MDApAAAAAAAAAEAKIgh2EHYiEzAxLjA3LjIwMTAgMjA6NTA6MDApAAAAAAAAAEAKIgh3EHciEzAxLjA3LjIwMTAgMjA6MzA6MDApAAAAAAAAAEAKIgh4EHgiEzAxLjA3LjIwMTAgMjA6MDA6MDApAAAAAAAAAEAKIgh5EHkiEzAxLjA3LjIwMTAgMTk6NTA6MDApAAAAAAAAAEAKIgh6EHoiEzAxLjA3LjIwMTAgMTk6NDA6MDApAAAAAAAAAEAKIgh7EHsiEzAxLjA3LjIwMTAgMTk6MzA6MDApAAAAAAAAAEAKIgh8EHwiEzAxLjA3LjIwMTAgMTk6MjA6MDApAAAAAAAAAEAKIgh9EH0iEzAxLjA3LjIwMTAgMTk6MTA6MDApAAAAAAAAAEAKIgh+EH4iEzAxLjA3LjIwMTAgMTg6NDA6MDApAAAAAAAAAEAKIgh/EH8iEzAxLjA3LjIwMTAgMTg6MzA6MDApAAAAAAAAAEAKJAiAARCAASITMDEuMDcuMjAxMCAxODoxMDowMCkAAAAAAAAAQAokCIEBEIEBIhMwMS4wNy4yMDEwIDE4OjAwOjAwKQAAAAAAAABACiQIggEQggEiEzAxLjA3LjIwMTAgMTc6NDA6MDApAAAAAAAAAEAKJAiDARCDASITMDEuMDcuMjAxMCAxNzozMDowMCkAAAAAAAAAQAokCIQBEIQBIhMwMS4wNy4yMDEwIDE3OjIwOjAwKQAAAAAAAABACiQIhQEQhQEiEzAxLjA3LjIwMTAgMTY6NDA6MDApAAAAAAAAAEAKJAiGARCGASITMDEuMDcuMjAxMCAxNjoyMDowMCkAAAAAAAAAQAokCIcBEIcBIhMwMS4wNy4yMDEwIDE2OjEwOjAwKQAAAAAAAABACiQIiAEQiAEiEzAxLjA3LjIwMTAgMTU6NTA6MDApAAAAAAAAAEAKJAiJARCJASITMDEuMDcuMjAxMCAxNTo0MDowMCkAAAAAAAAAQAokCIoBEIoBIhMwMS4wNy4yMDEwIDE1OjEwOjAwKQAAAAAAAABACiQIiwEQiwEiEzAxLjA3LjIwMTAgMTQ6MzA6MDApAAAAAAAAAEAKJAiMARCMASITMDEuMDcuMjAxMCAxNDoyMDowMCkAAAAAAAAAQAokCI0BEI0BIhMwMS4wNy4yMDEwIDE0OjEwOjAwKQAAAAAAAABACiQIjgEQjgEiEzAxLjA3LjIwMTAgMTQ6MDA6MDApAAAAAAAAAEAKJAiPARCPASITMDEuMDcuMjAxMCAxMzo1MDowMCkAAAAAAAAAQAokCJABEJABIhMwMS4wNy4yMDEwIDEzOjQwOjAwKQAAAAAAAABACiQIkQEQkQEiEzAxLjA3LjIwMTAgMTM6MzA6MDApAAAAAAAAAEAKJAiSARCSASITMDEuMDcuMjAxMCAxMzoxMDowMCkAAAAAAAAAQAokCJMBEJMBIhMwMS4wNy4yMDEwIDEzOjAwOjAwKQAAAAAAAABACiQIlAEQlAEiEzAxLjA3LjIwMTAgMTI6NTA6MDApAAAAAAAAAEAKJAiVARCVASITMDEuMDcuMjAxMCAxMjo0MDowMCkAAAAAAAAAQAokCJYBEJYBIhMwMS4wNy4yMDEwIDEyOjMwOjAwKQAAAAAAAABACiQIlwEQlwEiEzAxLjA3LjIwMTAgMTI6MTA6MDApAAAAAAAAAEAKJAiYARCYASITMDEuMDcuMjAxMCAxMTo1MDowMCkAAAAAAAAAQAokCJkBEJkBIhMwMS4wNy4yMDEwIDExOjQwOjAwKQAAAAAAAABACiQImgEQmgEiEzAxLjA3LjIwMTAgMTE6MjA6MDApAAAAAAAAAEAKJAibARCbASITMDEuMDcuMjAxMCAxMToxMDowMCkAAAAAAAAAQAokCJwBEJwBIhMwMS4wNy4yMDEwIDExOjAwOjAwKQAAAAAAAABACiQInQEQnQEiEzAxLjA3LjIwMTAgMTA6NDA6MDApAAAAAAAAAEAKJAieARCeASITMDEuMDcuMjAxMCAxMDozMDowMCkAAAAAAAAAQAokCJ8BEJ8BIhMwMS4wNy4yMDEwIDEwOjIwOjAwKQAAAAAAAABACiQIoAEQoAEiEzAxLjA3LjIwMTAgMTA6MTA6MDApAAAAAAAAAEAKJAihARChASITMDEuMDcuMjAxMCAxMDowMDowMCkAAAAAAAAAQAokCKIBEKIBIhMwMS4wNy4yMDEwIDA5OjQwOjAwKQAAAAAAAABACiQIowEQowEiEzAxLjA3LjIwMTAgMDk6MzA6MDApAAAAAAAAAEAKJAikARCkASITMDEuMDcuMjAxMCAwOToyMDowMCkAAAAAAAAAQAokCKUBEKUBIhMwMS4wNy4yMDEwIDA5OjEwOjAwKQAAAAAAAABACiQIpgEQpgEiEzAxLjA3LjIwMTAgMDg6NDA6MDApAAAAAAAAAEAKJAinARCnASITMDEuMDcuMjAxMCAwODozMDowMCkAAAAAAAAAQAokCKgBEKgBIhMwMS4wNy4yMDEwIDA4OjIwOjAwKQAAAAAAAABACiQIqQEQqQEiEzAxLjA3LjIwMTAgMDg6MDA6MDApAAAAAAAAAEAKJAiqARCqASITMDEuMDcuMjAxMCAwNzo1MDowMCkAAAAAAAAAQAokCKsBEKsBIhMwMS4wNy4yMDEwIDA3OjQwOjAwKQAAAAAAAABACiQIrAEQrAEiEzAxLjA3LjIwMTAgMDc6MzA6MDApAAAAAAAAAEAKJAitARCtASITMDEuMDcuMjAxMCAwNzoxMDowMCkAAAAAAAAAQAokCK4BEK4BIhMwMS4wNy4yMDEwIDA2OjUwOjAwKQAAAAAAAABACiQIrwEQrwEiEzAxLjA3LjIwMTAgMDY6MzA6MDApAAAAAAAAAEAKJAiwARCwASITMDEuMDcuMjAxMCAwNjowMDowMCkAAAAAAAAAQAokCLEBELEBIhMwMS4wNy4yMDEwIDA1OjUwOjAwKQAAAAAAAABACiQIsgEQsgEiEzAxLjA3LjIwMTAgMDU6NDA6MDApAAAAAAAAAEAKJAizARCzASITMDEuMDcuMjAxMCAwNToyMDowMCkAAAAAAAAAQAokCLQBELQBIhMwMS4wNy4yMDEwIDA1OjAwOjAwKQAAAAAAAABACiQItQEQtQEiEzAxLjA3LjIwMTAgMDQ6NDA6MDApAAAAAAAAAEAKJAi2ARC2ASITMDEuMDcuMjAxMCAwNDozMDowMCkAAAAAAAAAQAokCLcBELcBIhMwMS4wNy4yMDEwIDA0OjIwOjAwKQAAAAAAAABACiQIuAEQuAEiEzAxLjA3LjIwMTAgMDQ6MDA6MDApAAAAAAAAAEAKJAi5ARC5ASITMDEuMDcuMjAxMCAwMzo1MDowMCkAAAAAAAAAQAokCLoBELoBIhMwMS4wNy4yMDEwIDAzOjQwOjAwKQAAAAAAAABACiQIuwEQuwEiEzAxLjA3LjIwMTAgMDM6MzA6MDApAAAAAAAAAEAKJAi8ARC8ASITMDEuMDcuMjAxMCAwMjo0MDowMCkAAAAAAAAAQAokCL0BEL0BIhMwMS4wNy4yMDEwIDAyOjMwOjAwKQAAAAAAAABACiQIvgEQvgEiEzAxLjA3LjIwMTAgMDI6MjA6MDApAAAAAAAAAEAKJAi/ARC/ASITMDEuMDcuMjAxMCAwMjoxMDowMCkAAAAAAAAAQAokCMABEMABIhMwMS4wNy4yMDEwIDAyOjAwOjAwKQAAAAAAAABACiQIwQEQwQEiEzAxLjA3LjIwMTAgMDE6NTA6MDApAAAAAAAAAEAKJAjCARDCASITMDEuMDcuMjAxMCAwMTo0MDowMCkAAAAAAAAAQAokCMMBEMMBIhMwMS4wNy4yMDEwIDAxOjMwOjAwKQAAAAAAAABACiQIxAEQxAEiEzAxLjA3LjIwMTAgMDE6MTA6MDApAAAAAAAAAEAKJAjFARDFASITMDEuMDcuMjAxMCAwMTowMDowMCkAAAAAAAAAQAokCMYBEMYBIhMwMS4wNy4yMDEwIDAwOjUwOjAwKQAAAAAAAABACiQIxwEQxwEiEzAxLjA3LjIwMTAgMDA6NDA6MDApAAAAAAAAAEAKJAjIARDIASITMDEuMDcuMjAxMCAwMDoyMDowMCkAAAAAAAAAQAokCMkBEMkBIhMwMS4wNy4yMDEwIDAwOjEwOjAwKQAAAAAAAABACiQIygEQygEiEzMxLjEyLjIwMTYgMjM6NDA6MDApAAAAAAAA8D8KJAjLARDLASITMzEuMTIuMjAxNiAyMzozMDowMCkAAAAAAADwPwokCMwBEMwBIhMzMS4xMi4yMDE2IDIzOjIwOjAwKQAAAAAAAPA/CiQIzQEQzQEiEzMxLjEyLjIwMTYgMjI6NDA6MDApAAAAAAAA8D8KJAjOARDOASITMzEuMTIuMjAxNiAyMjozMDowMCkAAAAAAADwPwokCM8BEM8BIhMzMS4xMi4yMDE2IDIyOjIwOjAwKQAAAAAAAPA/CiQI0AEQ0AEiEzMxLjEyLjIwMTYgMjI6MDA6MDApAAAAAAAA8D8KJAjRARDRASITMzEuMTIuMjAxNiAyMTo1MDowMCkAAAAAAADwPwokCNIBENIBIhMzMS4xMi4yMDE2IDIxOjQwOjAwKQAAAAAAAPA/CiQI0wEQ0wEiEzMxLjEyLjIwMTYgMjE6MzA6MDApAAAAAAAA8D8KJAjUARDUASITMzEuMTIuMjAxNiAyMToyMDowMCkAAAAAAADwPwokCNUBENUBIhMzMS4xMi4yMDE2IDIxOjEwOjAwKQAAAAAAAPA/CiQI1gEQ1gEiEzMxLjEyLjIwMTYgMjE6MDA6MDApAAAAAAAA8D8KJAjXARDXASITMzEuMTIuMjAxNiAyMDo1MDowMCkAAAAAAADwPwokCNgBENgBIhMzMS4xMi4yMDE2IDIwOjMwOjAwKQAAAAAAAPA/CiQI2QEQ2QEiEzMxLjEyLjIwMTYgMjA6MjA6MDApAAAAAAAA8D8KJAjaARDaASITMzEuMTIuMjAxNiAyMDoxMDowMCkAAAAAAADwPwokCNsBENsBIhMzMS4xMi4yMDE2IDIwOjAwOjAwKQAAAAAAAPA/CiQI3AEQ3AEiEzMxLjEyLjIwMTYgMTk6NTA6MDApAAAAAAAA8D8KJAjdARDdASITMzEuMTIuMjAxNiAxOTo0MDowMCkAAAAAAADwPwokCN4BEN4BIhMzMS4xMi4yMDE2IDE5OjIwOjAwKQAAAAAAAPA/CiQI3wEQ3wEiEzMxLjEyLjIwMTYgMTk6MTA6MDApAAAAAAAA8D8KJAjgARDgASITMzEuMTIuMjAxNiAxOTowMDowMCkAAAAAAADwPwokCOEBEOEBIhMzMS4xMi4yMDE2IDE4OjUwOjAwKQAAAAAAAPA/CiQI4gEQ4gEiEzMxLjEyLjIwMTYgMTg6MjA6MDApAAAAAAAA8D8KJAjjARDjASITMzEuMTIuMjAxNiAxODoxMDowMCkAAAAAAADwPwokCOQBEOQBIhMzMS4xMi4yMDE2IDE4OjAwOjAwKQAAAAAAAPA/CiQI5QEQ5QEiEzMxLjEyLjIwMTYgMTc6NDA6MDApAAAAAAAA8D8KJAjmARDmASITMzEuMTIuMjAxNiAxNzozMDowMCkAAAAAAADwPwokCOcBEOcBIhMzMS4xMi4yMDE2IDE3OjIwOjAwKQAAAAAAAPA/CiQI6AEQ6AEiEzMxLjEyLjIwMTYgMTc6MTA6MDApAAAAAAAA8D8KJAjpARDpASITMzEuMTIuMjAxNiAxNjo1MDowMCkAAAAAAADwPwokCOoBEOoBIhMzMS4xMi4yMDE2IDE2OjQwOjAwKQAAAAAAAPA/CiQI6wEQ6wEiEzMxLjEyLjIwMTYgMTY6MzA6MDApAAAAAAAA8D8KJAjsARDsASITMzEuMTIuMjAxNiAxNjoyMDowMCkAAAAAAADwPwokCO0BEO0BIhMzMS4xMi4yMDE2IDE2OjEwOjAwKQAAAAAAAPA/CiQI7gEQ7gEiEzMxLjEyLjIwMTYgMTU6NTA6MDApAAAAAAAA8D8KJAjvARDvASITMzEuMTIuMjAxNiAxNTo0MDowMCkAAAAAAADwPwokCPABEPABIhMzMS4xMi4yMDE2IDE1OjMwOjAwKQAAAAAAAPA/CiQI8QEQ8QEiEzMxLjEyLjIwMTYgMTU6MjA6MDApAAAAAAAA8D8KJAjyARDyASITMzEuMTIuMjAxNiAxNToxMDowMCkAAAAAAADwPwokCPMBEPMBIhMzMS4xMi4yMDE2IDE1OjAwOjAwKQAAAAAAAPA/CiQI9AEQ9AEiEzMxLjEyLjIwMTYgMTQ6NTA6MDApAAAAAAAA8D8KJAj1ARD1ASITMzEuMTIuMjAxNiAxNDozMDowMCkAAAAAAADwPwokCPYBEPYBIhMzMS4xMi4yMDE2IDE0OjIwOjAwKQAAAAAAAPA/CiQI9wEQ9wEiEzMxLjEyLjIwMTYgMTQ6MTA6MDApAAAAAAAA8D8KJAj4ARD4ASITMzEuMTIuMjAxNiAxNDowMDowMCkAAAAAAADwPwokCPkBEPkBIhMzMS4xMi4yMDE2IDEzOjUwOjAwKQAAAAAAAPA/CiQI+gEQ+gEiEzMxLjEyLjIwMTYgMTM6NDA6MDApAAAAAAAA8D8KJAj7ARD7ASITMzEuMTIuMjAxNiAxMzowMDowMCkAAAAAAADwPwokCPwBEPwBIhMzMS4xMi4yMDE2IDEyOjUwOjAwKQAAAAAAAPA/CiQI/QEQ/QEiEzMxLjEyLjIwMTYgMTI6NDA6MDApAAAAAAAA8D8KJAj+ARD+ASITMzEuMTIuMjAxNiAxMjozMDowMCkAAAAAAADwPwokCP8BEP8BIhMzMS4xMi4yMDE2IDEyOjIwOjAwKQAAAAAAAPA/CiQIgAIQgAIiEzMxLjEyLjIwMTYgMTI6MTA6MDApAAAAAAAA8D8KJAiBAhCBAiITMzEuMTIuMjAxNiAxMjowMDowMCkAAAAAAADwPwokCIICEIICIhMzMS4xMi4yMDE2IDExOjUwOjAwKQAAAAAAAPA/CiQIgwIQgwIiEzMxLjEyLjIwMTYgMTE6MzA6MDApAAAAAAAA8D8KJAiEAhCEAiITMzEuMTIuMjAxNiAxMToyMDowMCkAAAAAAADwPwokCIUCEIUCIhMzMS4xMi4yMDE2IDExOjAwOjAwKQAAAAAAAPA/CiQIhgIQhgIiEzMxLjEyLjIwMTYgMTA6MTA6MDApAAAAAAAA8D8KJAiHAhCHAiITMzEuMTIuMjAxNiAxMDowMDowMCkAAAAAAADwPwokCIgCEIgCIhMzMS4xMi4yMDE2IDA5OjUwOjAwKQAAAAAAAPA/CiQIiQIQiQIiEzMxLjEyLjIwMTYgMDk6NDA6MDApAAAAAAAA8D8KJAiKAhCKAiITMzEuMTIuMjAxNiAwOToyMDowMCkAAAAAAADwPwokCIsCEIsCIhMzMS4xMi4yMDE2IDA5OjEwOjAwKQAAAAAAAPA/CiQIjAIQjAIiEzMxLjEyLjIwMTYgMDk6MDA6MDApAAAAAAAA8D8KJAiNAhCNAiITMzEuMTIuMjAxNiAwODo1MDowMCkAAAAAAADwPwokCI4CEI4CIhMzMS4xMi4yMDE2IDA4OjQwOjAwKQAAAAAAAPA/CiQIjwIQjwIiEzMxLjEyLjIwMTYgMDg6MzA6MDApAAAAAAAA8D8KJAiQAhCQAiITMzEuMTIuMjAxNiAwODoyMDowMCkAAAAAAADwPwokCJECEJECIhMzMS4xMi4yMDE2IDA4OjEwOjAwKQAAAAAAAPA/CiQIkgIQkgIiEzMxLjEyLjIwMTYgMDg6MDA6MDApAAAAAAAA8D8KJAiTAhCTAiITMzEuMTIuMjAxNiAwNzo1MDowMCkAAAAAAADwPwokCJQCEJQCIhMzMS4xMi4yMDE2IDA3OjQwOjAwKQAAAAAAAPA/CiQIlQIQlQIiEzMxLjEyLjIwMTYgMDc6MzA6MDApAAAAAAAA8D8KJAiWAhCWAiITMzEuMTIuMjAxNiAwNzoyMDowMCkAAAAAAADwPwokCJcCEJcCIhMzMS4xMi4yMDE2IDA3OjEwOjAwKQAAAAAAAPA/CiQImAIQmAIiEzMxLjEyLjIwMTYgMDc6MDA6MDApAAAAAAAA8D8KJAiZAhCZAiITMzEuMTIuMjAxNiAwNjo1MDowMCkAAAAAAADwPwokCJoCEJoCIhMzMS4xMi4yMDE2IDA2OjQwOjAwKQAAAAAAAPA/CiQImwIQmwIiEzMxLjEyLjIwMTYgMDY6MjA6MDApAAAAAAAA8D8KJAicAhCcAiITMzEuMTIuMjAxNiAwNjoxMDowMCkAAAAAAADwPwokCJ0CEJ0CIhMzMS4xMi4yMDE2IDA2OjAwOjAwKQAAAAAAAPA/CiQIngIQngIiEzMxLjEyLjIwMTYgMDU6NTA6MDApAAAAAAAA8D8KJAifAhCfAiITMzEuMTIuMjAxNiAwNTo0MDowMCkAAAAAAADwPwokCKACEKACIhMzMS4xMi4yMDE2IDA1OjEwOjAwKQAAAAAAAPA/CiQIoQIQoQIiEzMxLjEyLjIwMTYgMDQ6NTA6MDApAAAAAAAA8D8KJAiiAhCiAiITMzEuMTIuMjAxNiAwNDo0MDowMCkAAAAAAADwPwokCKMCEKMCIhMzMS4xMi4yMDE2IDA0OjIwOjAwKQAAAAAAAPA/CiQIpAIQpAIiEzMxLjEyLjIwMTYgMDQ6MDA6MDApAAAAAAAA8D8KJAilAhClAiITMzEuMTIuMjAxNiAwMzo1MDowMCkAAAAAAADwPwokCKYCEKYCIhMzMS4xMi4yMDE2IDAzOjMwOjAwKQAAAAAAAPA/CiQIpwIQpwIiEzMxLjEyLjIwMTYgMDM6MTA6MDApAAAAAAAA8D8KJAioAhCoAiITMzEuMTIuMjAxNiAwMzowMDowMCkAAAAAAADwPwokCKkCEKkCIhMzMS4xMi4yMDE2IDAyOjUwOjAwKQAAAAAAAPA/CiQIqgIQqgIiEzMxLjEyLjIwMTYgMDI6NDA6MDApAAAAAAAA8D8KJAirAhCrAiITMzEuMTIuMjAxNiAwMjozMDowMCkAAAAAAADwPwokCKwCEKwCIhMzMS4xMi4yMDE2IDAyOjIwOjAwKQAAAAAAAPA/CiQIrQIQrQIiEzMxLjEyLjIwMTYgMDI6MTA6MDApAAAAAAAA8D8KJAiuAhCuAiITMzEuMTIuMjAxNiAwMTo1MDowMCkAAAAAAADwPwokCK8CEK8CIhMzMS4xMi4yMDE2IDAxOjQwOjAwKQAAAAAAAPA/CiQIsAIQsAIiEzMxLjEyLjIwMTYgMDE6MjA6MDApAAAAAAAA8D8KJAixAhCxAiITMzEuMTIuMjAxNiAwMToxMDowMCkAAAAAAADwPwokCLICELICIhMzMS4xMi4yMDE2IDAxOjAwOjAwKQAAAAAAAPA/CiQIswIQswIiEzMxLjEyLjIwMTYgMDA6NTA6MDApAAAAAAAA8D8KJAi0AhC0AiITMzEuMTIuMjAxNiAwMDozMDowMCkAAAAAAADwPwokCLUCELUCIhMzMS4xMi4yMDE2IDAwOjIwOjAwKQAAAAAAAPA/CiQItgIQtgIiEzMxLjEyLjIwMTUgMjM6MDA6MDApAAAAAAAA8D8KJAi3AhC3AiITMzEuMTIuMjAxNSAyMjo0MDowMCkAAAAAAADwPwokCLgCELgCIhMzMS4xMi4yMDE1IDIyOjIwOjAwKQAAAAAAAPA/CiQIuQIQuQIiEzMxLjEyLjIwMTUgMjI6MTA6MDApAAAAAAAA8D8KJAi6AhC6AiITMzEuMTIuMjAxNSAyMjowMDowMCkAAAAAAADwPwokCLsCELsCIhMzMS4xMi4yMDE1IDIxOjQwOjAwKQAAAAAAAPA/CiQIvAIQvAIiEzMxLjEyLjIwMTUgMjE6MzA6MDApAAAAAAAA8D8KJAi9AhC9AiITMzEuMTIuMjAxNSAyMDo1MDowMCkAAAAAAADwPwokCL4CEL4CIhMzMS4xMi4yMDE1IDIwOjEwOjAwKQAAAAAAAPA/CiQIvwIQvwIiEzMxLjEyLjIwMTUgMTk6NTA6MDApAAAAAAAA8D8KJAjAAhDAAiITMzEuMTIuMjAxNSAxOTo0MDowMCkAAAAAAADwPwokCMECEMECIhMzMS4xMi4yMDE1IDE5OjMwOjAwKQAAAAAAAPA/CiQIwgIQwgIiEzMxLjEyLjIwMTUgMTk6MDA6MDApAAAAAAAA8D8KJAjDAhDDAiITMzEuMTIuMjAxNSAxODo1MDowMCkAAAAAAADwPwokCMQCEMQCIhMzMS4xMi4yMDE1IDE4OjEwOjAwKQAAAAAAAPA/CiQIxQIQxQIiEzMxLjEyLjIwMTUgMTg6MDA6MDApAAAAAAAA8D8KJAjGAhDGAiITMzEuMTIuMjAxNSAxNzo1MDowMCkAAAAAAADwPwokCMcCEMcCIhMzMS4xMi4yMDE1IDE3OjEwOjAwKQAAAAAAAPA/CiQIyAIQyAIiEzMxLjEyLjIwMTUgMTc6MDA6MDApAAAAAAAA8D8KJAjJAhDJAiITMzEuMTIuMjAxNSAxNjo1MDowMCkAAAAAAADwPwokCMoCEMoCIhMzMS4xMi4yMDE1IDE2OjMwOjAwKQAAAAAAAPA/CiQIywIQywIiEzMxLjEyLjIwMTUgMTY6MjA6MDApAAAAAAAA8D8KJAjMAhDMAiITMzEuMTIuMjAxNSAxNjowMDowMCkAAAAAAADwPwokCM0CEM0CIhMzMS4xMi4yMDE1IDE1OjQwOjAwKQAAAAAAAPA/CiQIzgIQzgIiEzMxLjEyLjIwMTUgMTU6MzA6MDApAAAAAAAA8D8KJAjPAhDPAiITMzEuMTIuMjAxNSAxNDo0MDowMCkAAAAAAADwPwokCNACENACIhMzMS4xMi4yMDE1IDE0OjMwOjAwKQAAAAAAAPA/CiQI0QIQ0QIiEzMxLjEyLjIwMTUgMTQ6MDA6MDApAAAAAAAA8D8KJAjSAhDSAiITMzEuMTIuMjAxNSAxMzo1MDowMCkAAAAAAADwPwokCNMCENMCIhMzMS4xMi4yMDE1IDEzOjQwOjAwKQAAAAAAAPA/CiQI1AIQ1AIiEzMxLjEyLjIwMTUgMTM6MjA6MDApAAAAAAAA8D8KJAjVAhDVAiITMzEuMTIuMjAxNSAxMzoxMDowMCkAAAAAAADwPwokCNYCENYCIhMzMS4xMi4yMDE1IDEzOjAwOjAwKQAAAAAAAPA/CiQI1wIQ1wIiEzMxLjEyLjIwMTUgMTI6NTA6MDApAAAAAAAA8D8KJAjYAhDYAiITMzEuMTIuMjAxNSAxMjozMDowMCkAAAAAAADwPwokCNkCENkCIhMzMS4xMi4yMDE1IDEyOjIwOjAwKQAAAAAAAPA/CiQI2gIQ2gIiEzMxLjEyLjIwMTUgMTI6MDA6MDApAAAAAAAA8D8KJAjbAhDbAiITMzEuMTIuMjAxNSAxMTo1MDowMCkAAAAAAADwPwokCNwCENwCIhMzMS4xMi4yMDE1IDExOjIwOjAwKQAAAAAAAPA/CiQI3QIQ3QIiEzMxLjEyLjIwMTUgMTA6NTA6MDApAAAAAAAA8D8KJAjeAhDeAiITMzEuMTIuMjAxNSAxMDozMDowMCkAAAAAAADwPwokCN8CEN8CIhMzMS4xMi4yMDE1IDEwOjIwOjAwKQAAAAAAAPA/CiQI4AIQ4AIiEzMxLjEyLjIwMTUgMDk6NTA6MDApAAAAAAAA8D8KJAjhAhDhAiITMzEuMTIuMjAxNSAwOTo0MDowMCkAAAAAAADwPwokCOICEOICIhMzMS4xMi4yMDE1IDA5OjMwOjAwKQAAAAAAAPA/CiQI4wIQ4wIiEzMxLjEyLjIwMTUgMDk6MjA6MDApAAAAAAAA8D8KJAjkAhDkAiITMzEuMTIuMjAxNSAwOToxMDowMCkAAAAAAADwPwokCOUCEOUCIhMzMS4xMi4yMDE1IDA4OjQwOjAwKQAAAAAAAPA/CiQI5gIQ5gIiEzMxLjEyLjIwMTUgMDg6MTA6MDApAAAAAAAA8D8KJAjnAhDnAiITMzEuMTIuMjAxNSAwODowMDowMCkAAAAAAADwPwokCOgCEOgCIhMzMS4xMi4yMDE1IDA3OjUwOjAwKQAAAAAAAPA/CiQI6QIQ6QIiEzMxLjEyLjIwMTUgMDc6NDA6MDApAAAAAAAA8D8KJAjqAhDqAiITMzEuMTIuMjAxNSAwNzozMDowMCkAAAAAAADwPwokCOsCEOsCIhMzMS4xMi4yMDE1IDA3OjIwOjAwKQAAAAAAAPA/CiQI7AIQ7AIiEzMxLjEyLjIwMTUgMDc6MTA6MDApAAAAAAAA8D8KJAjtAhDtAiITMzEuMTIuMjAxNSAwNjo1MDowMCkAAAAAAADwPwokCO4CEO4CIhMzMS4xMi4yMDE1IDA2OjMwOjAwKQAAAAAAAPA/CiQI7wIQ7wIiEzMxLjEyLjIwMTUgMDY6MjA6MDApAAAAAAAA8D8KJAjwAhDwAiITMzEuMTIuMjAxNSAwNjowMDowMCkAAAAAAADwPwokCPECEPECIhMzMS4xMi4yMDE1IDA1OjQwOjAwKQAAAAAAAPA/CiQI8gIQ8gIiEzMxLjEyLjIwMTUgMDU6MzA6MDApAAAAAAAA8D8KJAjzAhDzAiITMzEuMTIuMjAxNSAwNToyMDowMCkAAAAAAADwPwokCPQCEPQCIhMzMS4xMi4yMDE1IDA1OjEwOjAwKQAAAAAAAPA/CiQI9QIQ9QIiEzMxLjEyLjIwMTUgMDU6MDA6MDApAAAAAAAA8D8KJAj2AhD2AiITMzEuMTIuMjAxNSAwNDo1MDowMCkAAAAAAADwPwokCPcCEPcCIhMzMS4xMi4yMDE1IDA0OjQwOjAwKQAAAAAAAPA/CiQI+AIQ+AIiEzMxLjEyLjIwMTUgMDQ6MzA6MDApAAAAAAAA8D8KJAj5AhD5AiITMzEuMTIuMjAxNSAwNDoyMDowMCkAAAAAAADwPwokCPoCEPoCIhMzMS4xMi4yMDE1IDA0OjEwOjAwKQAAAAAAAPA/CiQI+wIQ+wIiEzMxLjEyLjIwMTUgMDQ6MDA6MDApAAAAAAAA8D8KJAj8AhD8AiITMzEuMTIuMjAxNSAwMzo0MDowMCkAAAAAAADwPwokCP0CEP0CIhMzMS4xMi4yMDE1IDAzOjEwOjAwKQAAAAAAAPA/CiQI/gIQ/gIiEzMxLjEyLjIwMTUgMDM6MDA6MDApAAAAAAAA8D8KJAj/AhD/AiITMzEuMTIuMjAxNSAwMjozMDowMCkAAAAAAADwPwokCIADEIADIhMzMS4xMi4yMDE1IDAyOjAwOjAwKQAAAAAAAPA/CiQIgQMQgQMiEzMxLjEyLjIwMTUgMDE6NTA6MDApAAAAAAAA8D8KJAiCAxCCAyITMzEuMTIuMjAxNSAwMTo0MDowMCkAAAAAAADwPwokCIMDEIMDIhMzMS4xMi4yMDE1IDAxOjMwOjAwKQAAAAAAAPA/CiQIhAMQhAMiEzMxLjEyLjIwMTUgMDE6MjA6MDApAAAAAAAA8D8KJAiFAxCFAyITMzEuMTIuMjAxNSAwMToxMDowMCkAAAAAAADwPwokCIYDEIYDIhMzMS4xMi4yMDE1IDAwOjUwOjAwKQAAAAAAAPA/CiQIhwMQhwMiEzMxLjEyLjIwMTUgMDA6NDA6MDApAAAAAAAA8D8KJAiIAxCIAyITMzEuMTIuMjAxNSAwMDozMDowMCkAAAAAAADwPwokCIkDEIkDIhMzMS4xMi4yMDE1IDAwOjIwOjAwKQAAAAAAAPA/CiQIigMQigMiEzMxLjEyLjIwMTUgMDA6MTA6MDApAAAAAAAA8D8KJAiLAxCLAyITMzEuMTIuMjAxNSAwMDowMDowMCkAAAAAAADwPwokCIwDEIwDIhMzMS4xMi4yMDE0IDIzOjQwOjAwKQAAAAAAAPA/CiQIjQMQjQMiEzMxLjEyLjIwMTQgMjM6MzA6MDApAAAAAAAA8D8KJAiOAxCOAyITMzEuMTIuMjAxNCAyMzoxMDowMCkAAAAAAADwPwokCI8DEI8DIhMzMS4xMi4yMDE0IDIzOjAwOjAwKQAAAAAAAPA/CiQIkAMQkAMiEzMxLjEyLjIwMTQgMjI6NTA6MDApAAAAAAAA8D8KJAiRAxCRAyITMzEuMTIuMjAxNCAyMjozMDowMCkAAAAAAADwPwokCJIDEJIDIhMzMS4xMi4yMDE0IDIyOjIwOjAwKQAAAAAAAPA/CiQIkwMQkwMiEzMxLjEyLjIwMTQgMjI6MTA6MDApAAAAAAAA8D8KJAiUAxCUAyITMzEuMTIuMjAxNCAyMjowMDowMCkAAAAAAADwPwokCJUDEJUDIhMzMS4xMi4yMDE0IDIxOjMwOjAwKQAAAAAAAPA/CiQIlgMQlgMiEzMxLjEyLjIwMTQgMjE6MjA6MDApAAAAAAAA8D8KJAiXAxCXAyITMzEuMTIuMjAxNCAyMToxMDowMCkAAAAAAADwPwokCJgDEJgDIhMzMS4xMi4yMDE0IDIxOjAwOjAwKQAAAAAAAPA/CiQImQMQmQMiEzMxLjEyLjIwMTQgMjA6NTA6MDApAAAAAAAA8D8KJAiaAxCaAyITMzEuMTIuMjAxNCAyMDozMDowMCkAAAAAAADwPwokCJsDEJsDIhMzMS4xMi4yMDE0IDIwOjIwOjAwKQAAAAAAAPA/CiQInAMQnAMiEzMxLjEyLjIwMTQgMjA6MDA6MDApAAAAAAAA8D8KJAidAxCdAyITMzEuMTIuMjAxNCAxOTo1MDowMCkAAAAAAADwPwokCJ4DEJ4DIhMzMS4xMi4yMDE0IDE5OjQwOjAwKQAAAAAAAPA/CiQInwMQnwMiEzMxLjEyLjIwMTQgMTk6MzA6MDApAAAAAAAA8D8KJAigAxCgAyITMzEuMTIuMjAxNCAxOToyMDowMCkAAAAAAADwPwokCKEDEKEDIhMzMS4xMi4yMDE0IDE5OjEwOjAwKQAAAAAAAPA/CiQIogMQogMiEzMxLjEyLjIwMTQgMTk6MDA6MDApAAAAAAAA8D8KJAijAxCjAyITMzEuMTIuMjAxNCAxODo0MDowMCkAAAAAAADwPwokCKQDEKQDIhMzMS4xMi4yMDE0IDE4OjEwOjAwKQAAAAAAAPA/CiQIpQMQpQMiEzMxLjEyLjIwMTQgMTg6MDA6MDApAAAAAAAA8D8KJAimAxCmAyITMzEuMTIuMjAxNCAxNzo1MDowMCkAAAAAAADwPwokCKcDEKcDIhMzMS4xMi4yMDE0IDE3OjQwOjAwKQAAAAAAAPA/CiQIqAMQqAMiEzMxLjEyLjIwMTQgMTc6MzA6MDApAAAAAAAA8D8KJAipAxCpAyITMzEuMTIuMjAxNCAxNzowMDowMCkAAAAAAADwPwokCKoDEKoDIhMzMS4xMi4yMDE0IDE2OjQwOjAwKQAAAAAAAPA/CiQIqwMQqwMiEzMxLjEyLjIwMTQgMTY6MzA6MDApAAAAAAAA8D8KJAisAxCsAyITMzEuMTIuMjAxNCAxNjowMDowMCkAAAAAAADwPwokCK0DEK0DIhMzMS4xMi4yMDE0IDE1OjQwOjAwKQAAAAAAAPA/CiQIrgMQrgMiEzMxLjEyLjIwMTQgMTU6MjA6MDApAAAAAAAA8D8KJAivAxCvAyITMzEuMTIuMjAxNCAxNToxMDowMCkAAAAAAADwPwokCLADELADIhMzMS4xMi4yMDE0IDE0OjQwOjAwKQAAAAAAAPA/CiQIsQMQsQMiEzMxLjEyLjIwMTQgMTQ6MDA6MDApAAAAAAAA8D8KJAiyAxCyAyITMzEuMTIuMjAxNCAxMzo1MDowMCkAAAAAAADwPwokCLMDELMDIhMzMS4xMi4yMDE0IDEzOjIwOjAwKQAAAAAAAPA/CiQItAMQtAMiEzMxLjEyLjIwMTQgMTM6MDA6MDApAAAAAAAA8D8KJAi1AxC1AyITMzEuMTIuMjAxNCAxMjo1MDowMCkAAAAAAADwPwokCLYDELYDIhMzMS4xMi4yMDE0IDEyOjQwOjAwKQAAAAAAAPA/CiQItwMQtwMiEzMxLjEyLjIwMTQgMTI6MzA6MDApAAAAAAAA8D8KJAi4AxC4AyITMzEuMTIuMjAxNCAxMjoyMDowMCkAAAAAAADwPwokCLkDELkDIhMzMS4xMi4yMDE0IDEyOjEwOjAwKQAAAAAAAPA/CiQIugMQugMiEzMxLjEyLjIwMTQgMTI6MDA6MDApAAAAAAAA8D8KJAi7AxC7AyITMzEuMTIuMjAxNCAxMTo1MDowMCkAAAAAAADwPwokCLwDELwDIhMzMS4xMi4yMDE0IDExOjQwOjAwKQAAAAAAAPA/CiQIvQMQvQMiEzMxLjEyLjIwMTQgMTE6MzA6MDApAAAAAAAA8D8KJAi+AxC+AyITMzEuMTIuMjAxNCAxMToyMDowMCkAAAAAAADwPwokCL8DEL8DIhMzMS4xMi4yMDE0IDEwOjQwOjAwKQAAAAAAAPA/CiQIwAMQwAMiEzMxLjEyLjIwMTQgMTA6MjA6MDApAAAAAAAA8D8KJAjBAxDBAyITMzEuMTIuMjAxNCAxMDoxMDowMCkAAAAAAADwPwokCMIDEMIDIhMzMS4xMi4yMDE0IDEwOjAwOjAwKQAAAAAAAPA/CiQIwwMQwwMiEzMxLjEyLjIwMTQgMDk6NDA6MDApAAAAAAAA8D8KJAjEAxDEAyITMzEuMTIuMjAxNCAwOToxMDowMCkAAAAAAADwPwokCMUDEMUDIhMzMS4xMi4yMDE0IDA5OjAwOjAwKQAAAAAAAPA/CiQIxgMQxgMiEzMxLjEyLjIwMTQgMDg6NTA6MDApAAAAAAAA8D8KJAjHAxDHAyITMzEuMTIuMjAxNCAwODowMDowMCkAAAAAAADwPwokCMgDEMgDIhMzMS4xMi4yMDE0IDA3OjUwOjAwKQAAAAAAAPA/CiQIyQMQyQMiEzMxLjEyLjIwMTQgMDc6MTA6MDApAAAAAAAA8D8KJAjKAxDKAyITMzEuMTIuMjAxNCAwNzowMDowMCkAAAAAAADwPwokCMsDEMsDIhMzMS4xMi4yMDE0IDA2OjQwOjAwKQAAAAAAAPA/CiQIzAMQzAMiEzMxLjEyLjIwMTQgMDY6MjA6MDApAAAAAAAA8D8KJAjNAxDNAyITMzEuMTIuMjAxNCAwNjoxMDowMCkAAAAAAADwPwokCM4DEM4DIhMzMS4xMi4yMDE0IDA2OjAwOjAwKQAAAAAAAPA/CiQIzwMQzwMiEzMxLjEyLjIwMTQgMDU6NTA6MDApAAAAAAAA8D8KJAjQAxDQAyITMzEuMTIuMjAxNCAwNTo0MDowMCkAAAAAAADwPwokCNEDENEDIhMzMS4xMi4yMDE0IDA1OjMwOjAwKQAAAAAAAPA/CiQI0gMQ0gMiEzMxLjEyLjIwMTQgMDU6MjA6MDApAAAAAAAA8D8KJAjTAxDTAyITMzEuMTIuMjAxNCAwNToxMDowMCkAAAAAAADwPwokCNQDENQDIhMzMS4xMi4yMDE0IDA1OjAwOjAwKQAAAAAAAPA/CiQI1QMQ1QMiEzMxLjEyLjIwMTQgMDQ6NTA6MDApAAAAAAAA8D8KJAjWAxDWAyITMzEuMTIuMjAxNCAwNDo0MDowMCkAAAAAAADwPwokCNcDENcDIhMzMS4xMi4yMDE0IDA0OjEwOjAwKQAAAAAAAPA/CiQI2AMQ2AMiEzMxLjEyLjIwMTQgMDM6NTA6MDApAAAAAAAA8D8KJAjZAxDZAyITMzEuMTIuMjAxNCAwMzo0MDowMCkAAAAAAADwPwokCNoDENoDIhMzMS4xMi4yMDE0IDAzOjMwOjAwKQAAAAAAAPA/CiQI2wMQ2wMiEzMxLjEyLjIwMTQgMDM6MjA6MDApAAAAAAAA8D8KJAjcAxDcAyITMzEuMTIuMjAxNCAwMzoxMDowMCkAAAAAAADwPwokCN0DEN0DIhMzMS4xMi4yMDE0IDAzOjAwOjAwKQAAAAAAAPA/CiQI3gMQ3gMiEzMxLjEyLjIwMTQgMDI6MjA6MDApAAAAAAAA8D8KJAjfAxDfAyITMzEuMTIuMjAxNCAwMjoxMDowMCkAAAAAAADwPwokCOADEOADIhMzMS4xMi4yMDE0IDAxOjUwOjAwKQAAAAAAAPA/CiQI4QMQ4QMiEzMxLjEyLjIwMTQgMDE6NDA6MDApAAAAAAAA8D8KJAjiAxDiAyITMzEuMTIuMjAxNCAwMTozMDowMCkAAAAAAADwPwokCOMDEOMDIhMzMS4xMi4yMDE0IDAxOjIwOjAwKQAAAAAAAPA/CiQI5AMQ5AMiEzMxLjEyLjIwMTQgMDE6MTA6MDApAAAAAAAA8D8KJAjlAxDlAyITMzEuMTIuMjAxNCAwMTowMDowMCkAAAAAAADwPwokCOYDEOYDIhMzMS4xMi4yMDE0IDAwOjUwOjAwKQAAAAAAAPA/CiQI5wMQ5wMiEzMxLjEyLjIwMTQgMDA6NDA6MDApAAAAAAAA8D8KJAjoAxDoAyITMzEuMTIuMjAxNCAwMDozMDowMCkAAAAAAADwPwokCOkDEOkDIhMzMS4xMi4yMDE0IDAwOjIwOjAwKQAAAAAAAPA/CiQI6gMQ6gMiEzMxLjEyLjIwMTQgMDA6MDA6MDApAAAAAAAA8D8KJAjrAxDrAyITMzEuMTIuMjAxMyAyMzo0MDowMCkAAAAAAADwPwokCOwDEOwDIhMzMS4xMi4yMDEzIDIzOjIwOjAwKQAAAAAAAPA/CiQI7QMQ7QMiEzMxLjEyLjIwMTMgMjI6MjA6MDApAAAAAAAA8D8KJAjuAxDuAyITMzEuMTIuMjAxMyAyMjowMDowMCkAAAAAAADwPwokCO8DEO8DIhMzMS4xMi4yMDEzIDIxOjUwOjAwKQAAAAAAAPA/CiQI8AMQ8AMiEzMxLjEyLjIwMTMgMjE6MjA6MDApAAAAAAAA8D8KJAjxAxDxAyITMzEuMTIuMjAxMyAyMDo1MDowMCkAAAAAAADwPwokCPIDEPIDIhMzMS4xMi4yMDEzIDIwOjQwOjAwKQAAAAAAAPA/CiQI8wMQ8wMiEzMxLjEyLjIwMTMgMjA6MjA6MDApAAAAAAAA8D8KJAj0AxD0AyITMzEuMTIuMjAxMyAyMDowMDowMCkAAAAAAADwPwokCPUDEPUDIhMzMS4xMi4yMDEzIDE5OjUwOjAwKQAAAAAAAPA/CiQI9gMQ9gMiEzMxLjEyLjIwMTMgMTk6NDA6MDApAAAAAAAA8D8KJAj3AxD3AyITMzEuMTIuMjAxMyAxOTozMDowMCkAAAAAAADwPwokCPgDEPgDIhMzMS4xMi4yMDEzIDE5OjIwOjAwKQAAAAAAAPA/CiQI+QMQ+QMiEzMxLjEyLjIwMTMgMTg6NTA6MDApAAAAAAAA8D8KJAj6AxD6AyITMzEuMTIuMjAxMyAxODo0MDowMCkAAAAAAADwPwokCPsDEPsDIhMzMS4xMi4yMDEzIDE4OjMwOjAwKQAAAAAAAPA/CiQI/AMQ/AMiEzMxLjEyLjIwMTMgMTg6MjA6MDApAAAAAAAA8D8KJAj9AxD9AyITMzEuMTIuMjAxMyAxODowMDowMCkAAAAAAADwPwokCP4DEP4DIhMzMS4xMi4yMDEzIDE3OjUwOjAwKQAAAAAAAPA/CiQI/wMQ/wMiEzMxLjEyLjIwMTMgMTc6MzA6MDApAAAAAAAA8D8KJAiABBCABCITMzEuMTIuMjAxMyAxNzoyMDowMCkAAAAAAADwPwokCIEEEIEEIhMzMS4xMi4yMDEzIDE3OjEwOjAwKQAAAAAAAPA/CiQIggQQggQiEzMxLjEyLjIwMTMgMTc6MDA6MDApAAAAAAAA8D8KJAiDBBCDBCITMzEuMTIuMjAxMyAxNjo0MDowMCkAAAAAAADwPwokCIQEEIQEIhMzMS4xMi4yMDEzIDE2OjAwOjAwKQAAAAAAAPA/CiQIhQQQhQQiEzMxLjEyLjIwMTMgMTU6NTA6MDApAAAAAAAA8D8KJAiGBBCGBCITMzEuMTIuMjAxMyAxNTo0MDowMCkAAAAAAADwPwokCIcEEIcEIhMzMS4xMi4yMDEzIDE1OjIwOjAwKQAAAAAAAPA/CiQIiAQQiAQiEzMxLjEyLjIwMTMgMTU6MTA6MDApAAAAAAAA8D8KJAiJBBCJBCITMzEuMTIuMjAxMyAxNTowMDowMCkAAAAAAADwPwokCIoEEIoEIhMzMS4xMi4yMDEzIDE0OjUwOjAwKQAAAAAAAPA/CiQIiwQQiwQiEzMxLjEyLjIwMTMgMTQ6MzA6MDApAAAAAAAA8D8KJAiMBBCMBCITMzEuMTIuMjAxMyAxNDoyMDowMCkAAAAAAADwPwokCI0EEI0EIhMzMS4xMi4yMDEzIDE0OjAwOjAwKQAAAAAAAPA/CiQIjgQQjgQiEzMxLjEyLjIwMTMgMTM6NTA6MDApAAAAAAAA8D8KJAiPBBCPBCITMzEuMTIuMjAxMyAxMzo0MDowMCkAAAAAAADwPwokCJAEEJAEIhMzMS4xMi4yMDEzIDEzOjIwOjAwKQAAAAAAAPA/CiQIkQQQkQQiEzMxLjEyLjIwMTMgMTM6MTA6MDApAAAAAAAA8D8KJAiSBBCSBCITMzEuMTIuMjAxMyAxMzowMDowMCkAAAAAAADwPwokCJMEEJMEIhMzMS4xMi4yMDEzIDEyOjUwOjAwKQAAAAAAAPA/CiQIlAQQlAQiEzMxLjEyLjIwMTMgMTI6NDA6MDApAAAAAAAA8D8KJAiVBBCVBCITMzEuMTIuMjAxMyAxMjozMDowMCkAAAAAAADwPwokCJYEEJYEIhMzMS4xMi4yMDEzIDEyOjIwOjAwKQAAAAAAAPA/CiQIlwQQlwQiEzMxLjEyLjIwMTMgMTI6MTA6MDApAAAAAAAA8D8KJAiYBBCYBCITMzEuMTIuMjAxMyAxMTozMDowMCkAAAAAAADwPwokCJkEEJkEIhMzMS4xMi4yMDEzIDExOjIwOjAwKQAAAAAAAPA/CiQImgQQmgQiEzMxLjEyLjIwMTMgMTE6MTA6MDApAAAAAAAA8D8KJAibBBCbBCITMzEuMTIuMjAxMyAxMTowMDowMCkAAAAAAADwPwokCJwEEJwEIhMzMS4xMi4yMDEzIDEwOjUwOjAwKQAAAAAAAPA/CiQInQQQnQQiEzMxLjEyLjIwMTMgMTA6NDA6MDApAAAAAAAA8D8KJAieBBCeBCITMzEuMTIuMjAxMyAxMDozMDowMCkAAAAAAADwPwokCJ8EEJ8EIhMzMS4xMi4yMDEzIDEwOjEwOjAwKQAAAAAAAPA/CiQIoAQQoAQiEzMxLjEyLjIwMTMgMTA6MDA6MDApAAAAAAAA8D8KJAihBBChBCITMzEuMTIuMjAxMyAwOTo1MDowMCkAAAAAAADwPwokCKIEEKIEIhMzMS4xMi4yMDEzIDA5OjEwOjAwKQAAAAAAAPA/CiQIowQQowQiEzMxLjEyLjIwMTMgMDk6MDA6MDApAAAAAAAA8D8KJAikBBCkBCITMzEuMTIuMjAxMyAwODoxMDowMCkAAAAAAADwPwokCKUEEKUEIhMzMS4xMi4yMDEzIDA4OjAwOjAwKQAAAAAAAPA/CiQIpgQQpgQiEzMxLjEyLjIwMTMgMDc6NTA6MDApAAAAAAAA8D8KJAinBBCnBCITMzEuMTIuMjAxMyAwNzo0MDowMCkAAAAAAADwPwokCKgEEKgEIhMzMS4xMi4yMDEzIDA3OjMwOjAwKQAAAAAAAPA/CiQIqQQQqQQiEzMxLjEyLjIwMTMgMDc6MjA6MDApAAAAAAAA8D8KJAiqBBCqBCITMzEuMTIuMjAxMyAwNjo1MDowMCkAAAAAAADwPwokCKsEEKsEIhMzMS4xMi4yMDEzIDA2OjQwOjAwKQAAAAAAAPA/CiQIrAQQrAQiEzMxLjEyLjIwMTMgMDY6MDA6MDApAAAAAAAA8D8KJAitBBCtBCITMzEuMTIuMjAxMyAwNTo1MDowMCkAAAAAAADwPwokCK4EEK4EIhMzMS4xMi4yMDEzIDA1OjQwOjAwKQAAAAAAAPA/CiQIrwQQrwQiEzMxLjEyLjIwMTMgMDU6MjA6MDApAAAAAAAA8D8KJAiwBBCwBCITMzEuMTIuMjAxMyAwNTowMDowMCkAAAAAAADwPwokCLEEELEEIhMzMS4xMi4yMDEzIDA0OjQwOjAwKQAAAAAAAPA/CiQIsgQQsgQiEzMxLjEyLjIwMTMgMDQ6MzA6MDApAAAAAAAA8D8KJAizBBCzBCITMzEuMTIuMjAxMyAwNDoyMDowMCkAAAAAAADwPwokCLQEELQEIhMzMS4xMi4yMDEzIDA0OjEwOjAwKQAAAAAAAPA/CiQItQQQtQQiEzMxLjEyLjIwMTMgMDQ6MDA6MDApAAAAAAAA8D8KJAi2BBC2BCITMzEuMTIuMjAxMyAwMzo1MDowMCkAAAAAAADwPwokCLcEELcEIhMzMS4xMi4yMDEzIDAzOjQwOjAwKQAAAAAAAPA/CiQIuAQQuAQiEzMxLjEyLjIwMTMgMDM6MzA6MDApAAAAAAAA8D8KJAi5BBC5BCITMzEuMTIuMjAxMyAwMzoyMDowMCkAAAAAAADwPwokCLoEELoEIhMzMS4xMi4yMDEzIDAzOjAwOjAwKQAAAAAAAPA/CiQIuwQQuwQiEzMxLjEyLjIwMTMgMDI6NTA6MDApAAAAAAAA8D8KJAi8BBC8BCITMzEuMTIuMjAxMyAwMjo0MDowMCkAAAAAAADwPwokCL0EEL0EIhMzMS4xMi4yMDEzIDAyOjIwOjAwKQAAAAAAAPA/CiQIvgQQvgQiEzMxLjEyLjIwMTMgMDE6NTA6MDApAAAAAAAA8D8KJAi/BBC/BCITMzEuMTIuMjAxMyAwMTo0MDowMCkAAAAAAADwPwokCMAEEMAEIhMzMS4xMi4yMDEzIDAxOjMwOjAwKQAAAAAAAPA/CiQIwQQQwQQiEzMxLjEyLjIwMTMgMDE6MjA6MDApAAAAAAAA8D8KJAjCBBDCBCITMzEuMTIuMjAxMyAwMTowMDowMCkAAAAAAADwPwokCMMEEMMEIhMzMS4xMi4yMDEzIDAwOjUwOjAwKQAAAAAAAPA/CiQIxAQQxAQiEzMxLjEyLjIwMTMgMDA6NDA6MDApAAAAAAAA8D8KJAjFBBDFBCITMzEuMTIuMjAxMyAwMDozMDowMCkAAAAAAADwPwokCMYEEMYEIhMzMS4xMi4yMDEzIDAwOjEwOjAwKQAAAAAAAPA/CiQIxwQQxwQiEzMxLjEyLjIwMTMgMDA6MDA6MDApAAAAAAAA8D8KJAjIBBDIBCITMzEuMTIuMjAxMiAyMzo1MDowMCkAAAAAAADwPwokCMkEEMkEIhMzMS4xMi4yMDEyIDIzOjMwOjAwKQAAAAAAAPA/CiQIygQQygQiEzMxLjEyLjIwMTIgMjM6MTA6MDApAAAAAAAA8D8KJAjLBBDLBCITMzEuMTIuMjAxMiAyMjo1MDowMCkAAAAAAADwPwokCMwEEMwEIhMzMS4xMi4yMDEyIDIyOjQwOjAwKQAAAAAAAPA/CiQIzQQQzQQiEzMxLjEyLjIwMTIgMjI6MzA6MDApAAAAAAAA8D8KJAjOBBDOBCITMzEuMTIuMjAxMiAyMjoyMDowMCkAAAAAAADwPwokCM8EEM8EIhMzMS4xMi4yMDEyIDIyOjEwOjAwKQAAAAAAAPA/CiQI0AQQ0AQiEzMxLjEyLjIwMTIgMjE6NDA6MDApAAAAAAAA8D8KJAjRBBDRBCITMzEuMTIuMjAxMiAyMToxMDowMCkAAAAAAADwPwokCNIEENIEIhMzMS4xMi4yMDEyIDIwOjUwOjAwKQAAAAAAAPA/CiQI0wQQ0wQiEzMxLjEyLjIwMTIgMjA6NDA6MDApAAAAAAAA8D8KJAjUBBDUBCITMzEuMTIuMjAxMiAyMDoyMDowMCkAAAAAAADwPwokCNUEENUEIhMzMS4xMi4yMDEyIDIwOjEwOjAwKQAAAAAAAPA/CiQI1gQQ1gQiEzMxLjEyLjIwMTIgMTk6NTA6MDApAAAAAAAA8D8KJAjXBBDXBCITMzEuMTIuMjAxMiAxOTo0MDowMCkAAAAAAADwPwokCNgEENgEIhMzMS4xMi4yMDEyIDE5OjIwOjAwKQAAAAAAAPA/CiQI2QQQ2QQiEzMxLjEyLjIwMTIgMTk6MTA6MDApAAAAAAAA8D8KJAjaBBDaBCITMzEuMTIuMjAxMiAxOTowMDowMCkAAAAAAADwPwokCNsEENsEIhMzMS4xMi4yMDEyIDE4OjUwOjAwKQAAAAAAAPA/CiQI3AQQ3AQiEzMxLjEyLjIwMTIgMTg6NDA6MDApAAAAAAAA8D8KJAjdBBDdBCITMzEuMTIuMjAxMiAxODozMDowMCkAAAAAAADwPwokCN4EEN4EIhMzMS4xMi4yMDEyIDE4OjIwOjAwKQAAAAAAAPA/CiQI3wQQ3wQiEzMxLjEyLjIwMTIgMTg6MDA6MDApAAAAAAAA8D8KJAjgBBDgBCITMzEuMTIuMjAxMiAxNzozMDowMCkAAAAAAADwPwokCOEEEOEEIhMzMS4xMi4yMDEyIDE3OjIwOjAwKQAAAAAAAPA/CiQI4gQQ4gQiEzMxLjEyLjIwMTIgMTY6MjA6MDApAAAAAAAA8D8KJAjjBBDjBCITMzEuMTIuMjAxMiAxNjoxMDowMCkAAAAAAADwPwokCOQEEOQEIhMzMS4xMi4yMDEyIDE2OjAwOjAwKQAAAAAAAPA/CiQI5QQQ5QQiEzMxLjEyLjIwMTIgMTU6NTA6MDApAAAAAAAA8D8KJAjmBBDmBCITMzEuMTIuMjAxMiAxNToyMDowMCkAAAAAAADwPwokCOcEEOcEIhMzMS4xMi4yMDEyIDE1OjEwOjAwKQAAAAAAAPA/CiQI6AQQ6AQiEzMxLjEyLjIwMTIgMTQ6NTA6MDApAAAAAAAA8D8KJAjpBBDpBCITMzEuMTIuMjAxMiAxNDoyMDowMCkAAAAAAADwPwokCOoEEOoEIhMzMS4xMi4yMDEyIDE0OjEwOjAwKQAAAAAAAPA/CiQI6wQQ6wQiEzMxLjEyLjIwMTIgMTQ6MDA6MDApAAAAAAAA8D8KJAjsBBDsBCITMzEuMTIuMjAxMiAxMzo1MDowMCkAAAAAAADwPwokCO0EEO0EIhMzMS4xMi4yMDEyIDEzOjMwOjAwKQAAAAAAAPA/CiQI7gQQ7gQiEzMxLjEyLjIwMTIgMTM6MTA6MDApAAAAAAAA8D8KJAjvBBDvBCITMzEuMTIuMjAxMiAxMzowMDowMCkAAAAAAADwPwokCPAEEPAEIhMzMS4xMi4yMDEyIDEyOjUwOjAwKQAAAAAAAPA/CiQI8QQQ8QQiEzMxLjEyLjIwMTIgMTI6NDA6MDApAAAAAAAA8D8KJAjyBBDyBCITMzEuMTIuMjAxMiAxMjoyMDowMCkAAAAAAADwPwokCPMEEPMEIhMzMS4xMi4yMDEyIDEyOjAwOjAwKQAAAAAAAPA/CiQI9AQQ9AQiEzMxLjEyLjIwMTIgMTE6NTA6MDApAAAAAAAA8D8KJAj1BBD1BCITMzEuMTIuMjAxMiAxMTo0MDowMCkAAAAAAADwPwokCPYEEPYEIhMzMS4xMi4yMDEyIDExOjMwOjAwKQAAAAAAAPA/CiQI9wQQ9wQiEzMxLjEyLjIwMTIgMTE6MjA6MDApAAAAAAAA8D8KJAj4BBD4BCITMzEuMTIuMjAxMiAxMToxMDowMCkAAAAAAADwPwokCPkEEPkEIhMzMS4xMi4yMDEyIDEwOjUwOjAwKQAAAAAAAPA/CiQI+gQQ+gQiEzMxLjEyLjIwMTIgMTA6NDA6MDApAAAAAAAA8D8KJAj7BBD7BCITMzEuMTIuMjAxMiAxMDozMDowMCkAAAAAAADwPwokCPwEEPwEIhMzMS4xMi4yMDEyIDEwOjIwOjAwKQAAAAAAAPA/CiQI/QQQ/QQiEzMxLjEyLjIwMTIgMTA6MDA6MDApAAAAAAAA8D8KJAj+BBD+BCITMzEuMTIuMjAxMiAwOToxMDowMCkAAAAAAADwPwokCP8EEP8EIhMzMS4xMi4yMDEyIDA5OjAwOjAwKQAAAAAAAPA/CiQIgAUQgAUiEzMxLjEyLjIwMTIgMDg6NTA6MDApAAAAAAAA8D8KJAiBBRCBBSITMzEuMTIuMjAxMiAwODo0MDowMCkAAAAAAADwPwokCIIFEIIFIhMzMS4xMi4yMDEyIDA4OjIwOjAwKQAAAAAAAPA/CiQIgwUQgwUiEzMxLjEyLjIwMTIgMDg6MTA6MDApAAAAAAAA8D8KJAiEBRCEBSITMzEuMTIuMjAxMiAwODowMDowMCkAAAAAAADwPwokCIUFEIUFIhMzMS4xMi4yMDEyIDA3OjUwOjAwKQAAAAAAAPA/CiQIhgUQhgUiEzMxLjEyLjIwMTIgMDc6MjA6MDApAAAAAAAA8D8KJAiHBRCHBSITMzEuMTIuMjAxMiAwNzoxMDowMCkAAAAAAADwPwokCIgFEIgFIhMzMS4xMi4yMDEyIDA3OjAwOjAwKQAAAAAAAPA/CiQIiQUQiQUiEzMxLjEyLjIwMTIgMDY6NDA6MDApAAAAAAAA8D8KJAiKBRCKBSITMzEuMTIuMjAxMiAwNjozMDowMCkAAAAAAADwPwokCIsFEIsFIhMzMS4xMi4yMDEyIDA2OjIwOjAwKQAAAAAAAPA/CiQIjAUQjAUiEzMxLjEyLjIwMTIgMDY6MTA6MDApAAAAAAAA8D8KJAiNBRCNBSITMzEuMTIuMjAxMiAwNjowMDowMCkAAAAAAADwPwokCI4FEI4FIhMzMS4xMi4yMDEyIDA1OjQwOjAwKQAAAAAAAPA/CiQIjwUQjwUiEzMxLjEyLjIwMTIgMDU6MzA6MDApAAAAAAAA8D8KJAiQBRCQBSITMzEuMTIuMjAxMiAwNToyMDowMCkAAAAAAADwPwokCJEFEJEFIhMzMS4xMi4yMDEyIDA1OjEwOjAwKQAAAAAAAPA/CiQIkgUQkgUiEzMxLjEyLjIwMTIgMDU6MDA6MDApAAAAAAAA8D8KJAiTBRCTBSITMzEuMTIuMjAxMiAwNDo1MDowMCkAAAAAAADwPwokCJQFEJQFIhMzMS4xMi4yMDEyIDA0OjQwOjAwKQAAAAAAAPA/CiQIlQUQlQUiEzMxLjEyLjIwMTIgMDQ6MjA6MDApAAAAAAAA8D8KJAiWBRCWBSITMzEuMTIuMjAxMiAwNDowMDowMCkAAAAAAADwPwokCJcFEJcFIhMzMS4xMi4yMDEyIDAzOjMwOjAwKQAAAAAAAPA/CiQImAUQmAUiEzMxLjEyLjIwMTIgMDM6MTA6MDApAAAAAAAA8D8KJAiZBRCZBSITMzEuMTIuMjAxMiAwMzowMDowMCkAAAAAAADwPwokCJoFEJoFIhMzMS4xMi4yMDEyIDAyOjQwOjAwKQAAAAAAAPA/CiQImwUQmwUiEzMxLjEyLjIwMTIgMDI6MjA6MDApAAAAAAAA8D8KJAicBRCcBSITMzEuMTIuMjAxMiAwMjoxMDowMCkAAAAAAADwPwokCJ0FEJ0FIhMzMS4xMi4yMDEyIDAyOjAwOjAwKQAAAAAAAPA/CiQIngUQngUiEzMxLjEyLjIwMTIgMDE6NTA6MDApAAAAAAAA8D8KJAifBRCfBSITMzEuMTIuMjAxMiAwMTozMDowMCkAAAAAAADwPwokCKAFEKAFIhMzMS4xMi4yMDEyIDAxOjIwOjAwKQAAAAAAAPA/CiQIoQUQoQUiEzMxLjEyLjIwMTIgMDE6MTA6MDApAAAAAAAA8D8KJAiiBRCiBSITMzEuMTIuMjAxMiAwMTowMDowMCkAAAAAAADwPwokCKMFEKMFIhMzMS4xMi4yMDEyIDAwOjUwOjAwKQAAAAAAAPA/CiQIpAUQpAUiEzMxLjEyLjIwMTIgMDA6NDA6MDApAAAAAAAA8D8KJAilBRClBSITMzEuMTIuMjAxMiAwMDozMDowMCkAAAAAAADwPwokCKYFEKYFIhMzMS4xMi4yMDEyIDAwOjIwOjAwKQAAAAAAAPA/CiQIpwUQpwUiEzMxLjEyLjIwMTIgMDA6MTA6MDApAAAAAAAA8D8KJAioBRCoBSITMzEuMTIuMjAxMiAwMDowMDowMCkAAAAAAADwPwokCKkFEKkFIhMzMS4xMi4yMDExIDIzOjUwOjAwKQAAAAAAAPA/CiQIqgUQqgUiEzMxLjEyLjIwMTEgMjM6MjA6MDApAAAAAAAA8D8KJAirBRCrBSITMzEuMTIuMjAxMSAyMzoxMDowMCkAAAAAAADwPwokCKwFEKwFIhMzMS4xMi4yMDExIDIzOjAwOjAwKQAAAAAAAPA/CiQIrQUQrQUiEzMxLjEyLjIwMTEgMjI6NTA6MDApAAAAAAAA8D8KJAiuBRCuBSITMzEuMTIuMjAxMSAyMjozMDowMCkAAAAAAADwPwokCK8FEK8FIhMzMS4xMi4yMDExIDIyOjIwOjAwKQAAAAAAAPA/CiQIsAUQsAUiEzMxLjEyLjIwMTEgMjI6MTA6MDApAAAAAAAA8D8KJAixBRCxBSITMzEuMTIuMjAxMSAyMjowMDowMCkAAAAAAADwPwokCLIFELIFIhMzMS4xMi4yMDExIDIxOjUwOjAwKQAAAAAAAPA/CiQIswUQswUiEzMxLjEyLjIwMTEgMjE6MzA6MDApAAAAAAAA8D8KJAi0BRC0BSITMzEuMTIuMjAxMSAyMToyMDowMCkAAAAAAADwPwokCLUFELUFIhMzMS4xMi4yMDExIDIxOjEwOjAwKQAAAAAAAPA/CiQItgUQtgUiEzMxLjEyLjIwMTEgMjE6MDA6MDApAAAAAAAA8D8KJAi3BRC3BSITMzEuMTIuMjAxMSAyMDo1MDowMCkAAAAAAADwPwokCLgFELgFIhMzMS4xMi4yMDExIDIwOjQwOjAwKQAAAAAAAPA/CiQIuQUQuQUiEzMxLjEyLjIwMTEgMjA6MzA6MDApAAAAAAAA8D8KJAi6BRC6BSITMzEuMTIuMjAxMSAyMDoxMDowMCkAAAAAAADwPwokCLsFELsFIhMzMS4xMi4yMDExIDIwOjAwOjAwKQAAAAAAAPA/CiQIvAUQvAUiEzMxLjEyLjIwMTEgMTk6NDA6MDApAAAAAAAA8D8KJAi9BRC9BSITMzEuMTIuMjAxMSAxOToyMDowMCkAAAAAAADwPwokCL4FEL4FIhMzMS4xMi4yMDExIDE5OjEwOjAwKQAAAAAAAPA/CiQIvwUQvwUiEzMxLjEyLjIwMTEgMTk6MDA6MDApAAAAAAAA8D8KJAjABRDABSITMzEuMTIuMjAxMSAxODoyMDowMCkAAAAAAADwPwokCMEFEMEFIhMzMS4xMi4yMDExIDE4OjEwOjAwKQAAAAAAAPA/CiQIwgUQwgUiEzMxLjEyLjIwMTEgMTg6MDA6MDApAAAAAAAA8D8KJAjDBRDDBSITMzEuMTIuMjAxMSAxNzo0MDowMCkAAAAAAADwPwokCMQFEMQFIhMzMS4xMi4yMDExIDE3OjIwOjAwKQAAAAAAAPA/CiQIxQUQxQUiEzMxLjEyLjIwMTEgMTc6MTA6MDApAAAAAAAA8D8KJAjGBRDGBSITMzEuMTIuMjAxMSAxNzowMDowMCkAAAAAAADwPwokCMcFEMcFIhMzMS4xMi4yMDExIDE2OjMwOjAwKQAAAAAAAPA/CiQIyAUQyAUiEzMxLjEyLjIwMTEgMTY6MjA6MDApAAAAAAAA8D8KJAjJBRDJBSITMzEuMTIuMjAxMSAxNjoxMDowMCkAAAAAAADwPwokCMoFEMoFIhMzMS4xMi4yMDExIDE2OjAwOjAwKQAAAAAAAPA/CiQIywUQywUiEzMxLjEyLjIwMTEgMTU6NTA6MDApAAAAAAAA8D8KJAjMBRDMBSITMzEuMTIuMjAxMSAxNTo0MDowMCkAAAAAAADwPwokCM0FEM0FIhMzMS4xMi4yMDExIDE1OjMwOjAwKQAAAAAAAPA/CiQIzgUQzgUiEzMxLjEyLjIwMTEgMTU6MjA6MDApAAAAAAAA8D8KJAjPBRDPBSITMzEuMTIuMjAxMSAxNToxMDowMCkAAAAAAADwPwokCNAFENAFIhMzMS4xMi4yMDExIDE0OjUwOjAwKQAAAAAAAPA/CiQI0QUQ0QUiEzMxLjEyLjIwMTEgMTQ6MzA6MDApAAAAAAAA8D8KJAjSBRDSBSITMzEuMTIuMjAxMSAxNDowMDowMCkAAAAAAADwPwokCNMFENMFIhMzMS4xMi4yMDExIDEzOjQwOjAwKQAAAAAAAPA/CiQI1AUQ1AUiEzMxLjEyLjIwMTEgMTM6MzA6MDApAAAAAAAA8D8KJAjVBRDVBSITMzEuMTIuMjAxMSAxMjo1MDowMCkAAAAAAADwPwokCNYFENYFIhMzMS4xMi4yMDExIDEyOjQwOjAwKQAAAAAAAPA/CiQI1wUQ1wUiEzMxLjEyLjIwMTEgMTI6MjA6MDApAAAAAAAA8D8KJAjYBRDYBSITMzEuMTIuMjAxMSAxMjoxMDowMCkAAAAAAADwPwokCNkFENkFIhMzMS4xMi4yMDExIDEyOjAwOjAwKQAAAAAAAPA/CiQI2gUQ2gUiEzMxLjEyLjIwMTEgMTE6NTA6MDApAAAAAAAA8D8KJAjbBRDbBSITMzEuMTIuMjAxMSAxMTo0MDowMCkAAAAAAADwPwokCNwFENwFIhMzMS4xMi4yMDExIDExOjMwOjAwKQAAAAAAAPA/CiQI3QUQ3QUiEzMxLjEyLjIwMTEgMTE6MTA6MDApAAAAAAAA8D8KJAjeBRDeBSITMzEuMTIuMjAxMSAxMTowMDowMCkAAAAAAADwPwokCN8FEN8FIhMzMS4xMi4yMDExIDEwOjUwOjAwKQAAAAAAAPA/CiQI4AUQ4AUiEzMxLjEyLjIwMTEgMTA6NDA6MDApAAAAAAAA8D8KJAjhBRDhBSITMzEuMTIuMjAxMSAxMDozMDowMCkAAAAAAADwPwokCOIFEOIFIhMzMS4xMi4yMDExIDEwOjEwOjAwKQAAAAAAAPA/CiQI4wUQ4wUiEzMxLjEyLjIwMTEgMTA6MDA6MDApAAAAAAAA8D8KJAjkBRDkBSITMzEuMTIuMjAxMSAwOTo0MDowMCkAAAAAAADwPwokCOUFEOUFIhMzMS4xMi4yMDExIDA5OjMwOjAwKQAAAAAAAPA/CiQI5gUQ5gUiEzMxLjEyLjIwMTEgMDg6NTA6MDApAAAAAAAA8D8KJAjnBRDnBSITMzEuMTIuMjAxMSAwODozMDowMCkAAAAAAADwPwokCOgFEOgFIhMzMS4xMi4yMDExIDA4OjIwOjAwKQAAAAAAAPA/CiQI6QUQ6QUiEzMxLjEyLjIwMTEgMDg6MTA6MDApAAAAAAAA8D8KJAjqBRDqBSITMzEuMTIuMjAxMSAwODowMDowMCkAAAAAAADwPwokCOsFEOsFIhMzMS4xMi4yMDExIDA3OjMwOjAwKQAAAAAAAPA/CiQI7AUQ7AUiEzMxLjEyLjIwMTEgMDc6MTA6MDApAAAAAAAA8D8KJAjtBRDtBSITMzEuMTIuMjAxMSAwNzowMDowMCkAAAAAAADwPwokCO4FEO4FIhMzMS4xMi4yMDExIDA2OjUwOjAwKQAAAAAAAPA/CiQI7wUQ7wUiEzMxLjEyLjIwMTEgMDY6NDA6MDApAAAAAAAA8D8KJAjwBRDwBSITMzEuMTIuMjAxMSAwNjozMDowMCkAAAAAAADwPwokCPEFEPEFIhMzMS4xMi4yMDExIDA2OjIwOjAwKQAAAAAAAPA/CiQI8gUQ8gUiEzMxLjEyLjIwMTEgMDY6MTA6MDApAAAAAAAA8D8KJAjzBRDzBSITMzEuMTIuMjAxMSAwNjowMDowMCkAAAAAAADwPwokCPQFEPQFIhMzMS4xMi4yMDExIDA1OjUwOjAwKQAAAAAAAPA/CiQI9QUQ9QUiEzMxLjEyLjIwMTEgMDU6MzA6MDApAAAAAAAA8D8KJAj2BRD2BSITMzEuMTIuMjAxMSAwNTowMDowMCkAAAAAAADwPwokCPcFEPcFIhMzMS4xMi4yMDExIDA0OjUwOjAwKQAAAAAAAPA/CiQI+AUQ+AUiEzMxLjEyLjIwMTEgMDQ6NDA6MDApAAAAAAAA8D8KJAj5BRD5BSITMzEuMTIuMjAxMSAwNDozMDowMCkAAAAAAADwPwokCPoFEPoFIhMzMS4xMi4yMDExIDA0OjIwOjAwKQAAAAAAAPA/CiQI+wUQ+wUiEzMxLjEyLjIwMTEgMDQ6MTA6MDApAAAAAAAA8D8KJAj8BRD8BSITMzEuMTIuMjAxMSAwNDowMDowMCkAAAAAAADwPwokCP0FEP0FIhMzMS4xMi4yMDExIDAzOjUwOjAwKQAAAAAAAPA/CiQI/gUQ/gUiEzMxLjEyLjIwMTEgMDM6NDA6MDApAAAAAAAA8D8KJAj/BRD/BSITMzEuMTIuMjAxMSAwMzozMDowMCkAAAAAAADwPwokCIAGEIAGIhMzMS4xMi4yMDExIDAzOjIwOjAwKQAAAAAAAPA/CiQIgQYQgQYiEzMxLjEyLjIwMTEgMDM6MTA6MDApAAAAAAAA8D8KJAiCBhCCBiITMzEuMTIuMjAxMSAwMzowMDowMCkAAAAAAADwPwokCIMGEIMGIhMzMS4xMi4yMDExIDAyOjQwOjAwKQAAAAAAAPA/CiQIhAYQhAYiEzMxLjEyLjIwMTEgMDI6MjA6MDApAAAAAAAA8D8KJAiFBhCFBiITMzEuMTIuMjAxMSAwMjoxMDowMCkAAAAAAADwPwokCIYGEIYGIhMzMS4xMi4yMDExIDAyOjAwOjAwKQAAAAAAAPA/CiQIhwYQhwYiEzMxLjEyLjIwMTEgMDE6NTA6MDApAAAAAAAA8D8KJAiIBhCIBiITMzEuMTIuMjAxMSAwMTo0MDowMCkAAAAAAADwPwokCIkGEIkGIhMzMS4xMi4yMDExIDAxOjIwOjAwKQAAAAAAAPA/CiQIigYQigYiEzMxLjEyLjIwMTEgMDE6MTA6MDApAAAAAAAA8D8KJAiLBhCLBiITMzEuMTIuMjAxMSAwMTowMDowMCkAAAAAAADwPwokCIwGEIwGIhMzMS4xMi4yMDExIDAwOjUwOjAwKQAAAAAAAPA/CiQIjQYQjQYiEzMxLjEyLjIwMTEgMDA6MzA6MDApAAAAAAAA8D8KJAiOBhCOBiITMzEuMTIuMjAxMSAwMDoyMDowMCkAAAAAAADwPwokCI8GEI8GIhMzMS4xMi4yMDExIDAwOjAwOjAwKQAAAAAAAPA/CiQIkAYQkAYiEzMxLjEyLjIwMTAgMjM6NTA6MDApAAAAAAAA8D8KJAiRBhCRBiITMzEuMTIuMjAxMCAyMzozMDowMCkAAAAAAADwPwokCJIGEJIGIhMzMS4xMi4yMDEwIDIzOjIwOjAwKQAAAAAAAPA/CiQIkwYQkwYiEzMxLjEyLjIwMTAgMjM6MTA6MDApAAAAAAAA8D8KJAiUBhCUBiITMzEuMTIuMjAxMCAyMzowMDowMCkAAAAAAADwPwokCJUGEJUGIhMzMS4xMi4yMDEwIDIyOjQwOjAwKQAAAAAAAPA/CiQIlgYQlgYiEzMxLjEyLjIwMTAgMjI6MTA6MDApAAAAAAAA8D8KJAiXBhCXBiITMzEuMTIuMjAxMCAyMjowMDowMCkAAAAAAADwPwokCJgGEJgGIhMzMS4xMi4yMDEwIDIxOjUwOjAwKQAAAAAAAPA/CiQImQYQmQYiEzMxLjEyLjIwMTAgMjE6NDA6MDApAAAAAAAA8D8KJAiaBhCaBiITMzEuMTIuMjAxMCAyMTozMDowMCkAAAAAAADwPwokCJsGEJsGIhMzMS4xMi4yMDEwIDIxOjAwOjAwKQAAAAAAAPA/CiQInAYQnAYiEzMxLjEyLjIwMTAgMjA6NTA6MDApAAAAAAAA8D8KJAidBhCdBiITMzEuMTIuMjAxMCAyMDo0MDowMCkAAAAAAADwPwokCJ4GEJ4GIhMzMS4xMi4yMDEwIDIwOjMwOjAwKQAAAAAAAPA/CiQInwYQnwYiEzMxLjEyLjIwMTAgMjA6MjA6MDApAAAAAAAA8D8KJAigBhCgBiITMzEuMTIuMjAxMCAxOTo0MDowMCkAAAAAAADwPwokCKEGEKEGIhMzMS4xMi4yMDEwIDE5OjMwOjAwKQAAAAAAAPA/CiQIogYQogYiEzMxLjEyLjIwMTAgMTk6MDA6MDApAAAAAAAA8D8KJAijBhCjBiITMzEuMTIuMjAxMCAxODo1MDowMCkAAAAAAADwPwokCKQGEKQGIhMzMS4xMi4yMDEwIDE4OjQwOjAwKQAAAAAAAPA/CiQIpQYQpQYiEzMxLjEyLjIwMTAgMTg6MDA6MDApAAAAAAAA8D8KJAimBhCmBiITMzEuMTIuMjAxMCAxNzo1MDowMCkAAAAAAADwPwokCKcGEKcGIhMzMS4xMi4yMDEwIDE3OjQwOjAwKQAAAAAAAPA/CiQIqAYQqAYiEzMxLjEyLjIwMTAgMTc6MjA6MDApAAAAAAAA8D8KJAipBhCpBiITMzEuMTIuMjAxMCAxNzowMDowMCkAAAAAAADwPwokCKoGEKoGIhMzMS4xMi4yMDEwIDE2OjQwOjAwKQAAAAAAAPA/CiQIqwYQqwYiEzMxLjEyLjIwMTAgMTY6MjA6MDApAAAAAAAA8D8KJAisBhCsBiITMzEuMTIuMjAxMCAxNjoxMDowMCkAAAAAAADwPwokCK0GEK0GIhMzMS4xMi4yMDEwIDE2OjAwOjAwKQAAAAAAAPA/CiQIrgYQrgYiEzMxLjEyLjIwMTAgMTU6NTA6MDApAAAAAAAA8D8KJAivBhCvBiITMzEuMTIuMjAxMCAxNTo0MDowMCkAAAAAAADwPwokCLAGELAGIhMzMS4xMi4yMDEwIDE1OjMwOjAwKQAAAAAAAPA/CiQIsQYQsQYiEzMxLjEyLjIwMTAgMTU6MjA6MDApAAAAAAAA8D8KJAiyBhCyBiITMzEuMTIuMjAxMCAxNToxMDowMCkAAAAAAADwPwokCLMGELMGIhMzMS4xMi4yMDEwIDE1OjAwOjAwKQAAAAAAAPA/CiQItAYQtAYiEzMxLjEyLjIwMTAgMTQ6NTA6MDApAAAAAAAA8D8KJAi1BhC1BiITMzEuMTIuMjAxMCAxNDozMDowMCkAAAAAAADwPwokCLYGELYGIhMzMS4xMi4yMDEwIDE0OjIwOjAwKQAAAAAAAPA/CiQItwYQtwYiEzMxLjEyLjIwMTAgMTQ6MTA6MDApAAAAAAAA8D8KJAi4BhC4BiITMzEuMTIuMjAxMCAxNDowMDowMCkAAAAAAADwPwokCLkGELkGIhMzMS4xMi4yMDEwIDEzOjUwOjAwKQAAAAAAAPA/CiQIugYQugYiEzMxLjEyLjIwMTAgMTM6NDA6MDApAAAAAAAA8D8KJAi7BhC7BiITMzEuMTIuMjAxMCAxMzoxMDowMCkAAAAAAADwPwokCLwGELwGIhMzMS4xMi4yMDEwIDEzOjAwOjAwKQAAAAAAAPA/CiQIvQYQvQYiEzMxLjEyLjIwMTAgMTI6NTA6MDApAAAAAAAA8D8KJAi+BhC+BiITMzEuMTIuMjAxMCAxMjo0MDowMCkAAAAAAADwPwokCL8GEL8GIhMzMS4xMi4yMDEwIDEyOjMwOjAwKQAAAAAAAPA/CiQIwAYQwAYiEzMxLjEyLjIwMTAgMTI6MjA6MDApAAAAAAAA8D8KJAjBBhDBBiITMzEuMTIuMjAxMCAxMTozMDowMCkAAAAAAADwPwokCMIGEMIGIhMzMS4xMi4yMDEwIDExOjIwOjAwKQAAAAAAAPA/CiQIwwYQwwYiEzMxLjEyLjIwMTAgMTE6MTA6MDApAAAAAAAA8D8KJAjEBhDEBiITMzEuMTIuMjAxMCAxMTowMDowMCkAAAAAAADwPwokCMUGEMUGIhMzMS4xMi4yMDEwIDEwOjUwOjAwKQAAAAAAAPA/CiQIxgYQxgYiEzMxLjEyLjIwMTAgMTA6NDA6MDApAAAAAAAA8D8KJAjHBhDHBiITMzEuMTIuMjAxMCAxMDozMDowMCkAAAAAAADwPwokCMgGEMgGIhMzMS4xMi4yMDEwIDEwOjIwOjAwKQAAAAAAAPA/CiQIyQYQyQYiEzMxLjEyLjIwMTAgMTA6MTA6MDApAAAAAAAA8D8KJAjKBhDKBiITMzEuMTIuMjAxMCAwOTo1MDowMCkAAAAAAADwPwokCMsGEMsGIhMzMS4xMi4yMDEwIDA5OjMwOjAwKQAAAAAAAPA/CiQIzAYQzAYiEzMxLjEyLjIwMTAgMDk6MjA6MDApAAAAAAAA8D8KJAjNBhDNBiITMzEuMTIuMjAxMCAwODo1MDowMCkAAAAAAADwPwokCM4GEM4GIhMzMS4xMi4yMDEwIDA4OjQwOjAwKQAAAAAAAPA/CiQIzwYQzwYiEzMxLjEyLjIwMTAgMDg6MzA6MDApAAAAAAAA8D8KJAjQBhDQBiITMzEuMTIuMjAxMCAwODoxMDowMCkAAAAAAADwPwokCNEGENEGIhMzMS4xMi4yMDEwIDA4OjAwOjAwKQAAAAAAAPA/CiQI0gYQ0gYiEzMxLjEyLjIwMTAgMDc6NTA6MDApAAAAAAAA8D8KJAjTBhDTBiITMzEuMTIuMjAxMCAwNzo0MDowMCkAAAAAAADwPwokCNQGENQGIhMzMS4xMi4yMDEwIDA3OjEwOjAwKQAAAAAAAPA/CiQI1QYQ1QYiEzMxLjEyLjIwMTAgMDc6MDA6MDApAAAAAAAA8D8KJAjWBhDWBiITMzEuMTIuMjAxMCAwNjo0MDowMCkAAAAAAADwPwokCNcGENcGIhMzMS4xMi4yMDEwIDA2OjMwOjAwKQAAAAAAAPA/CiQI2AYQ2AYiEzMxLjEyLjIwMTAgMDY6MTA6MDApAAAAAAAA8D8KJAjZBhDZBiITMzEuMTIuMjAxMCAwNjowMDowMCkAAAAAAADwPwokCNoGENoGIhMzMS4xMi4yMDEwIDA1OjUwOjAwKQAAAAAAAPA/CiQI2wYQ2wYiEzMxLjEyLjIwMTAgMDU6MjA6MDApAAAAAAAA8D8KJAjcBhDcBiITMzEuMTIuMjAxMCAwNToxMDowMCkAAAAAAADwPwokCN0GEN0GIhMzMS4xMi4yMDEwIDA0OjUwOjAwKQAAAAAAAPA/CiQI3gYQ3gYiEzMxLjEyLjIwMTAgMDQ6MzA6MDApAAAAAAAA8D8KJAjfBhDfBiITMzEuMTIuMjAxMCAwNDowMDowMCkAAAAAAADwPwokCOAGEOAGIhMzMS4xMi4yMDEwIDAzOjQwOjAwKQAAAAAAAPA/CiQI4QYQ4QYiEzMxLjEyLjIwMTAgMDM6MzA6MDApAAAAAAAA8D8KJAjiBhDiBiITMzEuMTIuMjAxMCAwMjo1MDowMCkAAAAAAADwPwokCOMGEOMGIhMzMS4xMi4yMDEwIDAyOjQwOjAwKQAAAAAAAPA/CiQI5AYQ5AYiEzMxLjEyLjIwMTAgMDI6MzA6MDApAAAAAAAA8D8KJAjlBhDlBiITMzEuMTIuMjAxMCAwMjoyMDowMCkAAAAAAADwPwokCOYGEOYGIhMzMS4xMi4yMDEwIDAyOjAwOjAwKQAAAAAAAPA/CiQI5wYQ5wYiEzMxLjEyLjIwMTAgMDE6NDA6MDApAAAAAAAA8D8KJAjoBhDoBiITMzEuMTIuMjAxMCAwMToxMDowMCkAAAAAAADwPwokCOkGEOkGIhMzMS4xMi4yMDEwIDAxOjAwOjAwKQAAAAAAAPA/CiQI6gYQ6gYiEzMxLjEyLjIwMTAgMDA6NTA6MDApAAAAAAAA8D8KJAjrBhDrBiITMzEuMTIuMjAxMCAwMDo0MDowMCkAAAAAAADwPwokCOwGEOwGIhMzMS4xMi4yMDEwIDAwOjMwOjAwKQAAAAAAAPA/CiQI7QYQ7QYiEzMxLjEyLjIwMTAgMDA6MjA6MDApAAAAAAAA8D8KJAjuBhDuBiITMzEuMTIuMjAxMCAwMDoxMDowMCkAAAAAAADwPwokCO8GEO8GIhMzMS4xMi4yMDEwIDAwOjAwOjAwKQAAAAAAAPA/CiQI8AYQ8AYiEzMxLjEyLjIwMDkgMjM6NTA6MDApAAAAAAAA8D8KJAjxBhDxBiITMzEuMTIuMjAwOSAyMzozMDowMCkAAAAAAADwPwokCPIGEPIGIhMzMS4xMi4yMDA5IDIzOjIwOjAwKQAAAAAAAPA/CiQI8wYQ8wYiEzMxLjEyLjIwMDkgMjM6MDA6MDApAAAAAAAA8D8KJAj0BhD0BiITMzEuMTIuMjAwOSAyMjo1MDowMCkAAAAAAADwPwokCPUGEPUGIhMzMS4xMi4yMDA5IDIyOjQwOjAwKQAAAAAAAPA/CiQI9gYQ9gYiEzMxLjEyLjIwMDkgMjI6MzA6MDApAAAAAAAA8D8KJAj3BhD3BiITMzEuMTIuMjAwOSAyMjoxMDowMCkAAAAAAADwPwokCPgGEPgGIhMzMS4xMi4yMDA5IDIxOjUwOjAwKQAAAAAAAPA/CiQI+QYQ+QYiEzMxLjEyLjIwMDkgMjE6NDA6MDApAAAAAAAA8D8KJAj6BhD6BiITMzEuMTIuMjAwOSAyMTozMDowMCkAAAAAAADwPwokCPsGEPsGIhMzMS4xMi4yMDA5IDIxOjIwOjAwKQAAAAAAAPA/CiQI/AYQ/AYiEzMxLjEyLjIwMDkgMjE6MTA6MDApAAAAAAAA8D8KJAj9BhD9BiITMzEuMTIuMjAwOSAyMTowMDowMCkAAAAAAADwPwokCP4GEP4GIhMzMS4xMi4yMDA5IDIwOjQwOjAwKQAAAAAAAPA/CiQI/wYQ/wYiEzMxLjEyLjIwMDkgMjA6MzA6MDApAAAAAAAA8D8KJAiABxCAByITMzEuMTIuMjAwOSAyMDoyMDowMCkAAAAAAADwPwokCIEHEIEHIhMzMS4xMi4yMDA5IDIwOjAwOjAwKQAAAAAAAPA/CiQIggcQggciEzMxLjEyLjIwMDkgMTk6NDA6MDApAAAAAAAA8D8KJAiDBxCDByITMzEuMTIuMjAwOSAxOTozMDowMCkAAAAAAADwPwokCIQHEIQHIhMzMS4xMi4yMDA5IDE5OjIwOjAwKQAAAAAAAPA/CiQIhQcQhQciEzMxLjEyLjIwMDkgMTk6MTA6MDApAAAAAAAA8D8KJAiGBxCGByITMzEuMTIuMjAwOSAxODo1MDowMCkAAAAAAADwPwokCIcHEIcHIhMzMS4xMi4yMDA5IDE4OjQwOjAwKQAAAAAAAPA/CiQIiAcQiAciEzMxLjEyLjIwMDkgMTg6MzA6MDApAAAAAAAA8D8KJAiJBxCJByITMzEuMTIuMjAwOSAxODoyMDowMCkAAAAAAADwPwokCIoHEIoHIhMzMS4xMi4yMDA5IDE4OjAwOjAwKQAAAAAAAPA/CiQIiwcQiwciEzMxLjEyLjIwMDkgMTc6NTA6MDApAAAAAAAA8D8KJAiMBxCMByITMzEuMTIuMjAwOSAxNzo0MDowMCkAAAAAAADwPwokCI0HEI0HIhMzMS4xMi4yMDA5IDE3OjMwOjAwKQAAAAAAAPA/CiQIjgcQjgciEzMxLjEyLjIwMDkgMTc6MjA6MDApAAAAAAAA8D8KJAiPBxCPByITMzEuMTIuMjAwOSAxNzoxMDowMCkAAAAAAADwPwokCJAHEJAHIhMzMS4xMi4yMDA5IDE3OjAwOjAwKQAAAAAAAPA/CiQIkQcQkQciEzMxLjEyLjIwMDkgMTY6NDA6MDApAAAAAAAA8D8KJAiSBxCSByITMzEuMTIuMjAwOSAxNjozMDowMCkAAAAAAADwPwokCJMHEJMHIhMzMS4xMi4yMDA5IDE2OjIwOjAwKQAAAAAAAPA/CiQIlAcQlAciEzMxLjEyLjIwMDkgMTY6MTA6MDApAAAAAAAA8D8KJAiVBxCVByITMzEuMTIuMjAwOSAxNjowMDowMCkAAAAAAADwPwokCJYHEJYHIhMzMS4xMi4yMDA5IDE1OjUwOjAwKQAAAAAAAPA/CiQIlwcQlwciEzMxLjEyLjIwMDkgMTU6NDA6MDApAAAAAAAA8D8KJAiYBxCYByITMzEuMTIuMjAwOSAxNToyMDowMCkAAAAAAADwPwokCJkHEJkHIhMzMS4xMi4yMDA5IDE1OjEwOjAwKQAAAAAAAPA/CiQImgcQmgciEzMxLjEyLjIwMDkgMTU6MDA6MDApAAAAAAAA8D8KJAibBxCbByITMzEuMTIuMjAwOSAxNDo1MDowMCkAAAAAAADwPwokCJwHEJwHIhMzMS4xMi4yMDA5IDE0OjIwOjAwKQAAAAAAAPA/CiQInQcQnQciEzMxLjEyLjIwMDkgMTQ6MTA6MDApAAAAAAAA8D8KJAieBxCeByITMzEuMTIuMjAwOSAxMzo1MDowMCkAAAAAAADwPwokCJ8HEJ8HIhMzMS4xMi4yMDA5IDEzOjQwOjAwKQAAAAAAAPA/CiQIoAcQoAciEzMxLjEyLjIwMDkgMTM6MTA6MDApAAAAAAAA8D8KJAihBxChByITMzEuMTIuMjAwOSAxMjo1MDowMCkAAAAAAADwPwokCKIHEKIHIhMzMS4xMi4yMDA5IDEyOjQwOjAwKQAAAAAAAPA/CiQIowcQowciEzMxLjEyLjIwMDkgMTI6MzA6MDApAAAAAAAA8D8KJAikBxCkByITMzEuMTIuMjAwOSAxMjoyMDowMCkAAAAAAADwPwokCKUHEKUHIhMzMS4xMi4yMDA5IDEyOjAwOjAwKQAAAAAAAPA/CiQIpgcQpgciEzMxLjEyLjIwMDkgMTE6NTA6MDApAAAAAAAA8D8KJAinBxCnByITMzEuMTIuMjAwOSAxMTo0MDowMCkAAAAAAADwPwokCKgHEKgHIhMzMS4xMi4yMDA5IDExOjMwOjAwKQAAAAAAAPA/CiQIqQcQqQciEzMxLjEyLjIwMDkgMTE6MjA6MDApAAAAAAAA8D8KJAiqBxCqByITMzEuMTIuMjAwOSAxMToxMDowMCkAAAAAAADwPwokCKsHEKsHIhMzMS4xMi4yMDA5IDEwOjUwOjAwKQAAAAAAAPA/CiQIrAcQrAciEzMxLjEyLjIwMDkgMTA6NDA6MDApAAAAAAAA8D8KJAitBxCtByITMzEuMTIuMjAwOSAxMDozMDowMCkAAAAAAADwPwokCK4HEK4HIhMzMS4xMi4yMDA5IDEwOjIwOjAwKQAAAAAAAPA/CiQIrwcQrwciEzMxLjEyLjIwMDkgMTA6MDA6MDApAAAAAAAA8D8KJAiwBxCwByITMzEuMTIuMjAwOSAwOTo0MDowMCkAAAAAAADwPwokCLEHELEHIhMzMS4xMi4yMDA5IDA5OjMwOjAwKQAAAAAAAPA/CiQIsgcQsgciEzMxLjEyLjIwMDkgMDk6MjA6MDApAAAAAAAA8D8KJAizBxCzByITMzEuMTIuMjAwOSAwOToxMDowMCkAAAAAAADwPwokCLQHELQHIhMzMS4xMi4yMDA5IDA5OjAwOjAwKQAAAAAAAPA/CiQItQcQtQciEzMxLjEyLjIwMDkgMDg6NTA6MDApAAAAAAAA8D8KJAi2BxC2ByITMzEuMTIuMjAwOSAwODozMDowMCkAAAAAAADwPwokCLcHELcHIhMzMS4xMi4yMDA5IDA4OjIwOjAwKQAAAAAAAPA/CiQIuAcQuAciEzMxLjEyLjIwMDkgMDg6MTA6MDApAAAAAAAA8D8KJAi5BxC5ByITMzEuMTIuMjAwOSAwNzo0MDowMCkAAAAAAADwPwokCLoHELoHIhMzMS4xMi4yMDA5IDA3OjMwOjAwKQAAAAAAAPA/CiQIuwcQuwciEzMxLjEyLjIwMDkgMDc6MjA6MDApAAAAAAAA8D8KJAi8BxC8ByITMzEuMTIuMjAwOSAwNzoxMDowMCkAAAAAAADwPwokCL0HEL0HIhMzMS4xMi4yMDA5IDA2OjUwOjAwKQAAAAAAAPA/CiQIvgcQvgciEzMxLjEyLjIwMDkgMDY6NDA6MDApAAAAAAAA8D8KJAi/BxC/ByITMzEuMTIuMjAwOSAwNjozMDowMCkAAAAAAADwPwokCMAHEMAHIhMzMS4xMi4yMDA5IDA2OjIwOjAwKQAAAAAAAPA/CiQIwQcQwQciEzMxLjEyLjIwMDkgMDY6MTA6MDApAAAAAAAA8D8KJAjCBxDCByITMzEuMTIuMjAwOSAwNjowMDowMCkAAAAAAADwPwokCMMHEMMHIhMzMS4xMi4yMDA5IDA1OjUwOjAwKQAAAAAAAPA/CiQIxAcQxAciEzMxLjEyLjIwMDkgMDU6MzA6MDApAAAAAAAA8D8KJAjFBxDFByITMzEuMTIuMjAwOSAwNToyMDowMCkAAAAAAADwPwokCMYHEMYHIhMzMS4xMi4yMDA5IDA1OjEwOjAwKQAAAAAAAPA/CiQIxwcQxwciEzMxLjEyLjIwMDkgMDQ6NDA6MDApAAAAAAAA8D8KJAjIBxDIByITMzEuMTIuMjAwOSAwNDozMDowMCkAAAAAAADwPwokCMkHEMkHIhMzMS4xMi4yMDA5IDA0OjIwOjAwKQAAAAAAAPA/CiQIygcQygciEzMxLjEyLjIwMDkgMDM6NTA6MDApAAAAAAAA8D8KJAjLBxDLByITMzEuMTIuMjAwOSAwMzo0MDowMCkAAAAAAADwPwokCMwHEMwHIhMzMS4xMi4yMDA5IDAzOjMwOjAwKQAAAAAAAPA/CiQIzQcQzQciEzMxLjEyLjIwMDkgMDM6MjA6MDApAAAAAAAA8D8KJAjOBxDOByITMzEuMTIuMjAwOSAwMzoxMDowMCkAAAAAAADwPwokCM8HEM8HIhMzMS4xMi4yMDA5IDAzOjAwOjAwKQAAAAAAAPA/CiQI0AcQ0AciEzMxLjEyLjIwMDkgMDI6NTA6MDApAAAAAAAA8D8KJAjRBxDRByITMzEuMTIuMjAwOSAwMjo0MDowMCkAAAAAAADwPwokCNIHENIHIhMzMS4xMi4yMDA5IDAyOjIwOjAwKQAAAAAAAPA/CiQI0wcQ0wciEzMxLjEyLjIwMDkgMDI6MDA6MDApAAAAAAAA8D8KJAjUBxDUByITMzEuMTIuMjAwOSAwMTo1MDowMCkAAAAAAADwPwokCNUHENUHIhMzMS4xMi4yMDA5IDAxOjIwOjAwKQAAAAAAAPA/CiQI1gcQ1gciEzMxLjEyLjIwMDkgMDE6MTA6MDApAAAAAAAA8D8KJAjXBxDXByITMzEuMTIuMjAwOSAwMDo1MDowMCkAAAAAAADwPwokCNgHENgHIhMzMS4xMi4yMDA5IDAwOjMwOjAwKQAAAAAAAPA/CiQI2QcQ2QciEzMxLjEyLjIwMDkgMDA6MTA6MDApAAAAAAAA8D8KJAjaBxDaByITMzEuMTIuMjAwOSAwMDowMDowMCkAAAAAAADwPwokCNsHENsHIhMzMS4xMC4yMDE2IDIzOjIwOjAwKQAAAAAAAPA/CiQI3AcQ3AciEzMxLjEwLjIwMTYgMjI6NTA6MDApAAAAAAAA8D8KJAjdBxDdByITMzEuMTAuMjAxNiAyMjo0MDowMCkAAAAAAADwPwokCN4HEN4HIhMzMS4xMC4yMDE2IDIyOjIwOjAwKQAAAAAAAPA/CiQI3wcQ3wciEzMxLjEwLjIwMTYgMjI6MTA6MDApAAAAAAAA8D8KJAjgBxDgByITMzEuMTAuMjAxNiAyMjowMDowMCkAAAAAAADwPwokCOEHEOEHIhMzMS4xMC4yMDE2IDIxOjUwOjAwKQAAAAAAAPA/CiQI4gcQ4gciEzMxLjEwLjIwMTYgMjE6MjA6MDApAAAAAAAA8D8KJAjjBxDjByITMzEuMTAuMjAxNiAyMToxMDowMCkAAAAAAADwPwokCOQHEOQHIhMzMS4xMC4yMDE2IDIwOjMwOjAwKQAAAAAAAPA/CiQI5QcQ5QciEzMxLjEwLjIwMTYgMjA6MjA6MDApAAAAAAAA8D8KJAjmBxDmByITMzEuMTAuMjAxNiAyMDoxMDowMCkAAAAAAADwPwokCOcHEOcHIhMzMS4xMC4yMDE2IDIwOjAwOjAwKQAAAAAAAPA/QgsKCURhdGUgVGltZRrMBxABGrQHCrgCCMyIERgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAIAFAzIgRERG8jLmuRCNAGVkJ01C87hBAKQAAAKCZmek/MQAAAGBm5iFAOQAAAIDr0TxAQqICGhsJAAAAoJmZ6T8RmpmZXeXQDEAhnlmOLB0ox0AaGwmamZld5dAMQBGamZkpsp0ZQCEKxnQmuSzuQBobCZqZmSmynRlAETQzM9J4aSJAIRHMtd+Pb/FAGhsJNDMz0nhpIkARmpmZjxgEKEAhl20tIZSp60AaGwmamZmPGAQoQBEAAABNuJ4tQCETnfa9OuHjQBobCQAAAE24ni1AETQzMwWsnDFAIZUhCI2+qNdAGhsJNDMzBaycMUARZ2bm4/tpNEAhs7ZBsJrzw0AaGwlnZubj+2k0QBGamZnCSzc3QCFPQf4qyC2jQBobCZqZmcJLNzdAEc3MTKGbBDpAIZYnXjgGEWNAGhsJzcxMoZsEOkARAAAAgOvRPEAhABBAW3SdYUBCpAIaGwkAAACgmZnpPxEAAACAwvUSQCEzMzMzs07bQBobCQAAAIDC9RJAEQAAAOCjcBdAITMzMzOzTttAGhsJAAAA4KNwF0ARAAAAYLgeG0AhMzMzM7NO20AaGwkAAABguB4bQBEAAABAMzMfQCEzMzMzs07bQBobCQAAAEAzMx9AEQAAAGBm5iFAITMzMzOzTttAGhsJAAAAYGbmIUARAAAAYLieJEAhMzMzM7NO20AaGwkAAABguJ4kQBEAAABgZmYnQCEzMzMzs07bQBobCQAAAGBmZidAEQAAAOBRuCpAITMzMzOzTttAGhsJAAAA4FG4KkARAAAAgOtRL0AhMzMzM7NO20AaGwkAAACA61EvQBEAAACA69E8QCEzMzMzs07bQCABQhEKD0gyT0MgKG1tb2wvbW9sKRrHBxABGrYHCrgCCMyIERgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAIAFAzIgREU9YL/RB3SJAGV3Dcqqg1yBAIEgpAAAAYI8CN8AxAAAAYI/CIkA5AAAAANejQkBCogIaGwkAAABgjwI3wBFmZmbWIvswwCH01epkKyl/QBobCWZmZtYi+zDAEZqZmZls5yXAIRiDjJ7c/ZpAGhsJmpmZmWznJcAR0MzMDCexE8AhUTOQubdjwEAaGwnQzMwMJ7ETwBFgZmZmLLLxPyGP8/5j/sfhQBobCWBmZmYssvE/EQAAAEA9ihxAIRi2H4jBIfBAGhsJAAAAQD2KHEARMDMzs/dTKkAh+WffdGQy8UAaGwkwMzOz91MqQBEyMzNjaDEzQCHglcr4/6ntQBobCTIzM2NoMTNAEczMzOzUODlAIXyJKLdXytpAGhsJzMzM7NQ4OUARZmZmdkFAP0AhkqH5Dt/4ukAaGwlmZmZ2QUA/QBEAAAAA16NCQCEwuZ5osO+OQEKkAhobCQAAAGCPAjfAEQAAAIDrUfS/ITMzMzOzTttAGhsJAAAAgOtR9L8RAAAAoHA9AEAhMzMzM7NO20AaGwkAAACgcD0AQBEAAABA4XoSQCEzMzMzs07bQBobCQAAAEDhehJAEQAAAMD1KBxAITMzMzOzTttAGhsJAAAAwPUoHEARAAAAYI/CIkAhMzMzM7NO20AaGwkAAABgj8IiQBEAAADA9agnQCEzMzMzs07bQBobCQAAAMD1qCdAEQAAAIDCdSxAITMzMzOzTttAGhsJAAAAgMJ1LEARAAAAgD3KMEAhMzMzM7NO20AaGwkAAACAPcowQBEAAADAHkU0QCEzMzMzs07bQBobCQAAAMAeRTRAEQAAAADXo0JAITMzMzOzTttAIAFCCgoIVCAoZGVnQykaywcQARq3Bwq4AgjMiBEYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQCABQMyIERG1MjvfuMkTQBnDc/daxeoaQCCUASkAAABgjwI5wDEAAADAzMwUQDkAAAAAKRw3QEKiAhobCQAAAGCPAjnAETMzMyOwMjTAIYQtAjLV/2xAGhsJMzMzI7AyNMARzczMzKHFLsAhriCx+zIIkUAaGwnNzMzMocUuwBE0MzNT4yUlwCGA7+v5UxuqQBobCTQzM1PjJSXAETQzM7NJDBfAIUSt4encjcZAGhsJNDMzs0kMF8ARAAAAAGZm7r8hpNSZshX74UAaGwkAAAAAZmbuvxFgZmZmYOUOQCF75t5mNYTwQBobCWBmZmZg5Q5AETQzM5MWWSFAIcn7Qx+Nu/BAGhsJNDMzkxZZIUARzMzMDNX4KkAhK0xmYyB27kAaGwnMzMwM1fgqQBEyMzPDSUwyQCFFD+WQwBTaQBobCTIzM8NJTDJAEQAAAAApHDdAIVWxG8TVfpRAQqQCGhsJAAAAYI8COcARAAAAANejDMAhMzMzM7NO20AaGwkAAAAA16MMwBEAAACAPQrnvyEzMzMzs07bQBobCQAAAIA9Cue/EQAAAADXo/Q/ITMzMzOzTttAGhsJAAAAANej9D8RAAAAIIXrCUAhMzMzM7NO20AaGwkAAAAghesJQBEAAADAzMwUQCEzMzMzs07bQBobCQAAAMDMzBRAEQAAAAAAAB1AITMzMzOzTttAGhsJAAAAAAAAHUARAAAA4FE4IkAhMzMzM7NO20AaGwkAAADgUTgiQBEAAADA9SgmQCEzMzMzs07bQBobCQAAAMD1KCZAEQAAAEDh+ipAITMzMzOzTttAGhsJAAAAQOH6KkARAAAAACkcN0AhMzMzM7NO20AgAUINCgtUZGV3IChkZWdDKRrFBxABGrQHCrgCCMyIERgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAIAFAzIgREe48NvuXt3FAGdZdEe0EAiFAKQAAAEAzU29AMQAAAEAzt3FAOQAAACBcc3NAQqICGhsJAAAAQDNTb0ARmpmZeZMKcEAh3BoupoGef0AaGwmamZl5kwpwQBEzMzNTjWtwQCHsZcPYxhGdQBobCTMzM1ONa3BAEc3MzCyHzHBAIZ9RzKTnuL5AGhsJzczMLIfMcEARZmZmBoEtcUAhmr+KeFHe4EAaGwlmZmYGgS1xQBEAAADgeo5xQCFUR4zJeXjvQBobCQAAAOB6jnFAEZqZmbl073FAIaiwjYBfdPFAGhsJmpmZuXTvcUARMzMzk25QckAhcNR0Eqn87UAaGwkzMzOTblByQBHNzMxsaLFyQCFmtjM8dTfcQBobCc3MzGxosXJAEWZmZkZiEnNAIZ2zt235Ob1AGhsJZmZmRmISc0ARAAAAIFxzc0AhCAJ++1VtkUBCpAIaGwkAAABAM1NvQBEAAABgZgpxQCEzMzMzs07bQBobCQAAAGBmCnFAEQAAAMDMQHFAITMzMzOzTttAGhsJAAAAwMxAcUARAAAAQAprcUAhMzMzM7NO20AaGwkAAABACmtxQBEAAACAFJJxQCEzMzMzs07bQBobCQAAAIAUknFAEQAAAEAzt3FAITMzMzOzTttAGhsJAAAAQDO3cUARAAAAgMLdcUAhMzMzM7NO20AaGwkAAACAwt1xQBEAAADgegRyQCEzMzMzs07bQBobCQAAAOB6BHJAEQAAAKBwLXJAITMzMzOzTttAGhsJAAAAoHAtckARAAAAYGZmckAhMzMzM7NO20AaGwkAAABgZmZyQBEAAAAgXHNzQCEzMzMzs07bQCABQgoKCFRwb3QgKEspGskHEAEatAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERgyZJSC8OI0AZGtqrUUe6EEApAAAAIK5H6T8xAAAAQDOzIUA5AAAAgOtRPEBCogIaGwkAAAAgrkfpPxHNzMxgEFgMQCGeEwjQ9aDGQBobCc3MzGAQWAxAEc3MzJwaLxlAIUYc9COwye1AGhsJzczMnBovGUARmpmZhBYZIkAhNJS4aNBt8UAaGwmamZmEFhkiQBHNzMy6n5onQCGmJGPuKmfrQBobCc3MzLqfmidAEQAAAPEoHC1AIY9j3I+fMeRAGhsJAAAA8SgcLUARmpmZE9lOMUAhON2O3v0Z2EAaGwmamZkT2U4xQBEzM7OunQ80QCFfrg8Eho3EQBobCTMzs66dDzRAEc3MzEli0DZAIecV9T6zp6RAGhsJzczMSWLQNkARZ2bm5CaROUAhUodOcxhgZkAaGwlnZubkJpE5QBEAAACA61E8QCEIGjSrW+thQEKkAhobCQAAACCuR+k/EQAAAOBRuBJAITMzMzOzTttAGhsJAAAA4FG4EkARAAAAwPUoF0AhMzMzM7NO20AaGwkAAADA9SgXQBEAAADAzMwaQCEzMzMzs07bQBobCQAAAMDMzBpAEQAAAEAK1x5AITMzMzOzTttAGhsJAAAAQArXHkARAAAAQDOzIUAhMzMzM7NO20AaGwkAAABAM7MhQBEAAABgZmYkQCEzMzMzs07bQBobCQAAAGBmZiRAEQAAAMD1KCdAITMzMzOzTttAGhsJAAAAwPUoJ0ARAAAAIIVrKkAhMzMzM7NO20AaGwkAAAAghWsqQBEAAABA4fouQCEzMzMzs07bQBobCQAAAEDh+i5AEQAAAIDrUTxAITMzMzOzTttAIAFCDgoMVlBhY3QgKG1iYXIpGrEHEAEanAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERbi2WqgMhEEAZFHkSTjWQE0AgnAkxAAAA4KNwAUA5AAAAoEcBR0BCmQIaEhEAAACAbGcSQCGddBB9vmwIQRobCQAAAIBsZxJAEQAAAIBsZyJAIRtAgpi5zeVAGhsJAAAAgGxnIkARAAAAwCKbK0Ahgtg9lRwu00AaGwkAAADAIpsrQBEAAACAbGcyQCFzPUugLG/BQBobCQAAAIBsZzJAEQAAAKBHATdAIR0DM7LKj6xAGhsJAAAAoEcBN0ARAAAAwCKbO0AhCvP1KIwbl0AaGwkAAADAIps7QBEAAADwfhpAQCF4znIKBSiFQBobCQAAAPB+GkBAEQAAAIBsZ0JAIS0aM+gHxHFAGhsJAAAAgGxnQkARAAAAEFq0REAh9JcgJdDxW0AaGwkAAAAQWrREQBEAAACgRwFHQCH0lyAl0PFbQEKbAhoSEQAAAGBmZtY/ITMzMzOzTttAGhsJAAAAYGZm1j8RAAAAYI/C5T8hMzMzM7NO20AaGwkAAABgj8LlPxEAAABguB7xPyEzMzMzs07bQBobCQAAAGC4HvE/EQAAAMDMzPg/ITMzMzOzTttAGhsJAAAAwMzM+D8RAAAA4KNwAUAhMzMzM7NO20AaGwkAAADgo3ABQBEAAABgZmYIQCEzMzMzs07bQBobCQAAAGBmZghAEQAAAIDrURFAITMzMzOzTttAGhsJAAAAgOtREUARAAAAgML1GUAhMzMzM7NO20AaGwkAAACAwvUZQBEAAACgR+EkQCEzMzMzs07bQBobCQAAAKBH4SRAEQAAAKBHAUdAITMzMzOzTttAIAFCDgoMVlBkZWYgKG1iYXIpGskHEAEatAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERed/FgrweK0AZ+b2X9MvwHkApAAAAYGZm7j8xAAAAoJmZJ0A5AAAAYI/iT0BCogIaGwkAAABgZmbuPxHNzMxqke0cQCGt62oro/XsQBobCc3MzGqR7RxAEc3MzAQrBytAIXvGpyHiTPlAGhsJzczMBCsHK0ARmpkZqsbLM0AhwZRmleYS8EAaGwmamRmqxsszQBHNzMzR9xM6QCE7PWFhv2beQBobCc3MzNH3EzpAEQAAwHwULkBAId3ekpwZlsdAGhsJAADAfBQuQEARmpmZEC1SQ0Ahh8UUmT+FskAaGwmamZkQLVJDQBEzM3OkRXZGQCFRbRb+wDOcQBobCTMzc6RFdkZAEc3MTDhemklAIUjBSycUSYhAGhsJzcxMOF6aSUARZ2YmzHa+TEAhuH/i7OjzZUAaGwlnZibMdr5MQBEAAABgj+JPQCGB6KkFGgdiQEKkAhobCQAAAGBmZu4/EQAAAKBwPRZAITMzMzOzTttAGhsJAAAAoHA9FkARAAAAIK5HHEAhMzMzM7NO20AaGwkAAAAgrkccQBEAAAAAAAAhQCEzMzMzs07bQBobCQAAAAAAACFAEQAAAKCZGSRAITMzMzOzTttAGhsJAAAAoJkZJEARAAAAoJmZJ0AhMzMzM7NO20AaGwkAAACgmZknQBEAAAAgrscrQCEzMzMzs07bQBobCQAAACCuxytAEQAAAGCPQjBAITMzMzOzTttAGhsJAAAAYI9CMEARAAAAYGYmM0AhMzMzM7NO20AaGwkAAABgZiYzQBEAAAAgXM83QCEzMzMzs07bQBobCQAAACBczzdAEQAAAGCP4k9AITMzMzOzTttAIAFCDgoMVlBtYXggKG1iYXIpGs0HEAEatwcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERa5ljsr87CEAZE+0OOAC0UUAgnwIpAAAAAICHw8AxAAAAgBSuB0A5AAAAACncNkBCogIaGwkAAAAAgIfDwBFmZiYxaJLBwCG+dyu81wY8QBobCWZmJjFoksHAEZqZmcSgOr/AIbB3K7zXBjxAGhsJmpmZxKA6v8ARZmbmJnFQu8AhvncrvNcGPEAaGwlmZuYmcVC7wBEzMzOJQWa3wCG2dyu81wY8QBobCTMzM4lBZrfAEQAAgOsRfLPAIbZ3K7zXBjxAGhsJAACA6xF8s8ARmJmZm8Qjr8AhvncrvNcGPEAaGwmYmZmbxCOvwBEyMzNgZU+nwCG2dyu81wY8QBobCTIzM2BlT6fAEZiZmUkM9p7AIbZ3K7zXBjxAGhsJmJmZSQz2nsARkJmZpZuajsAhvncrvNcGPEAaGwmQmZmlm5qOwBEAAAAAKdw2QCHjiakJPw0RQUKkAhobCQAAAACAh8PAEQAAACCF6/E/ITMzMzOzTttAGhsJAAAAIIXr8T8RAAAAgML1+D8hMzMzM7NO20AaGwkAAACAwvX4PxEAAAAAAAAAQCEzMzMzs07bQBobCQAAAAAAAABAEQAAAMAehQNAITMzMzOzTttAGhsJAAAAwB6FA0ARAAAAgBSuB0AhMzMzM7NO20AaGwkAAACAFK4HQBEAAAAA16MMQCEzMzMzs07bQBobCQAAAADXowxAEQAAACCuRxFAITMzMzOzTttAGhsJAAAAIK5HEUARAAAAgML1FEAhMzMzM7NO20AaGwkAAACAwvUUQBEAAABgj8IaQCEzMzMzs07bQBobCQAAAGCPwhpAEQAAAAAp3DZAITMzMzOzTttAIAFCDwoNbWF4LiB3diAobS9zKRrFBxABGrQHCrgCCMyIERgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAIAFAzIgREaakBUm36Y5AGSlzEQMjvSBAKQAAAMDMjIxAMQAAAGCP7I5AOQAAAMDMuo9AQqICGhsJAAAAwMyMjEARZmZmJjPejEAh9/QPaXf+UUAaGwlmZmYmM96MQBHNzMyMmS+NQCEv9Q9pd/5RQBobCc3MzIyZL41AETMzM/P/gI1AIff0D2l3/lFAGhsJMzMz8/+AjUARmpmZWWbSjUAhGepZIuO2X0AaGwmamZlZZtKNQBEAAADAzCOOQCFQb0VXb1KXQBobCQAAAMDMI45AEWZmZiYzdY5AIbeCqewnRMZAGhsJZmZmJjN1jkARzczMjJnGjkAhMXFtDqPV7kAaGwnNzMyMmcaOQBEzMzPz/xePQCEjj9+bf6IAQRobCTMzM/P/F49AEZqZmVlmaY9AIQnXWCsxjO1AGhsJmpmZWWZpj0ARAAAAwMy6j0AhT1FB4bU5uUBCpAIaGwkAAADAzIyMQBEAAABgj5SOQCEzMzMzs07bQBobCQAAAGCPlI5AEQAAAIDrtY5AITMzMzOzTttAGhsJAAAAgOu1jkARAAAAgBTMjkAhMzMzM7NO20AaGwkAAACAFMyOQBEAAACgR92OQCEzMzMzs07bQBobCQAAAKBH3Y5AEQAAAGCP7I5AITMzMzOzTttAGhsJAAAAYI/sjkARAAAAIIX7jkAhMzMzM7NO20AaGwkAAAAghfuOQBEAAABgZgyPQCEzMzMzs07bQBobCQAAAGBmDI9AEQAAAIDrH49AITMzMzOzTttAGhsJAAAAgOsfj0ARAAAAoHA7j0AhMzMzM7NO20AaGwkAAACgcDuPQBEAAADAzLqPQCEzMzMzs07bQCABQgoKCHAgKG1iYXIpGsMHEAEatAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBEROxMv1eoCU0AZhxJtK8t0MEApAAAAYGbmKUAxAAAAoJnZU0A5AAAAAAAAWUBCogIaGwkAAABgZuYpQBGamZkRrqc1QCEJLC+Ze+lkQBobCZqZmRGupzVAETMzM/MoXD5AIfLhCBTBIoNAGhsJMzMz8yhcPkARZmZm6lGIQ0AhBOgkgpdXtUAaGwlmZmbqUYhDQBEzMzNbj+JHQCGn6+k8aNjMQBobCTMzM1uP4kdAEQAAAMzMPExAIecqPlOSWNRAGhsJAAAAzMw8TEARZmZmHoVLUEAh661Q2v8p20AaGwlmZmYehUtQQBHMzMzWo3hSQCHSooFOo63iQBobCczMzNajeFJAETMzM4/CpVRAIV171Z1WzelAGhsJMzMzj8KlVEARmZmZR+HSVkAhZG9Lo0i67kAaGwmZmZlH4dJWQBEAAAAAAABZQCFlmy3aclDrQEKkAhobCQAAAGBm5ilAEQAAAMAehUlAITMzMzOzTttAGhsJAAAAwB6FSUARAAAAoHCdTkAhMzMzM7NO20AaGwkAAACgcJ1OQBEAAADgozBRQCEzMzMzs07bQBobCQAAAOCjMFFAEQAAAAAAoFJAITMzMzOzTttAGhsJAAAAAACgUkARAAAAoJnZU0AhMzMzM7NO20AaGwkAAACgmdlTQBEAAAAAAOBUQCEzMzMzs07bQBobCQAAAAAA4FRAEQAAAGBm5lVAITMzMzOzTttAGhsJAAAAYGbmVUARAAAAQDPTVkAhMzMzM7NO20AaGwkAAABAM9NWQBEAAABgZsZXQCEzMzMzs07bQBobCQAAAGBmxldAEQAAAAAAAFlAITMzMzOzTttAIAFCCAoGcmggKCUpGskHEAEatAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERMhMi9ZQAk0AZSHQUptT/Q0ApAAAAwMyNkEAxAAAAACn3kkA5AAAAACnGlUBCogIaGwkAAADAzI2QQBEzMzOTbxORQCHQfX6gQCqGQBobCTMzM5NvE5FAEWZmZmYSmZFAIR8y3+rcR4tAGhsJZmZmZhKZkUARmpmZObUekkAhgAZelKI80UAaGwmamZk5tR6SQBHNzMwMWKSSQCEVJuP7olzvQBobCc3MzAxYpJJAEQAAAOD6KZNAIVe2LuuPqfVAGhsJAAAA4Popk0ARMzMzs52vk0Ahb9opj1hB8EAaGwkzMzOzna+TQBFmZmaGQDWUQCFaasUOivjfQBobCWZmZoZANZRAEZqZmVnjupRAIaGC7huglrdAGhsJmpmZWeO6lEARzczMLIZAlUAhBDKvZmFBmUAaGwnNzMwshkCVQBEAAAAAKcaVQCEmp598HOd8QEKkAhobCQAAAMDMjZBAEQAAAGCPOZJAITMzMzOzTttAGhsJAAAAYI85kkARAAAAYLh2kkAhMzMzM7NO20AaGwkAAABguHaSQBEAAACA66SSQCEzMzMzs07bQBobCQAAAIDrpJJAEQAAACBczpJAITMzMzOzTttAGhsJAAAAIFzOkkARAAAAACn3kkAhMzMzM7NO20AaGwkAAAAAKfeSQBEAAADgeiKTQCEzMzMzs07bQBobCQAAAOB6IpNAEQAAAIA9UZNAITMzMzOzTttAGhsJAAAAgD1Rk0ARAAAAYGaJk0AhMzMzM7NO20AaGwkAAABgZomTQBEAAACAFNOTQCEzMzMzs07bQBobCQAAAIAU05NAEQAAAAApxpVAITMzMzOzTttAIAFCDgoMcmhvIChnL20qKjMpGsYHEAEatAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERrGNaggoTGEAZSy7xh9k8BUApAAAAAAAA4D8xAAAAAClcFkA5AAAAoEchMkBCogIaGwkAAAAAAADgPxEzMzOznxoCQCFqKwBv4dbHQBobCTMzM7OfGgJAETMzM7OfGhBAIQ+LoPjJtu5AGhsJMzMzs58aEEARzMzMjO8nF0AhQlXJedBt8UAaGwnMzMyM7ycXQBFmZmZmPzUeQCG/M4KbF5/rQBobCWZmZmY/NR5AEQAAAKBHoSJAIdYqtkDKs+NAGhsJAAAAoEehIkARzMzMjO8nJkAhikbwKskl10AaGwnMzMyM7ycmQBGZmZl5l64pQCEd55Bf+FbDQBobCZmZmXmXrilAEWZmZmY/NS1AIW7C1op3MKJAGhsJZmZmZj81LUARmpmZqfNdMEAhBeVL5VpoYUAaGwmamZmp810wQBEAAACgRyEyQCH75EvlWmhhQEKkAhobCQAAAAAAAOA/EQAAAKCZmQdAITMzMzOzTttAGhsJAAAAoJmZB0ARAAAAQDMzDUAhMzMzM7NO20AaGwkAAABAMzMNQBEAAAAghesQQCEzMzMzs07bQBobCQAAACCF6xBAEQAAAEDhehNAITMzMzOzTttAGhsJAAAAQOF6E0ARAAAAAClcFkAhMzMzM7NO20AaGwkAAAAAKVwWQBEAAABgj8IZQCEzMzMzs07bQBobCQAAAGCPwhlAEQAAAKBwPR1AITMzMzOzTttAGhsJAAAAoHA9HUARAAAAQDOzIEAhMzMzM7NO20AaGwkAAABAM7MgQBEAAACgmZkjQCEzMzMzs07bQBobCQAAAKCZmSNAEQAAAKBHITJAITMzMzOzTttAIAFCCwoJc2ggKGcva2cpGq0HEAEanAcKuAIIzIgRGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AgAUDMiBERAx7Ql87YZUAZPavek1WlVUAgoAIxAAAAYGbGaEA5AAAAAACAdkBCmQIaEhEAAAAAAABCQCGyz3LKp4zgQBobCQAAAAAAAEJAEQAAAAAAAFJAIaFvAPUKnNdAGhsJAAAAAAAAUkARAAAAAAAAW0AhPJuC+sCcvkAaGwkAAAAAAABbQBEAAAAAAABiQCGg4ycj6vbHQBobCQAAAAAAAGJAEQAAAAAAgGZAIQH0qUYg7t9AGhsJAAAAAACAZkARAAAAAAAAa0Ah94ZusCJ38UAaGwkAAAAAAABrQBEAAAAAAIBvQCHaaOE+FbHpQBobCQAAAAAAgG9AEQAAAAAAAHJAIZGmQO6xht1AGhsJAAAAAAAAckARAAAAAABAdEAhlQ9nDNCduUAaGwkAAAAAAEB0QBEAAAAAAIB2QCFEMZC5EoC+QEKbAhoSEQAAAIA9yj5AITMzMzOzTttAGhsJAAAAgD3KPkARAAAAgOtRUEAhMzMzM7NO20AaGwkAAACA61FQQBEAAABgZhZjQCEzMzMzs07bQBobCQAAAGBmFmNAEQAAAEAzk2ZAITMzMzOzTttAGhsJAAAAQDOTZkARAAAAYGbGaEAhMzMzM7NO20AaGwkAAABgZsZoQBEAAAAAAFBqQCEzMzMzs07bQBobCQAAAAAAUGpAEQAAAMDM7GtAITMzMzOzTttAGhsJAAAAwMzsa0ARAAAAoJmZbkAhMzMzM7NO20AaGwkAAACgmZluQBEAAADAzGxwQCEzMzMzs07bQBobCQAAAMDMbHBAEQAAAAAAgHZAITMzMzOzTttAIAFCCgoId2QgKGRlZykayAcQARq3Bwq4AgjMiBEYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQBobCQAAAAAAAPA/EQAAAAAAAPA/ITMzMzOzTttAGhsJAAAAAAAA8D8RAAAAAAAA8D8hMzMzM7NO20AaGwkAAAAAAADwPxEAAAAAAADwPyEzMzMzs07bQCABQMyIERFbuIPdtQ36PxkPTHHq9rFRQCDAAikAAAAAgIfDwDEAAADA9Sj8PzkAAACAFC4sQEKiAhobCQAAAACAh8PAEQAAsHLYksHAIVIECGmQADxAGhsJAACwctiSwcARAADAymE8v8AhUgQIaZAAPEAaGwkAAMDKYTy/wBEAACCwElO7wCFSBAhpkAA8QBobCQAAILASU7vAEQAAgJXDabfAIVIECGmQADxAGhsJAACAlcNpt8ARAADgenSAs8AhUgQIaZAAPEAaGwkAAOB6dICzwBEAAIDASi6vwCFSBAhpkAA8QBobCQAAgMBKLq/AEQAAQIusW6fAIVIECGmQADxAGhsJAABAi6xbp8ARAAAArBwSn8AhUgQIaZAAPEAaGwkAAACsHBKfwBEAAACDwNmOwCFSBAhpkAA8QBobCQAAAIPA2Y7AEQAAAIAULixAId86ses/DRFBQqQCGhsJAAAAAICHw8ARAAAAoHA94j8hMzMzM7NO20AaGwkAAACgcD3iPxEAAABAMzPrPyEzMzMzs07bQBobCQAAAEAzM+s/EQAAAOB6FPI/ITMzMzOzTttAGhsJAAAA4HoU8j8RAAAA4FG49j8hMzMzM7NO20AaGwkAAADgUbj2PxEAAADA9Sj8PyEzMzMzs07bQBobCQAAAMD1KPw/EQAAAIA9CgFAITMzMzOzTttAGhsJAAAAgD0KAUARAAAA4FG4BEAhMzMzM7NO20AaGwkAAADgUbgEQBEAAADgo3AJQCEzMzMzs07bQBobCQAAAOCjcAlAEQAAAOBRuBBAITMzMzOzTttAGhsJAAAA4FG4EEARAAAAgBQuLEAhMzMzM7NO20AgAUIKCgh3diAobS9zKQ=="></facets-overview>';
        facets_iframe.srcdoc = facets_html;
         facets_iframe.id = "";
         setTimeout(() => {
           facets_iframe.setAttribute('height', facets_iframe.contentWindow.document.body.offsetHeight + 'px')
         }, 1500)
         </script>



<div><b>'eval' split:</b></div><br/>



<iframe id='facets-iframe' width="100%" height="500px"></iframe>
        <script>
        facets_iframe = document.getElementById('facets-iframe');
        facets_html = '<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"><\/script><link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/master/facets-dist/facets-jupyter.html"><facets-overview proto-input="CseYAwoObGhzX3N0YXRpc3RpY3MQ+8wIGseuAhACIrSuAgq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBD+ywgaHhITMjEuMDMuMjAxNCAxNzoxMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE3OjAwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTY6NTA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxNjo0MDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE2OjIwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTU6NTA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxNTo0MDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE1OjEwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTQ6NTA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxNDo0MDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDE0OjIwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTQ6MDA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMzo1MDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDEzOjQwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTM6MzA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMjoyMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDExOjUwOjAwGQAAAAAAAABAGh4SEzIxLjAzLjIwMTQgMTE6NDA6MDAZAAAAAAAAAEAaHhITMjEuMDMuMjAxNCAxMTozMDowMBkAAAAAAAAAQBoeEhMyMS4wMy4yMDE0IDEwOjUwOjAwGQAAAAAAAABAJQAAmEEq7KYCCh4iEzIxLjAzLjIwMTQgMTc6MTA6MDApAAAAAAAAAEAKIggBEAEiEzIxLjAzLjIwMTQgMTc6MDA6MDApAAAAAAAAAEAKIggCEAIiEzIxLjAzLjIwMTQgMTY6NTA6MDApAAAAAAAAAEAKIggDEAMiEzIxLjAzLjIwMTQgMTY6NDA6MDApAAAAAAAAAEAKIggEEAQiEzIxLjAzLjIwMTQgMTY6MjA6MDApAAAAAAAAAEAKIggFEAUiEzIxLjAzLjIwMTQgMTU6NTA6MDApAAAAAAAAAEAKIggGEAYiEzIxLjAzLjIwMTQgMTU6NDA6MDApAAAAAAAAAEAKIggHEAciEzIxLjAzLjIwMTQgMTU6MTA6MDApAAAAAAAAAEAKIggIEAgiEzIxLjAzLjIwMTQgMTQ6NTA6MDApAAAAAAAAAEAKIggJEAkiEzIxLjAzLjIwMTQgMTQ6NDA6MDApAAAAAAAAAEAKIggKEAoiEzIxLjAzLjIwMTQgMTQ6MjA6MDApAAAAAAAAAEAKIggLEAsiEzIxLjAzLjIwMTQgMTQ6MDA6MDApAAAAAAAAAEAKIggMEAwiEzIxLjAzLjIwMTQgMTM6NTA6MDApAAAAAAAAAEAKIggNEA0iEzIxLjAzLjIwMTQgMTM6NDA6MDApAAAAAAAAAEAKIggOEA4iEzIxLjAzLjIwMTQgMTM6MzA6MDApAAAAAAAAAEAKIggPEA8iEzIxLjAzLjIwMTQgMTI6MjA6MDApAAAAAAAAAEAKIggQEBAiEzIxLjAzLjIwMTQgMTE6NTA6MDApAAAAAAAAAEAKIggREBEiEzIxLjAzLjIwMTQgMTE6NDA6MDApAAAAAAAAAEAKIggSEBIiEzIxLjAzLjIwMTQgMTE6MzA6MDApAAAAAAAAAEAKIggTEBMiEzIxLjAzLjIwMTQgMTA6NTA6MDApAAAAAAAAAEAKIggUEBQiEzIxLjAzLjIwMTQgMTA6NDA6MDApAAAAAAAAAEAKIggVEBUiEzIxLjAzLjIwMTQgMTA6MTA6MDApAAAAAAAAAEAKIggWEBYiEzIxLjAzLjIwMTQgMTA6MDA6MDApAAAAAAAAAEAKIggXEBciEzIxLjAzLjIwMTQgMDk6NTA6MDApAAAAAAAAAEAKIggYEBgiEzIxLjAzLjIwMTQgMDg6NTA6MDApAAAAAAAAAEAKIggZEBkiEzIxLjAzLjIwMTQgMDg6MTA6MDApAAAAAAAAAEAKIggaEBoiEzIxLjAzLjIwMTQgMDc6NDA6MDApAAAAAAAAAEAKIggbEBsiEzIxLjAzLjIwMTQgMDc6MDA6MDApAAAAAAAAAEAKIggcEBwiEzIxLjAzLjIwMTQgMDY6NTA6MDApAAAAAAAAAEAKIggdEB0iEzIxLjAzLjIwMTQgMDY6MjA6MDApAAAAAAAAAEAKIggeEB4iEzIxLjAzLjIwMTQgMDU6NTA6MDApAAAAAAAAAEAKIggfEB8iEzIxLjAzLjIwMTQgMDU6MzA6MDApAAAAAAAAAEAKIgggECAiEzIxLjAzLjIwMTQgMDU6MjA6MDApAAAAAAAAAEAKIgghECEiEzIxLjAzLjIwMTQgMDU6MTA6MDApAAAAAAAAAEAKIggiECIiEzIxLjAzLjIwMTQgMDU6MDA6MDApAAAAAAAAAEAKIggjECMiEzIxLjAzLjIwMTQgMDQ6NTA6MDApAAAAAAAAAEAKIggkECQiEzIxLjAzLjIwMTQgMDQ6MzA6MDApAAAAAAAAAEAKIgglECUiEzIxLjAzLjIwMTQgMDM6MzA6MDApAAAAAAAAAEAKIggmECYiEzIxLjAzLjIwMTQgMDM6MjA6MDApAAAAAAAAAEAKIggnECciEzIxLjAzLjIwMTQgMDM6MDA6MDApAAAAAAAAAEAKIggoECgiEzIxLjAzLjIwMTQgMDI6NTA6MDApAAAAAAAAAEAKIggpECkiEzIxLjAzLjIwMTQgMDI6MTA6MDApAAAAAAAAAEAKIggqECoiEzIxLjAzLjIwMTQgMDE6NTA6MDApAAAAAAAAAEAKIggrECsiEzIxLjAzLjIwMTQgMDE6NDA6MDApAAAAAAAAAEAKIggsECwiEzIxLjAzLjIwMTQgMDE6MjA6MDApAAAAAAAAAEAKIggtEC0iEzIwLjAzLjIwMTQgMjM6NDA6MDApAAAAAAAAAEAKIgguEC4iEzIwLjAzLjIwMTQgMjM6MzA6MDApAAAAAAAAAEAKIggvEC8iEzIwLjAzLjIwMTQgMjM6MTA6MDApAAAAAAAAAEAKIggwEDAiEzIwLjAzLjIwMTQgMjI6MzA6MDApAAAAAAAAAEAKIggxEDEiEzIwLjAzLjIwMTQgMjI6MTA6MDApAAAAAAAAAEAKIggyEDIiEzIwLjAzLjIwMTQgMjI6MDA6MDApAAAAAAAAAEAKIggzEDMiEzIwLjAzLjIwMTQgMjE6NDA6MDApAAAAAAAAAEAKIgg0EDQiEzIwLjAzLjIwMTQgMjE6MzA6MDApAAAAAAAAAEAKIgg1EDUiEzIwLjAzLjIwMTQgMjE6MjA6MDApAAAAAAAAAEAKIgg2EDYiEzIwLjAzLjIwMTQgMjE6MTA6MDApAAAAAAAAAEAKIgg3EDciEzIwLjAzLjIwMTQgMjA6NTA6MDApAAAAAAAAAEAKIgg4EDgiEzIwLjAzLjIwMTQgMjA6MjA6MDApAAAAAAAAAEAKIgg5EDkiEzIwLjAzLjIwMTQgMTk6NTA6MDApAAAAAAAAAEAKIgg6EDoiEzIwLjAzLjIwMTQgMTk6NDA6MDApAAAAAAAAAEAKIgg7EDsiEzIwLjAzLjIwMTQgMTk6MzA6MDApAAAAAAAAAEAKIgg8EDwiEzIwLjAzLjIwMTQgMTk6MTA6MDApAAAAAAAAAEAKIgg9ED0iEzIwLjAzLjIwMTQgMTg6NDA6MDApAAAAAAAAAEAKIgg+ED4iEzIwLjAzLjIwMTQgMTg6MzA6MDApAAAAAAAAAEAKIgg/ED8iEzIwLjAzLjIwMTQgMTg6MjA6MDApAAAAAAAAAEAKIghAEEAiEzIwLjAzLjIwMTQgMTc6NTA6MDApAAAAAAAAAEAKIghBEEEiEzIwLjAzLjIwMTQgMTc6MTA6MDApAAAAAAAAAEAKIghCEEIiEzIwLjAzLjIwMTQgMTc6MDA6MDApAAAAAAAAAEAKIghDEEMiEzIwLjAzLjIwMTQgMTY6NDA6MDApAAAAAAAAAEAKIghEEEQiEzIwLjAzLjIwMTQgMTU6MTA6MDApAAAAAAAAAEAKIghFEEUiEzIwLjAzLjIwMTQgMTU6MDA6MDApAAAAAAAAAEAKIghGEEYiEzIwLjAzLjIwMTQgMTQ6NDA6MDApAAAAAAAAAEAKIghHEEciEzIwLjAzLjIwMTQgMTM6MzA6MDApAAAAAAAAAEAKIghIEEgiEzIwLjAzLjIwMTQgMTM6MjA6MDApAAAAAAAAAEAKIghJEEkiEzIwLjAzLjIwMTQgMTM6MDA6MDApAAAAAAAAAEAKIghKEEoiEzIwLjAzLjIwMTQgMTI6MjA6MDApAAAAAAAAAEAKIghLEEsiEzIwLjAzLjIwMTQgMTE6NDA6MDApAAAAAAAAAEAKIghMEEwiEzIwLjAzLjIwMTQgMTE6MjA6MDApAAAAAAAAAEAKIghNEE0iEzAxLjA3LjIwMTAgMjM6MTA6MDApAAAAAAAAAEAKIghOEE4iEzAxLjA3LjIwMTAgMjM6MDA6MDApAAAAAAAAAEAKIghPEE8iEzAxLjA3LjIwMTAgMjI6NDA6MDApAAAAAAAAAEAKIghQEFAiEzAxLjA3LjIwMTAgMjI6MzA6MDApAAAAAAAAAEAKIghREFEiEzAxLjA3LjIwMTAgMjI6MDA6MDApAAAAAAAAAEAKIghSEFIiEzAxLjA3LjIwMTAgMjE6NDA6MDApAAAAAAAAAEAKIghTEFMiEzAxLjA3LjIwMTAgMjE6MDA6MDApAAAAAAAAAEAKIghUEFQiEzAxLjA3LjIwMTAgMjA6NDA6MDApAAAAAAAAAEAKIghVEFUiEzAxLjA3LjIwMTAgMjA6MjA6MDApAAAAAAAAAEAKIghWEFYiEzAxLjA3LjIwMTAgMjA6MTA6MDApAAAAAAAAAEAKIghXEFciEzAxLjA3LjIwMTAgMTk6MDA6MDApAAAAAAAAAEAKIghYEFgiEzAxLjA3LjIwMTAgMTg6NTA6MDApAAAAAAAAAEAKIghZEFkiEzAxLjA3LjIwMTAgMTg6MjA6MDApAAAAAAAAAEAKIghaEFoiEzAxLjA3LjIwMTAgMTc6NTA6MDApAAAAAAAAAEAKIghbEFsiEzAxLjA3LjIwMTAgMTc6MTA6MDApAAAAAAAAAEAKIghcEFwiEzAxLjA3LjIwMTAgMTc6MDA6MDApAAAAAAAAAEAKIghdEF0iEzAxLjA3LjIwMTAgMTY6NTA6MDApAAAAAAAAAEAKIgheEF4iEzAxLjA3LjIwMTAgMTY6MzA6MDApAAAAAAAAAEAKIghfEF8iEzAxLjA3LjIwMTAgMTY6MDA6MDApAAAAAAAAAEAKIghgEGAiEzAxLjA3LjIwMTAgMTU6MzA6MDApAAAAAAAAAEAKIghhEGEiEzAxLjA3LjIwMTAgMTU6MjA6MDApAAAAAAAAAEAKIghiEGIiEzAxLjA3LjIwMTAgMTU6MDA6MDApAAAAAAAAAEAKIghjEGMiEzAxLjA3LjIwMTAgMTQ6NTA6MDApAAAAAAAAAEAKIghkEGQiEzAxLjA3LjIwMTAgMTQ6NDA6MDApAAAAAAAAAEAKIghlEGUiEzAxLjA3LjIwMTAgMTM6MjA6MDApAAAAAAAAAEAKIghmEGYiEzAxLjA3LjIwMTAgMTI6MjA6MDApAAAAAAAAAEAKIghnEGciEzAxLjA3LjIwMTAgMTI6MDA6MDApAAAAAAAAAEAKIghoEGgiEzAxLjA3LjIwMTAgMTE6MzA6MDApAAAAAAAAAEAKIghpEGkiEzAxLjA3LjIwMTAgMTA6NTA6MDApAAAAAAAAAEAKIghqEGoiEzAxLjA3LjIwMTAgMDk6NTA6MDApAAAAAAAAAEAKIghrEGsiEzAxLjA3LjIwMTAgMDk6MDA6MDApAAAAAAAAAEAKIghsEGwiEzAxLjA3LjIwMTAgMDg6NTA6MDApAAAAAAAAAEAKIghtEG0iEzAxLjA3LjIwMTAgMDg6MTA6MDApAAAAAAAAAEAKIghuEG4iEzAxLjA3LjIwMTAgMDc6MjA6MDApAAAAAAAAAEAKIghvEG8iEzAxLjA3LjIwMTAgMDc6MDA6MDApAAAAAAAAAEAKIghwEHAiEzAxLjA3LjIwMTAgMDY6NDA6MDApAAAAAAAAAEAKIghxEHEiEzAxLjA3LjIwMTAgMDY6MjA6MDApAAAAAAAAAEAKIghyEHIiEzAxLjA3LjIwMTAgMDY6MTA6MDApAAAAAAAAAEAKIghzEHMiEzAxLjA3LjIwMTAgMDU6MzA6MDApAAAAAAAAAEAKIgh0EHQiEzAxLjA3LjIwMTAgMDU6MTA6MDApAAAAAAAAAEAKIgh1EHUiEzAxLjA3LjIwMTAgMDQ6NTA6MDApAAAAAAAAAEAKIgh2EHYiEzAxLjA3LjIwMTAgMDQ6MTA6MDApAAAAAAAAAEAKIgh3EHciEzAxLjA3LjIwMTAgMDM6MjA6MDApAAAAAAAAAEAKIgh4EHgiEzAxLjA3LjIwMTAgMDM6MTA6MDApAAAAAAAAAEAKIgh5EHkiEzAxLjA3LjIwMTAgMDM6MDA6MDApAAAAAAAAAEAKIgh6EHoiEzAxLjA3LjIwMTAgMDI6NTA6MDApAAAAAAAAAEAKIgh7EHsiEzAxLjA3LjIwMTAgMDE6MjA6MDApAAAAAAAAAEAKIgh8EHwiEzAxLjA3LjIwMTAgMDA6MzA6MDApAAAAAAAAAEAKIgh9EH0iEzMxLjEyLjIwMTYgMjM6NTA6MDApAAAAAAAA8D8KIgh+EH4iEzMxLjEyLjIwMTYgMjM6MTA6MDApAAAAAAAA8D8KIgh/EH8iEzMxLjEyLjIwMTYgMjM6MDA6MDApAAAAAAAA8D8KJAiAARCAASITMzEuMTIuMjAxNiAyMjo1MDowMCkAAAAAAADwPwokCIEBEIEBIhMzMS4xMi4yMDE2IDIyOjEwOjAwKQAAAAAAAPA/CiQIggEQggEiEzMxLjEyLjIwMTYgMjA6NDA6MDApAAAAAAAA8D8KJAiDARCDASITMzEuMTIuMjAxNiAxOTozMDowMCkAAAAAAADwPwokCIQBEIQBIhMzMS4xMi4yMDE2IDE4OjQwOjAwKQAAAAAAAPA/CiQIhQEQhQEiEzMxLjEyLjIwMTYgMTg6MzA6MDApAAAAAAAA8D8KJAiGARCGASITMzEuMTIuMjAxNiAxNzo1MDowMCkAAAAAAADwPwokCIcBEIcBIhMzMS4xMi4yMDE2IDE3OjAwOjAwKQAAAAAAAPA/CiQIiAEQiAEiEzMxLjEyLjIwMTYgMTY6MDA6MDApAAAAAAAA8D8KJAiJARCJASITMzEuMTIuMjAxNiAxNDo0MDowMCkAAAAAAADwPwokCIoBEIoBIhMzMS4xMi4yMDE2IDEzOjMwOjAwKQAAAAAAAPA/CiQIiwEQiwEiEzMxLjEyLjIwMTYgMTM6MjA6MDApAAAAAAAA8D8KJAiMARCMASITMzEuMTIuMjAxNiAxMzoxMDowMCkAAAAAAADwPwokCI0BEI0BIhMzMS4xMi4yMDE2IDExOjQwOjAwKQAAAAAAAPA/CiQIjgEQjgEiEzMxLjEyLjIwMTYgMTE6MTA6MDApAAAAAAAA8D8KJAiPARCPASITMzEuMTIuMjAxNiAxMDo1MDowMCkAAAAAAADwPwokCJABEJABIhMzMS4xMi4yMDE2IDEwOjQwOjAwKQAAAAAAAPA/CiQIkQEQkQEiEzMxLjEyLjIwMTYgMTA6MzA6MDApAAAAAAAA8D8KJAiSARCSASITMzEuMTIuMjAxNiAxMDoyMDowMCkAAAAAAADwPwokCJMBEJMBIhMzMS4xMi4yMDE2IDA5OjMwOjAwKQAAAAAAAPA/CiQIlAEQlAEiEzMxLjEyLjIwMTYgMDY6MzA6MDApAAAAAAAA8D8KJAiVARCVASITMzEuMTIuMjAxNiAwNTozMDowMCkAAAAAAADwPwokCJYBEJYBIhMzMS4xMi4yMDE2IDA1OjIwOjAwKQAAAAAAAPA/CiQIlwEQlwEiEzMxLjEyLjIwMTYgMDU6MDA6MDApAAAAAAAA8D8KJAiYARCYASITMzEuMTIuMjAxNiAwNDozMDowMCkAAAAAAADwPwokCJkBEJkBIhMzMS4xMi4yMDE2IDA0OjEwOjAwKQAAAAAAAPA/CiQImgEQmgEiEzMxLjEyLjIwMTYgMDM6NDA6MDApAAAAAAAA8D8KJAibARCbASITMzEuMTIuMjAxNiAwMzoyMDowMCkAAAAAAADwPwokCJwBEJwBIhMzMS4xMi4yMDE2IDAyOjAwOjAwKQAAAAAAAPA/CiQInQEQnQEiEzMxLjEyLjIwMTYgMDE6MzA6MDApAAAAAAAA8D8KJAieARCeASITMzEuMTIuMjAxNiAwMDo0MDowMCkAAAAAAADwPwokCJ8BEJ8BIhMzMS4xMi4yMDE2IDAwOjEwOjAwKQAAAAAAAPA/CiQIoAEQoAEiEzMxLjEyLjIwMTYgMDA6MDA6MDApAAAAAAAA8D8KJAihARChASITMzEuMTIuMjAxNSAyMzo1MDowMCkAAAAAAADwPwokCKIBEKIBIhMzMS4xMi4yMDE1IDIzOjQwOjAwKQAAAAAAAPA/CiQIowEQowEiEzMxLjEyLjIwMTUgMjM6MzA6MDApAAAAAAAA8D8KJAikARCkASITMzEuMTIuMjAxNSAyMzoyMDowMCkAAAAAAADwPwokCKUBEKUBIhMzMS4xMi4yMDE1IDIzOjEwOjAwKQAAAAAAAPA/CiQIpgEQpgEiEzMxLjEyLjIwMTUgMjI6NTA6MDApAAAAAAAA8D8KJAinARCnASITMzEuMTIuMjAxNSAyMjozMDowMCkAAAAAAADwPwokCKgBEKgBIhMzMS4xMi4yMDE1IDIxOjUwOjAwKQAAAAAAAPA/CiQIqQEQqQEiEzMxLjEyLjIwMTUgMjE6MjA6MDApAAAAAAAA8D8KJAiqARCqASITMzEuMTIuMjAxNSAyMToxMDowMCkAAAAAAADwPwokCKsBEKsBIhMzMS4xMi4yMDE1IDIxOjAwOjAwKQAAAAAAAPA/CiQIrAEQrAEiEzMxLjEyLjIwMTUgMjA6NDA6MDApAAAAAAAA8D8KJAitARCtASITMzEuMTIuMjAxNSAyMDozMDowMCkAAAAAAADwPwokCK4BEK4BIhMzMS4xMi4yMDE1IDIwOjIwOjAwKQAAAAAAAPA/CiQIrwEQrwEiEzMxLjEyLjIwMTUgMjA6MDA6MDApAAAAAAAA8D8KJAiwARCwASITMzEuMTIuMjAxNSAxOToyMDowMCkAAAAAAADwPwokCLEBELEBIhMzMS4xMi4yMDE1IDE5OjEwOjAwKQAAAAAAAPA/CiQIsgEQsgEiEzMxLjEyLjIwMTUgMTg6NDA6MDApAAAAAAAA8D8KJAizARCzASITMzEuMTIuMjAxNSAxODozMDowMCkAAAAAAADwPwokCLQBELQBIhMzMS4xMi4yMDE1IDE4OjIwOjAwKQAAAAAAAPA/CiQItQEQtQEiEzMxLjEyLjIwMTUgMTc6NDA6MDApAAAAAAAA8D8KJAi2ARC2ASITMzEuMTIuMjAxNSAxNzozMDowMCkAAAAAAADwPwokCLcBELcBIhMzMS4xMi4yMDE1IDE3OjIwOjAwKQAAAAAAAPA/CiQIuAEQuAEiEzMxLjEyLjIwMTUgMTY6NDA6MDApAAAAAAAA8D8KJAi5ARC5ASITMzEuMTIuMjAxNSAxNjoxMDowMCkAAAAAAADwPwokCLoBELoBIhMzMS4xMi4yMDE1IDE1OjUwOjAwKQAAAAAAAPA/CiQIuwEQuwEiEzMxLjEyLjIwMTUgMTU6MjA6MDApAAAAAAAA8D8KJAi8ARC8ASITMzEuMTIuMjAxNSAxNToxMDowMCkAAAAAAADwPwokCL0BEL0BIhMzMS4xMi4yMDE1IDE1OjAwOjAwKQAAAAAAAPA/CiQIvgEQvgEiEzMxLjEyLjIwMTUgMTQ6NTA6MDApAAAAAAAA8D8KJAi/ARC/ASITMzEuMTIuMjAxNSAxNDoyMDowMCkAAAAAAADwPwokCMABEMABIhMzMS4xMi4yMDE1IDE0OjEwOjAwKQAAAAAAAPA/CiQIwQEQwQEiEzMxLjEyLjIwMTUgMTM6MzA6MDApAAAAAAAA8D8KJAjCARDCASITMzEuMTIuMjAxNSAxMjo0MDowMCkAAAAAAADwPwokCMMBEMMBIhMzMS4xMi4yMDE1IDEyOjEwOjAwKQAAAAAAAPA/CiQIxAEQxAEiEzMxLjEyLjIwMTUgMTE6NDA6MDApAAAAAAAA8D8KJAjFARDFASITMzEuMTIuMjAxNSAxMTozMDowMCkAAAAAAADwPwokCMYBEMYBIhMzMS4xMi4yMDE1IDExOjEwOjAwKQAAAAAAAPA/CiQIxwEQxwEiEzMxLjEyLjIwMTUgMTE6MDA6MDApAAAAAAAA8D8KJAjIARDIASITMzEuMTIuMjAxNSAxMDo0MDowMCkAAAAAAADwPwokCMkBEMkBIhMzMS4xMi4yMDE1IDEwOjEwOjAwKQAAAAAAAPA/CiQIygEQygEiEzMxLjEyLjIwMTUgMTA6MDA6MDApAAAAAAAA8D8KJAjLARDLASITMzEuMTIuMjAxNSAwOTowMDowMCkAAAAAAADwPwokCMwBEMwBIhMzMS4xMi4yMDE1IDA4OjUwOjAwKQAAAAAAAPA/CiQIzQEQzQEiEzMxLjEyLjIwMTUgMDg6MzA6MDApAAAAAAAA8D8KJAjOARDOASITMzEuMTIuMjAxNSAwODoyMDowMCkAAAAAAADwPwokCM8BEM8BIhMzMS4xMi4yMDE1IDA3OjAwOjAwKQAAAAAAAPA/CiQI0AEQ0AEiEzMxLjEyLjIwMTUgMDY6NDA6MDApAAAAAAAA8D8KJAjRARDRASITMzEuMTIuMjAxNSAwNjoxMDowMCkAAAAAAADwPwokCNIBENIBIhMzMS4xMi4yMDE1IDA1OjUwOjAwKQAAAAAAAPA/CiQI0wEQ0wEiEzMxLjEyLjIwMTUgMDM6NTA6MDApAAAAAAAA8D8KJAjUARDUASITMzEuMTIuMjAxNSAwMzozMDowMCkAAAAAAADwPwokCNUBENUBIhMzMS4xMi4yMDE1IDAzOjIwOjAwKQAAAAAAAPA/CiQI1gEQ1gEiEzMxLjEyLjIwMTUgMDI6NTA6MDApAAAAAAAA8D8KJAjXARDXASITMzEuMTIuMjAxNSAwMjo0MDowMCkAAAAAAADwPwokCNgBENgBIhMzMS4xMi4yMDE1IDAyOjIwOjAwKQAAAAAAAPA/CiQI2QEQ2QEiEzMxLjEyLjIwMTUgMDI6MTA6MDApAAAAAAAA8D8KJAjaARDaASITMzEuMTIuMjAxNSAwMTowMDowMCkAAAAAAADwPwokCNsBENsBIhMzMS4xMi4yMDE0IDIzOjUwOjAwKQAAAAAAAPA/CiQI3AEQ3AEiEzMxLjEyLjIwMTQgMjM6MjA6MDApAAAAAAAA8D8KJAjdARDdASITMzEuMTIuMjAxNCAyMjo0MDowMCkAAAAAAADwPwokCN4BEN4BIhMzMS4xMi4yMDE0IDIxOjUwOjAwKQAAAAAAAPA/CiQI3wEQ3wEiEzMxLjEyLjIwMTQgMjE6NDA6MDApAAAAAAAA8D8KJAjgARDgASITMzEuMTIuMjAxNCAyMDo0MDowMCkAAAAAAADwPwokCOEBEOEBIhMzMS4xMi4yMDE0IDIwOjEwOjAwKQAAAAAAAPA/CiQI4gEQ4gEiEzMxLjEyLjIwMTQgMTg6NTA6MDApAAAAAAAA8D8KJAjjARDjASITMzEuMTIuMjAxNCAxODozMDowMCkAAAAAAADwPwokCOQBEOQBIhMzMS4xMi4yMDE0IDE4OjIwOjAwKQAAAAAAAPA/CiQI5QEQ5QEiEzMxLjEyLjIwMTQgMTc6MjA6MDApAAAAAAAA8D8KJAjmARDmASITMzEuMTIuMjAxNCAxNzoxMDowMCkAAAAAAADwPwokCOcBEOcBIhMzMS4xMi4yMDE0IDE2OjUwOjAwKQAAAAAAAPA/CiQI6AEQ6AEiEzMxLjEyLjIwMTQgMTY6MjA6MDApAAAAAAAA8D8KJAjpARDpASITMzEuMTIuMjAxNCAxNjoxMDowMCkAAAAAAADwPwokCOoBEOoBIhMzMS4xMi4yMDE0IDE1OjUwOjAwKQAAAAAAAPA/CiQI6wEQ6wEiEzMxLjEyLjIwMTQgMTU6MzA6MDApAAAAAAAA8D8KJAjsARDsASITMzEuMTIuMjAxNCAxNTowMDowMCkAAAAAAADwPwokCO0BEO0BIhMzMS4xMi4yMDE0IDE0OjUwOjAwKQAAAAAAAPA/CiQI7gEQ7gEiEzMxLjEyLjIwMTQgMTQ6MzA6MDApAAAAAAAA8D8KJAjvARDvASITMzEuMTIuMjAxNCAxNDoyMDowMCkAAAAAAADwPwokCPABEPABIhMzMS4xMi4yMDE0IDE0OjEwOjAwKQAAAAAAAPA/CiQI8QEQ8QEiEzMxLjEyLjIwMTQgMTM6NDA6MDApAAAAAAAA8D8KJAjyARDyASITMzEuMTIuMjAxNCAxMzozMDowMCkAAAAAAADwPwokCPMBEPMBIhMzMS4xMi4yMDE0IDEzOjEwOjAwKQAAAAAAAPA/CiQI9AEQ9AEiEzMxLjEyLjIwMTQgMTE6MTA6MDApAAAAAAAA8D8KJAj1ARD1ASITMzEuMTIuMjAxNCAxMTowMDowMCkAAAAAAADwPwokCPYBEPYBIhMzMS4xMi4yMDE0IDEwOjUwOjAwKQAAAAAAAPA/CiQI9wEQ9wEiEzMxLjEyLjIwMTQgMTA6MzA6MDApAAAAAAAA8D8KJAj4ARD4ASITMzEuMTIuMjAxNCAwOTo1MDowMCkAAAAAAADwPwokCPkBEPkBIhMzMS4xMi4yMDE0IDA5OjMwOjAwKQAAAAAAAPA/CiQI+gEQ+gEiEzMxLjEyLjIwMTQgMDk6MjA6MDApAAAAAAAA8D8KJAj7ARD7ASITMzEuMTIuMjAxNCAwODo0MDowMCkAAAAAAADwPwokCPwBEPwBIhMzMS4xMi4yMDE0IDA4OjMwOjAwKQAAAAAAAPA/CiQI/QEQ/QEiEzMxLjEyLjIwMTQgMDg6MjA6MDApAAAAAAAA8D8KJAj+ARD+ASITMzEuMTIuMjAxNCAwODoxMDowMCkAAAAAAADwPwokCP8BEP8BIhMzMS4xMi4yMDE0IDA3OjQwOjAwKQAAAAAAAPA/CiQIgAIQgAIiEzMxLjEyLjIwMTQgMDc6MzA6MDApAAAAAAAA8D8KJAiBAhCBAiITMzEuMTIuMjAxNCAwNzoyMDowMCkAAAAAAADwPwokCIICEIICIhMzMS4xMi4yMDE0IDA2OjUwOjAwKQAAAAAAAPA/CiQIgwIQgwIiEzMxLjEyLjIwMTQgMDY6MzA6MDApAAAAAAAA8D8KJAiEAhCEAiITMzEuMTIuMjAxNCAwNDozMDowMCkAAAAAAADwPwokCIUCEIUCIhMzMS4xMi4yMDE0IDA0OjIwOjAwKQAAAAAAAPA/CiQIhgIQhgIiEzMxLjEyLjIwMTQgMDQ6MDA6MDApAAAAAAAA8D8KJAiHAhCHAiITMzEuMTIuMjAxNCAwMjo1MDowMCkAAAAAAADwPwokCIgCEIgCIhMzMS4xMi4yMDE0IDAyOjQwOjAwKQAAAAAAAPA/CiQIiQIQiQIiEzMxLjEyLjIwMTQgMDI6MzA6MDApAAAAAAAA8D8KJAiKAhCKAiITMzEuMTIuMjAxNCAwMjowMDowMCkAAAAAAADwPwokCIsCEIsCIhMzMS4xMi4yMDE0IDAwOjEwOjAwKQAAAAAAAPA/CiQIjAIQjAIiEzMxLjEyLjIwMTMgMjM6NTA6MDApAAAAAAAA8D8KJAiNAhCNAiITMzEuMTIuMjAxMyAyMzozMDowMCkAAAAAAADwPwokCI4CEI4CIhMzMS4xMi4yMDEzIDIzOjEwOjAwKQAAAAAAAPA/CiQIjwIQjwIiEzMxLjEyLjIwMTMgMjM6MDA6MDApAAAAAAAA8D8KJAiQAhCQAiITMzEuMTIuMjAxMyAyMjo1MDowMCkAAAAAAADwPwokCJECEJECIhMzMS4xMi4yMDEzIDIyOjQwOjAwKQAAAAAAAPA/CiQIkgIQkgIiEzMxLjEyLjIwMTMgMjI6MzA6MDApAAAAAAAA8D8KJAiTAhCTAiITMzEuMTIuMjAxMyAyMjoxMDowMCkAAAAAAADwPwokCJQCEJQCIhMzMS4xMi4yMDEzIDIxOjQwOjAwKQAAAAAAAPA/CiQIlQIQlQIiEzMxLjEyLjIwMTMgMjE6MzA6MDApAAAAAAAA8D8KJAiWAhCWAiITMzEuMTIuMjAxMyAyMToxMDowMCkAAAAAAADwPwokCJcCEJcCIhMzMS4xMi4yMDEzIDIxOjAwOjAwKQAAAAAAAPA/CiQImAIQmAIiEzMxLjEyLjIwMTMgMjA6MzA6MDApAAAAAAAA8D8KJAiZAhCZAiITMzEuMTIuMjAxMyAyMDoxMDowMCkAAAAAAADwPwokCJoCEJoCIhMzMS4xMi4yMDEzIDE5OjEwOjAwKQAAAAAAAPA/CiQImwIQmwIiEzMxLjEyLjIwMTMgMTk6MDA6MDApAAAAAAAA8D8KJAicAhCcAiITMzEuMTIuMjAxMyAxODoxMDowMCkAAAAAAADwPwokCJ0CEJ0CIhMzMS4xMi4yMDEzIDE3OjQwOjAwKQAAAAAAAPA/CiQIngIQngIiEzMxLjEyLjIwMTMgMTY6NTA6MDApAAAAAAAA8D8KJAifAhCfAiITMzEuMTIuMjAxMyAxNjozMDowMCkAAAAAAADwPwokCKACEKACIhMzMS4xMi4yMDEzIDE2OjIwOjAwKQAAAAAAAPA/CiQIoQIQoQIiEzMxLjEyLjIwMTMgMTY6MTA6MDApAAAAAAAA8D8KJAiiAhCiAiITMzEuMTIuMjAxMyAxNTozMDowMCkAAAAAAADwPwokCKMCEKMCIhMzMS4xMi4yMDEzIDE0OjQwOjAwKQAAAAAAAPA/CiQIpAIQpAIiEzMxLjEyLjIwMTMgMTQ6MTA6MDApAAAAAAAA8D8KJAilAhClAiITMzEuMTIuMjAxMyAxMzozMDowMCkAAAAAAADwPwokCKYCEKYCIhMzMS4xMi4yMDEzIDEyOjAwOjAwKQAAAAAAAPA/CiQIpwIQpwIiEzMxLjEyLjIwMTMgMTE6NTA6MDApAAAAAAAA8D8KJAioAhCoAiITMzEuMTIuMjAxMyAxMTo0MDowMCkAAAAAAADwPwokCKkCEKkCIhMzMS4xMi4yMDEzIDEwOjIwOjAwKQAAAAAAAPA/CiQIqgIQqgIiEzMxLjEyLjIwMTMgMDk6NDA6MDApAAAAAAAA8D8KJAirAhCrAiITMzEuMTIuMjAxMyAwOTozMDowMCkAAAAAAADwPwokCKwCEKwCIhMzMS4xMi4yMDEzIDA5OjIwOjAwKQAAAAAAAPA/CiQIrQIQrQIiEzMxLjEyLjIwMTMgMDg6NTA6MDApAAAAAAAA8D8KJAiuAhCuAiITMzEuMTIuMjAxMyAwODo0MDowMCkAAAAAAADwPwokCK8CEK8CIhMzMS4xMi4yMDEzIDA4OjMwOjAwKQAAAAAAAPA/CiQIsAIQsAIiEzMxLjEyLjIwMTMgMDg6MjA6MDApAAAAAAAA8D8KJAixAhCxAiITMzEuMTIuMjAxMyAwNzoxMDowMCkAAAAAAADwPwokCLICELICIhMzMS4xMi4yMDEzIDA3OjAwOjAwKQAAAAAAAPA/CiQIswIQswIiEzMxLjEyLjIwMTMgMDY6MzA6MDApAAAAAAAA8D8KJAi0AhC0AiITMzEuMTIuMjAxMyAwNjoyMDowMCkAAAAAAADwPwokCLUCELUCIhMzMS4xMi4yMDEzIDA2OjEwOjAwKQAAAAAAAPA/CiQItgIQtgIiEzMxLjEyLjIwMTMgMDU6MzA6MDApAAAAAAAA8D8KJAi3AhC3AiITMzEuMTIuMjAxMyAwNToxMDowMCkAAAAAAADwPwokCLgCELgCIhMzMS4xMi4yMDEzIDA0OjUwOjAwKQAAAAAAAPA/CiQIuQIQuQIiEzMxLjEyLjIwMTMgMDM6MTA6MDApAAAAAAAA8D8KJAi6AhC6AiITMzEuMTIuMjAxMyAwMjozMDowMCkAAAAAAADwPwokCLsCELsCIhMzMS4xMi4yMDEzIDAyOjEwOjAwKQAAAAAAAPA/CiQIvAIQvAIiEzMxLjEyLjIwMTMgMDI6MDA6MDApAAAAAAAA8D8KJAi9AhC9AiITMzEuMTIuMjAxMyAwMToxMDowMCkAAAAAAADwPwokCL4CEL4CIhMzMS4xMi4yMDEzIDAwOjIwOjAwKQAAAAAAAPA/CiQIvwIQvwIiEzMxLjEyLjIwMTIgMjM6NDA6MDApAAAAAAAA8D8KJAjAAhDAAiITMzEuMTIuMjAxMiAyMzoyMDowMCkAAAAAAADwPwokCMECEMECIhMzMS4xMi4yMDEyIDIzOjAwOjAwKQAAAAAAAPA/CiQIwgIQwgIiEzMxLjEyLjIwMTIgMjI6MDA6MDApAAAAAAAA8D8KJAjDAhDDAiITMzEuMTIuMjAxMiAyMTo1MDowMCkAAAAAAADwPwokCMQCEMQCIhMzMS4xMi4yMDEyIDIxOjMwOjAwKQAAAAAAAPA/CiQIxQIQxQIiEzMxLjEyLjIwMTIgMjE6MjA6MDApAAAAAAAA8D8KJAjGAhDGAiITMzEuMTIuMjAxMiAyMTowMDowMCkAAAAAAADwPwokCMcCEMcCIhMzMS4xMi4yMDEyIDIwOjMwOjAwKQAAAAAAAPA/CiQIyAIQyAIiEzMxLjEyLjIwMTIgMjA6MDA6MDApAAAAAAAA8D8KJAjJAhDJAiITMzEuMTIuMjAxMiAxOTozMDowMCkAAAAAAADwPwokCMoCEMoCIhMzMS4xMi4yMDEyIDE4OjEwOjAwKQAAAAAAAPA/CiQIywIQywIiEzMxLjEyLjIwMTIgMTc6NTA6MDApAAAAAAAA8D8KJAjMAhDMAiITMzEuMTIuMjAxMiAxNzo0MDowMCkAAAAAAADwPwokCM0CEM0CIhMzMS4xMi4yMDEyIDE3OjEwOjAwKQAAAAAAAPA/CiQIzgIQzgIiEzMxLjEyLjIwMTIgMTc6MDA6MDApAAAAAAAA8D8KJAjPAhDPAiITMzEuMTIuMjAxMiAxNjo1MDowMCkAAAAAAADwPwokCNACENACIhMzMS4xMi4yMDEyIDE2OjQwOjAwKQAAAAAAAPA/CiQI0QIQ0QIiEzMxLjEyLjIwMTIgMTY6MzA6MDApAAAAAAAA8D8KJAjSAhDSAiITMzEuMTIuMjAxMiAxNTo0MDowMCkAAAAAAADwPwokCNMCENMCIhMzMS4xMi4yMDEyIDE1OjMwOjAwKQAAAAAAAPA/CiQI1AIQ1AIiEzMxLjEyLjIwMTIgMTU6MDA6MDApAAAAAAAA8D8KJAjVAhDVAiITMzEuMTIuMjAxMiAxNDo0MDowMCkAAAAAAADwPwokCNYCENYCIhMzMS4xMi4yMDEyIDE0OjMwOjAwKQAAAAAAAPA/CiQI1wIQ1wIiEzMxLjEyLjIwMTIgMTM6NDA6MDApAAAAAAAA8D8KJAjYAhDYAiITMzEuMTIuMjAxMiAxMzoyMDowMCkAAAAAAADwPwokCNkCENkCIhMzMS4xMi4yMDEyIDEyOjMwOjAwKQAAAAAAAPA/CiQI2gIQ2gIiEzMxLjEyLjIwMTIgMTI6MTA6MDApAAAAAAAA8D8KJAjbAhDbAiITMzEuMTIuMjAxMiAxMTowMDowMCkAAAAAAADwPwokCNwCENwCIhMzMS4xMi4yMDEyIDEwOjEwOjAwKQAAAAAAAPA/CiQI3QIQ3QIiEzMxLjEyLjIwMTIgMDk6NTA6MDApAAAAAAAA8D8KJAjeAhDeAiITMzEuMTIuMjAxMiAwOTo0MDowMCkAAAAAAADwPwokCN8CEN8CIhMzMS4xMi4yMDEyIDA5OjMwOjAwKQAAAAAAAPA/CiQI4AIQ4AIiEzMxLjEyLjIwMTIgMDk6MjA6MDApAAAAAAAA8D8KJAjhAhDhAiITMzEuMTIuMjAxMiAwODozMDowMCkAAAAAAADwPwokCOICEOICIhMzMS4xMi4yMDEyIDA3OjQwOjAwKQAAAAAAAPA/CiQI4wIQ4wIiEzMxLjEyLjIwMTIgMDc6MzA6MDApAAAAAAAA8D8KJAjkAhDkAiITMzEuMTIuMjAxMiAwNjo1MDowMCkAAAAAAADwPwokCOUCEOUCIhMzMS4xMi4yMDEyIDA1OjUwOjAwKQAAAAAAAPA/CiQI5gIQ5gIiEzMxLjEyLjIwMTIgMDQ6MzA6MDApAAAAAAAA8D8KJAjnAhDnAiITMzEuMTIuMjAxMiAwNDoxMDowMCkAAAAAAADwPwokCOgCEOgCIhMzMS4xMi4yMDEyIDAzOjUwOjAwKQAAAAAAAPA/CiQI6QIQ6QIiEzMxLjEyLjIwMTIgMDM6NDA6MDApAAAAAAAA8D8KJAjqAhDqAiITMzEuMTIuMjAxMiAwMzoyMDowMCkAAAAAAADwPwokCOsCEOsCIhMzMS4xMi4yMDEyIDAyOjUwOjAwKQAAAAAAAPA/CiQI7AIQ7AIiEzMxLjEyLjIwMTIgMDI6MzA6MDApAAAAAAAA8D8KJAjtAhDtAiITMzEuMTIuMjAxMiAwMTo0MDowMCkAAAAAAADwPwokCO4CEO4CIhMzMS4xMi4yMDExIDIzOjQwOjAwKQAAAAAAAPA/CiQI7wIQ7wIiEzMxLjEyLjIwMTEgMjM6MzA6MDApAAAAAAAA8D8KJAjwAhDwAiITMzEuMTIuMjAxMSAyMjo0MDowMCkAAAAAAADwPwokCPECEPECIhMzMS4xMi4yMDExIDIxOjQwOjAwKQAAAAAAAPA/CiQI8gIQ8gIiEzMxLjEyLjIwMTEgMjA6MjA6MDApAAAAAAAA8D8KJAjzAhDzAiITMzEuMTIuMjAxMSAxOTo1MDowMCkAAAAAAADwPwokCPQCEPQCIhMzMS4xMi4yMDExIDE5OjMwOjAwKQAAAAAAAPA/CiQI9QIQ9QIiEzMxLjEyLjIwMTEgMTg6NTA6MDApAAAAAAAA8D8KJAj2AhD2AiITMzEuMTIuMjAxMSAxODo0MDowMCkAAAAAAADwPwokCPcCEPcCIhMzMS4xMi4yMDExIDE4OjMwOjAwKQAAAAAAAPA/CiQI+AIQ+AIiEzMxLjEyLjIwMTEgMTc6NTA6MDApAAAAAAAA8D8KJAj5AhD5AiITMzEuMTIuMjAxMSAxNzozMDowMCkAAAAAAADwPwokCPoCEPoCIhMzMS4xMi4yMDExIDE2OjUwOjAwKQAAAAAAAPA/CiQI+wIQ+wIiEzMxLjEyLjIwMTEgMTY6NDA6MDApAAAAAAAA8D8KJAj8AhD8AiITMzEuMTIuMjAxMSAxNTowMDowMCkAAAAAAADwPwokCP0CEP0CIhMzMS4xMi4yMDExIDE0OjQwOjAwKQAAAAAAAPA/CiQI/gIQ/gIiEzMxLjEyLjIwMTEgMTQ6MjA6MDApAAAAAAAA8D8KJAj/AhD/AiITMzEuMTIuMjAxMSAxNDoxMDowMCkAAAAAAADwPwokCIADEIADIhMzMS4xMi4yMDExIDEzOjUwOjAwKQAAAAAAAPA/CiQIgQMQgQMiEzMxLjEyLjIwMTEgMTM6MjA6MDApAAAAAAAA8D8KJAiCAxCCAyITMzEuMTIuMjAxMSAxMzoxMDowMCkAAAAAAADwPwokCIMDEIMDIhMzMS4xMi4yMDExIDEzOjAwOjAwKQAAAAAAAPA/CiQIhAMQhAMiEzMxLjEyLjIwMTEgMTI6MzA6MDApAAAAAAAA8D8KJAiFAxCFAyITMzEuMTIuMjAxMSAxMToyMDowMCkAAAAAAADwPwokCIYDEIYDIhMzMS4xMi4yMDExIDEwOjIwOjAwKQAAAAAAAPA/CiQIhwMQhwMiEzMxLjEyLjIwMTEgMDk6NTA6MDApAAAAAAAA8D8KJAiIAxCIAyITMzEuMTIuMjAxMSAwOToyMDowMCkAAAAAAADwPwokCIkDEIkDIhMzMS4xMi4yMDExIDA5OjEwOjAwKQAAAAAAAPA/CiQIigMQigMiEzMxLjEyLjIwMTEgMDk6MDA6MDApAAAAAAAA8D8KJAiLAxCLAyITMzEuMTIuMjAxMSAwODo0MDowMCkAAAAAAADwPwokCIwDEIwDIhMzMS4xMi4yMDExIDA3OjUwOjAwKQAAAAAAAPA/CiQIjQMQjQMiEzMxLjEyLjIwMTEgMDc6NDA6MDApAAAAAAAA8D8KJAiOAxCOAyITMzEuMTIuMjAxMSAwNzoyMDowMCkAAAAAAADwPwokCI8DEI8DIhMzMS4xMi4yMDExIDA1OjQwOjAwKQAAAAAAAPA/CiQIkAMQkAMiEzMxLjEyLjIwMTEgMDU6MjA6MDApAAAAAAAA8D8KJAiRAxCRAyITMzEuMTIuMjAxMSAwNToxMDowMCkAAAAAAADwPwokCJIDEJIDIhMzMS4xMi4yMDExIDAyOjUwOjAwKQAAAAAAAPA/CiQIkwMQkwMiEzMxLjEyLjIwMTEgMDI6MzA6MDApAAAAAAAA8D8KJAiUAxCUAyITMzEuMTIuMjAxMSAwMTozMDowMCkAAAAAAADwPwokCJUDEJUDIhMzMS4xMi4yMDExIDAwOjQwOjAwKQAAAAAAAPA/CiQIlgMQlgMiEzMxLjEyLjIwMTEgMDA6MTA6MDApAAAAAAAA8D8KJAiXAxCXAyITMzEuMTIuMjAxMCAyMzo0MDowMCkAAAAAAADwPwokCJgDEJgDIhMzMS4xMi4yMDEwIDIyOjUwOjAwKQAAAAAAAPA/CiQImQMQmQMiEzMxLjEyLjIwMTAgMjI6MzA6MDApAAAAAAAA8D8KJAiaAxCaAyITMzEuMTIuMjAxMCAyMjoyMDowMCkAAAAAAADwPwokCJsDEJsDIhMzMS4xMi4yMDEwIDIxOjIwOjAwKQAAAAAAAPA/CiQInAMQnAMiEzMxLjEyLjIwMTAgMjE6MTA6MDApAAAAAAAA8D8KJAidAxCdAyITMzEuMTIuMjAxMCAyMDoxMDowMCkAAAAAAADwPwokCJ4DEJ4DIhMzMS4xMi4yMDEwIDIwOjAwOjAwKQAAAAAAAPA/CiQInwMQnwMiEzMxLjEyLjIwMTAgMTk6NTA6MDApAAAAAAAA8D8KJAigAxCgAyITMzEuMTIuMjAxMCAxOToyMDowMCkAAAAAAADwPwokCKEDEKEDIhMzMS4xMi4yMDEwIDE5OjEwOjAwKQAAAAAAAPA/CiQIogMQogMiEzMxLjEyLjIwMTAgMTg6MzA6MDApAAAAAAAA8D8KJAijAxCjAyITMzEuMTIuMjAxMCAxODoyMDowMCkAAAAAAADwPwokCKQDEKQDIhMzMS4xMi4yMDEwIDE4OjEwOjAwKQAAAAAAAPA/CiQIpQMQpQMiEzMxLjEyLjIwMTAgMTc6MzA6MDApAAAAAAAA8D8KJAimAxCmAyITMzEuMTIuMjAxMCAxNzoxMDowMCkAAAAAAADwPwokCKcDEKcDIhMzMS4xMi4yMDEwIDE2OjUwOjAwKQAAAAAAAPA/CiQIqAMQqAMiEzMxLjEyLjIwMTAgMTY6MzA6MDApAAAAAAAA8D8KJAipAxCpAyITMzEuMTIuMjAxMCAxNDo0MDowMCkAAAAAAADwPwokCKoDEKoDIhMzMS4xMi4yMDEwIDEzOjMwOjAwKQAAAAAAAPA/CiQIqwMQqwMiEzMxLjEyLjIwMTAgMTM6MjA6MDApAAAAAAAA8D8KJAisAxCsAyITMzEuMTIuMjAxMCAxMjoxMDowMCkAAAAAAADwPwokCK0DEK0DIhMzMS4xMi4yMDEwIDEyOjAwOjAwKQAAAAAAAPA/CiQIrgMQrgMiEzMxLjEyLjIwMTAgMTE6NTA6MDApAAAAAAAA8D8KJAivAxCvAyITMzEuMTIuMjAxMCAxMTo0MDowMCkAAAAAAADwPwokCLADELADIhMzMS4xMi4yMDEwIDEwOjAwOjAwKQAAAAAAAPA/CiQIsQMQsQMiEzMxLjEyLjIwMTAgMDk6NDA6MDApAAAAAAAA8D8KJAiyAxCyAyITMzEuMTIuMjAxMCAwOToxMDowMCkAAAAAAADwPwokCLMDELMDIhMzMS4xMi4yMDEwIDA5OjAwOjAwKQAAAAAAAPA/CiQItAMQtAMiEzMxLjEyLjIwMTAgMDg6MjA6MDApAAAAAAAA8D8KJAi1AxC1AyITMzEuMTIuMjAxMCAwNzozMDowMCkAAAAAAADwPwokCLYDELYDIhMzMS4xMi4yMDEwIDA3OjIwOjAwKQAAAAAAAPA/CiQItwMQtwMiEzMxLjEyLjIwMTAgMDY6NTA6MDApAAAAAAAA8D8KJAi4AxC4AyITMzEuMTIuMjAxMCAwNjoyMDowMCkAAAAAAADwPwokCLkDELkDIhMzMS4xMi4yMDEwIDA1OjQwOjAwKQAAAAAAAPA/CiQIugMQugMiEzMxLjEyLjIwMTAgMDU6MzA6MDApAAAAAAAA8D8KJAi7AxC7AyITMzEuMTIuMjAxMCAwNTowMDowMCkAAAAAAADwPwokCLwDELwDIhMzMS4xMi4yMDEwIDA0OjQwOjAwKQAAAAAAAPA/CiQIvQMQvQMiEzMxLjEyLjIwMTAgMDQ6MjA6MDApAAAAAAAA8D8KJAi+AxC+AyITMzEuMTIuMjAxMCAwNDoxMDowMCkAAAAAAADwPwokCL8DEL8DIhMzMS4xMi4yMDEwIDAzOjUwOjAwKQAAAAAAAPA/CiQIwAMQwAMiEzMxLjEyLjIwMTAgMDM6MjA6MDApAAAAAAAA8D8KJAjBAxDBAyITMzEuMTIuMjAxMCAwMzoxMDowMCkAAAAAAADwPwokCMIDEMIDIhMzMS4xMi4yMDEwIDAzOjAwOjAwKQAAAAAAAPA/CiQIwwMQwwMiEzMxLjEyLjIwMTAgMDI6MTA6MDApAAAAAAAA8D8KJAjEAxDEAyITMzEuMTIuMjAxMCAwMTo1MDowMCkAAAAAAADwPwokCMUDEMUDIhMzMS4xMi4yMDEwIDAxOjMwOjAwKQAAAAAAAPA/CiQIxgMQxgMiEzMxLjEyLjIwMTAgMDE6MjA6MDApAAAAAAAA8D8KJAjHAxDHAyITMzEuMTIuMjAwOSAyMzo0MDowMCkAAAAAAADwPwokCMgDEMgDIhMzMS4xMi4yMDA5IDIzOjEwOjAwKQAAAAAAAPA/CiQIyQMQyQMiEzMxLjEyLjIwMDkgMjI6MjA6MDApAAAAAAAA8D8KJAjKAxDKAyITMzEuMTIuMjAwOSAyMjowMDowMCkAAAAAAADwPwokCMsDEMsDIhMzMS4xMi4yMDA5IDIwOjUwOjAwKQAAAAAAAPA/CiQIzAMQzAMiEzMxLjEyLjIwMDkgMjA6MTA6MDApAAAAAAAA8D8KJAjNAxDNAyITMzEuMTIuMjAwOSAxOTo1MDowMCkAAAAAAADwPwokCM4DEM4DIhMzMS4xMi4yMDA5IDE5OjAwOjAwKQAAAAAAAPA/CiQIzwMQzwMiEzMxLjEyLjIwMDkgMTg6MTA6MDApAAAAAAAA8D8KJAjQAxDQAyITMzEuMTIuMjAwOSAxNjo1MDowMCkAAAAAAADwPwokCNEDENEDIhMzMS4xMi4yMDA5IDE1OjMwOjAwKQAAAAAAAPA/CiQI0gMQ0gMiEzMxLjEyLjIwMDkgMTQ6NDA6MDApAAAAAAAA8D8KJAjTAxDTAyITMzEuMTIuMjAwOSAxNDozMDowMCkAAAAAAADwPwokCNQDENQDIhMzMS4xMi4yMDA5IDE0OjAwOjAwKQAAAAAAAPA/CiQI1QMQ1QMiEzMxLjEyLjIwMDkgMTM6MzA6MDApAAAAAAAA8D8KJAjWAxDWAyITMzEuMTIuMjAwOSAxMzoyMDowMCkAAAAAAADwPwokCNcDENcDIhMzMS4xMi4yMDA5IDEzOjAwOjAwKQAAAAAAAPA/CiQI2AMQ2AMiEzMxLjEyLjIwMDkgMTI6MTA6MDApAAAAAAAA8D8KJAjZAxDZAyITMzEuMTIuMjAwOSAxMTowMDowMCkAAAAAAADwPwokCNoDENoDIhMzMS4xMi4yMDA5IDEwOjEwOjAwKQAAAAAAAPA/CiQI2wMQ2wMiEzMxLjEyLjIwMDkgMDk6NTA6MDApAAAAAAAA8D8KJAjcAxDcAyITMzEuMTIuMjAwOSAwODo0MDowMCkAAAAAAADwPwokCN0DEN0DIhMzMS4xMi4yMDA5IDA4OjAwOjAwKQAAAAAAAPA/CiQI3gMQ3gMiEzMxLjEyLjIwMDkgMDc6NTA6MDApAAAAAAAA8D8KJAjfAxDfAyITMzEuMTIuMjAwOSAwNzowMDowMCkAAAAAAADwPwokCOADEOADIhMzMS4xMi4yMDA5IDA1OjQwOjAwKQAAAAAAAPA/CiQI4QMQ4QMiEzMxLjEyLjIwMDkgMDU6MDA6MDApAAAAAAAA8D8KJAjiAxDiAyITMzEuMTIuMjAwOSAwNDo1MDowMCkAAAAAAADwPwokCOMDEOMDIhMzMS4xMi4yMDA5IDA0OjEwOjAwKQAAAAAAAPA/CiQI5AMQ5AMiEzMxLjEyLjIwMDkgMDQ6MDA6MDApAAAAAAAA8D8KJAjlAxDlAyITMzEuMTIuMjAwOSAwMjozMDowMCkAAAAAAADwPwokCOYDEOYDIhMzMS4xMi4yMDA5IDAyOjEwOjAwKQAAAAAAAPA/CiQI5wMQ5wMiEzMxLjEyLjIwMDkgMDE6NDA6MDApAAAAAAAA8D8KJAjoAxDoAyITMzEuMTIuMjAwOSAwMTozMDowMCkAAAAAAADwPwokCOkDEOkDIhMzMS4xMi4yMDA5IDAxOjAwOjAwKQAAAAAAAPA/CiQI6gMQ6gMiEzMxLjEyLjIwMDkgMDA6NDA6MDApAAAAAAAA8D8KJAjrAxDrAyITMzEuMTIuMjAwOSAwMDoyMDowMCkAAAAAAADwPwokCOwDEOwDIhMzMS4xMC4yMDE2IDIzOjUwOjAwKQAAAAAAAPA/CiQI7QMQ7QMiEzMxLjEwLjIwMTYgMjM6NDA6MDApAAAAAAAA8D8KJAjuAxDuAyITMzEuMTAuMjAxNiAyMzozMDowMCkAAAAAAADwPwokCO8DEO8DIhMzMS4xMC4yMDE2IDIzOjEwOjAwKQAAAAAAAPA/CiQI8AMQ8AMiEzMxLjEwLjIwMTYgMjM6MDA6MDApAAAAAAAA8D8KJAjxAxDxAyITMzEuMTAuMjAxNiAyMjozMDowMCkAAAAAAADwPwokCPIDEPIDIhMzMS4xMC4yMDE2IDIxOjQwOjAwKQAAAAAAAPA/CiQI8wMQ8wMiEzMxLjEwLjIwMTYgMjE6MzA6MDApAAAAAAAA8D8KJAj0AxD0AyITMzEuMTAuMjAxNiAyMTowMDowMCkAAAAAAADwPwokCPUDEPUDIhMzMS4xMC4yMDE2IDIwOjUwOjAwKQAAAAAAAPA/CiQI9gMQ9gMiEzMxLjEwLjIwMTYgMjA6NDA6MDApAAAAAAAA8D8KJAj3AxD3AyITMzEuMTAuMjAxNiAxOTo1MDowMCkAAAAAAADwPwokCPgDEPgDIhMzMS4xMC4yMDE2IDE5OjIwOjAwKQAAAAAAAPA/CiQI+QMQ+QMiEzMxLjEwLjIwMTYgMTk6MDA6MDApAAAAAAAA8D8KJAj6AxD6AyITMzEuMTAuMjAxNiAxODo1MDowMCkAAAAAAADwPwokCPsDEPsDIhMzMS4xMC4yMDE2IDE4OjAwOjAwKQAAAAAAAPA/CiQI/AMQ/AMiEzMxLjEwLjIwMTYgMTc6MzA6MDApAAAAAAAA8D8KJAj9AxD9AyITMzEuMTAuMjAxNiAxNzoyMDowMCkAAAAAAADwPwokCP4DEP4DIhMzMS4xMC4yMDE2IDE3OjEwOjAwKQAAAAAAAPA/CiQI/wMQ/wMiEzMxLjEwLjIwMTYgMTc6MDA6MDApAAAAAAAA8D8KJAiABBCABCITMzEuMTAuMjAxNiAxNjo1MDowMCkAAAAAAADwPwokCIEEEIEEIhMzMS4xMC4yMDE2IDE2OjQwOjAwKQAAAAAAAPA/CiQIggQQggQiEzMxLjEwLjIwMTYgMTY6MzA6MDApAAAAAAAA8D8KJAiDBBCDBCITMzEuMTAuMjAxNiAxNjowMDowMCkAAAAAAADwPwokCIQEEIQEIhMzMS4xMC4yMDE2IDE1OjQwOjAwKQAAAAAAAPA/CiQIhQQQhQQiEzMxLjEwLjIwMTYgMTQ6MDA6MDApAAAAAAAA8D8KJAiGBBCGBCITMzEuMTAuMjAxNiAxMzoxMDowMCkAAAAAAADwPwokCIcEEIcEIhMzMS4xMC4yMDE2IDEzOjAwOjAwKQAAAAAAAPA/CiQIiAQQiAQiEzMxLjEwLjIwMTYgMTI6NTA6MDApAAAAAAAA8D8KJAiJBBCJBCITMzEuMTAuMjAxNiAxMjoyMDowMCkAAAAAAADwPwokCIoEEIoEIhMzMS4xMC4yMDE2IDExOjIwOjAwKQAAAAAAAPA/CiQIiwQQiwQiEzMxLjEwLjIwMTYgMTA6NTA6MDApAAAAAAAA8D8KJAiMBBCMBCITMzEuMTAuMjAxNiAxMDo0MDowMCkAAAAAAADwPwokCI0EEI0EIhMzMS4xMC4yMDE2IDEwOjIwOjAwKQAAAAAAAPA/CiQIjgQQjgQiEzMxLjEwLjIwMTYgMTA6MTA6MDApAAAAAAAA8D8KJAiPBBCPBCITMzEuMTAuMjAxNiAwOTowMDowMCkAAAAAAADwPwokCJAEEJAEIhMzMS4xMC4yMDE2IDA4OjUwOjAwKQAAAAAAAPA/CiQIkQQQkQQiEzMxLjEwLjIwMTYgMDg6NDA6MDApAAAAAAAA8D8KJAiSBBCSBCITMzEuMTAuMjAxNiAwODoyMDowMCkAAAAAAADwPwokCJMEEJMEIhMzMS4xMC4yMDE2IDA3OjAwOjAwKQAAAAAAAPA/CiQIlAQQlAQiEzMxLjEwLjIwMTYgMDU6NTA6MDApAAAAAAAA8D8KJAiVBBCVBCITMzEuMTAuMjAxNiAwNToxMDowMCkAAAAAAADwPwokCJYEEJYEIhMzMS4xMC4yMDE2IDA1OjAwOjAwKQAAAAAAAPA/CiQIlwQQlwQiEzMxLjEwLjIwMTYgMDQ6NTA6MDApAAAAAAAA8D8KJAiYBBCYBCITMzEuMTAuMjAxNiAwNDowMDowMCkAAAAAAADwPwokCJkEEJkEIhMzMS4xMC4yMDE2IDAzOjQwOjAwKQAAAAAAAPA/CiQImgQQmgQiEzMxLjEwLjIwMTYgMDM6MjA6MDApAAAAAAAA8D8KJAibBBCbBCITMzEuMTAuMjAxNiAwMjozMDowMCkAAAAAAADwPwokCJwEEJwEIhMzMS4xMC4yMDE2IDAxOjUwOjAwKQAAAAAAAPA/CiQInQQQnQQiEzMxLjEwLjIwMTYgMDA6NDA6MDApAAAAAAAA8D8KJAieBBCeBCITMzEuMTAuMjAxNiAwMDozMDowMCkAAAAAAADwPwokCJ8EEJ8EIhMzMS4xMC4yMDE2IDAwOjIwOjAwKQAAAAAAAPA/CiQIoAQQoAQiEzMxLjEwLjIwMTUgMjE6MzA6MDApAAAAAAAA8D8KJAihBBChBCITMzEuMTAuMjAxNSAyMToxMDowMCkAAAAAAADwPwokCKIEEKIEIhMzMS4xMC4yMDE1IDIxOjAwOjAwKQAAAAAAAPA/CiQIowQQowQiEzMxLjEwLjIwMTUgMTk6NDA6MDApAAAAAAAA8D8KJAikBBCkBCITMzEuMTAuMjAxNSAxOTozMDowMCkAAAAAAADwPwokCKUEEKUEIhMzMS4xMC4yMDE1IDE5OjIwOjAwKQAAAAAAAPA/CiQIpgQQpgQiEzMxLjEwLjIwMTUgMTk6MDA6MDApAAAAAAAA8D8KJAinBBCnBCITMzEuMTAuMjAxNSAxODoyMDowMCkAAAAAAADwPwokCKgEEKgEIhMzMS4xMC4yMDE1IDE4OjEwOjAwKQAAAAAAAPA/CiQIqQQQqQQiEzMxLjEwLjIwMTUgMTc6MTA6MDApAAAAAAAA8D8KJAiqBBCqBCITMzEuMTAuMjAxNSAxNjo0MDowMCkAAAAAAADwPwokCKsEEKsEIhMzMS4xMC4yMDE1IDE1OjUwOjAwKQAAAAAAAPA/CiQIrAQQrAQiEzMxLjEwLjIwMTUgMTU6MjA6MDApAAAAAAAA8D8KJAitBBCtBCITMzEuMTAuMjAxNSAxNDo0MDowMCkAAAAAAADwPwokCK4EEK4EIhMzMS4xMC4yMDE1IDE0OjAwOjAwKQAAAAAAAPA/CiQIrwQQrwQiEzMxLjEwLjIwMTUgMTM6NTA6MDApAAAAAAAA8D8KJAiwBBCwBCITMzEuMTAuMjAxNSAxMzo0MDowMCkAAAAAAADwPwokCLEEELEEIhMzMS4xMC4yMDE1IDEzOjMwOjAwKQAAAAAAAPA/CiQIsgQQsgQiEzMxLjEwLjIwMTUgMTM6MTA6MDApAAAAAAAA8D8KJAizBBCzBCITMzEuMTAuMjAxNSAxMjo1MDowMCkAAAAAAADwPwokCLQEELQEIhMzMS4xMC4yMDE1IDEyOjQwOjAwKQAAAAAAAPA/CiQItQQQtQQiEzMxLjEwLjIwMTUgMTI6MzA6MDApAAAAAAAA8D8KJAi2BBC2BCITMzEuMTAuMjAxNSAxMjoyMDowMCkAAAAAAADwPwokCLcEELcEIhMzMS4xMC4yMDE1IDEyOjAwOjAwKQAAAAAAAPA/CiQIuAQQuAQiEzMxLjEwLjIwMTUgMTE6MzA6MDApAAAAAAAA8D8KJAi5BBC5BCITMzEuMTAuMjAxNSAxMToxMDowMCkAAAAAAADwPwokCLoEELoEIhMzMS4xMC4yMDE1IDExOjAwOjAwKQAAAAAAAPA/CiQIuwQQuwQiEzMxLjEwLjIwMTUgMTA6MzA6MDApAAAAAAAA8D8KJAi8BBC8BCITMzEuMTAuMjAxNSAwOTowMDowMCkAAAAAAADwPwokCL0EEL0EIhMzMS4xMC4yMDE1IDA4OjUwOjAwKQAAAAAAAPA/CiQIvgQQvgQiEzMxLjEwLjIwMTUgMDg6MzA6MDApAAAAAAAA8D8KJAi/BBC/BCITMzEuMTAuMjAxNSAwODowMDowMCkAAAAAAADwPwokCMAEEMAEIhMzMS4xMC4yMDE1IDA3OjUwOjAwKQAAAAAAAPA/CiQIwQQQwQQiEzMxLjEwLjIwMTUgMDc6MzA6MDApAAAAAAAA8D8KJAjCBBDCBCITMzEuMTAuMjAxNSAwNjozMDowMCkAAAAAAADwPwokCMMEEMMEIhMzMS4xMC4yMDE1IDA2OjIwOjAwKQAAAAAAAPA/CiQIxAQQxAQiEzMxLjEwLjIwMTUgMDU6MzA6MDApAAAAAAAA8D8KJAjFBBDFBCITMzEuMTAuMjAxNSAwNDo1MDowMCkAAAAAAADwPwokCMYEEMYEIhMzMS4xMC4yMDE1IDAzOjQwOjAwKQAAAAAAAPA/CiQIxwQQxwQiEzMxLjEwLjIwMTUgMDM6MzA6MDApAAAAAAAA8D8KJAjIBBDIBCITMzEuMTAuMjAxNSAwMjo0MDowMCkAAAAAAADwPwokCMkEEMkEIhMzMS4xMC4yMDE1IDAyOjMwOjAwKQAAAAAAAPA/CiQIygQQygQiEzMxLjEwLjIwMTUgMDI6MjA6MDApAAAAAAAA8D8KJAjLBBDLBCITMzEuMTAuMjAxNSAwMToyMDowMCkAAAAAAADwPwokCMwEEMwEIhMzMS4xMC4yMDE1IDAwOjAwOjAwKQAAAAAAAPA/CiQIzQQQzQQiEzMxLjEwLjIwMTQgMjM6NDA6MDApAAAAAAAA8D8KJAjOBBDOBCITMzEuMTAuMjAxNCAyMzozMDowMCkAAAAAAADwPwokCM8EEM8EIhMzMS4xMC4yMDE0IDIzOjEwOjAwKQAAAAAAAPA/CiQI0AQQ0AQiEzMxLjEwLjIwMTQgMjI6MjA6MDApAAAAAAAA8D8KJAjRBBDRBCITMzEuMTAuMjAxNCAyMjoxMDowMCkAAAAAAADwPwokCNIEENIEIhMzMS4xMC4yMDE0IDIxOjUwOjAwKQAAAAAAAPA/CiQI0wQQ0wQiEzMxLjEwLjIwMTQgMjA6NTA6MDApAAAAAAAA8D8KJAjUBBDUBCITMzEuMTAuMjAxNCAyMDoyMDowMCkAAAAAAADwPwokCNUEENUEIhMzMS4xMC4yMDE0IDE5OjIwOjAwKQAAAAAAAPA/CiQI1gQQ1gQiEzMxLjEwLjIwMTQgMTg6MzA6MDApAAAAAAAA8D8KJAjXBBDXBCITMzEuMTAuMjAxNCAxODowMDowMCkAAAAAAADwPwokCNgEENgEIhMzMS4xMC4yMDE0IDE3OjMwOjAwKQAAAAAAAPA/CiQI2QQQ2QQiEzMxLjEwLjIwMTQgMTc6MDA6MDApAAAAAAAA8D8KJAjaBBDaBCITMzEuMTAuMjAxNCAxNjo1MDowMCkAAAAAAADwPwokCNsEENsEIhMzMS4xMC4yMDE0IDE2OjMwOjAwKQAAAAAAAPA/CiQI3AQQ3AQiEzMxLjEwLjIwMTQgMTY6MjA6MDApAAAAAAAA8D8KJAjdBBDdBCITMzEuMTAuMjAxNCAxNjowMDowMCkAAAAAAADwPwokCN4EEN4EIhMzMS4xMC4yMDE0IDE1OjUwOjAwKQAAAAAAAPA/CiQI3wQQ3wQiEzMxLjEwLjIwMTQgMTU6NDA6MDApAAAAAAAA8D8KJAjgBBDgBCITMzEuMTAuMjAxNCAxNTozMDowMCkAAAAAAADwPwokCOEEEOEEIhMzMS4xMC4yMDE0IDE1OjIwOjAwKQAAAAAAAPA/CiQI4gQQ4gQiEzMxLjEwLjIwMTQgMTU6MTA6MDApAAAAAAAA8D8KJAjjBBDjBCITMzEuMTAuMjAxNCAxNDozMDowMCkAAAAAAADwPwokCOQEEOQEIhMzMS4xMC4yMDE0IDE0OjAwOjAwKQAAAAAAAPA/CiQI5QQQ5QQiEzMxLjEwLjIwMTQgMTM6NTA6MDApAAAAAAAA8D8KJAjmBBDmBCITMzEuMTAuMjAxNCAxMzoxMDowMCkAAAAAAADwPwokCOcEEOcEIhMzMS4xMC4yMDE0IDEyOjUwOjAwKQAAAAAAAPA/CiQI6AQQ6AQiEzMxLjEwLjIwMTQgMTI6MzA6MDApAAAAAAAA8D8KJAjpBBDpBCITMzEuMTAuMjAxNCAxMjoyMDowMCkAAAAAAADwPwokCOoEEOoEIhMzMS4xMC4yMDE0IDExOjUwOjAwKQAAAAAAAPA/CiQI6wQQ6wQiEzMxLjEwLjIwMTQgMTE6MzA6MDApAAAAAAAA8D8KJAjsBBDsBCITMzEuMTAuMjAxNCAxMToxMDowMCkAAAAAAADwPwokCO0EEO0EIhMzMS4xMC4yMDE0IDEwOjIwOjAwKQAAAAAAAPA/CiQI7gQQ7gQiEzMxLjEwLjIwMTQgMDk6NDA6MDApAAAAAAAA8D8KJAjvBBDvBCITMzEuMTAuMjAxNCAwODo1MDowMCkAAAAAAADwPwokCPAEEPAEIhMzMS4xMC4yMDE0IDA4OjMwOjAwKQAAAAAAAPA/CiQI8QQQ8QQiEzMxLjEwLjIwMTQgMDg6MTA6MDApAAAAAAAA8D8KJAjyBBDyBCITMzEuMTAuMjAxNCAwNzo0MDowMCkAAAAAAADwPwokCPMEEPMEIhMzMS4xMC4yMDE0IDA3OjEwOjAwKQAAAAAAAPA/CiQI9AQQ9AQiEzMxLjEwLjIwMTQgMDY6MjA6MDApAAAAAAAA8D8KJAj1BBD1BCITMzEuMTAuMjAxNCAwNTo1MDowMCkAAAAAAADwPwokCPYEEPYEIhMzMS4xMC4yMDE0IDA1OjQwOjAwKQAAAAAAAPA/CiQI9wQQ9wQiEzMxLjEwLjIwMTQgMDU6MjA6MDApAAAAAAAA8D8KJAj4BBD4BCITMzEuMTAuMjAxNCAwNToxMDowMCkAAAAAAADwPwokCPkEEPkEIhMzMS4xMC4yMDE0IDA1OjAwOjAwKQAAAAAAAPA/CiQI+gQQ+gQiEzMxLjEwLjIwMTQgMDQ6MzA6MDApAAAAAAAA8D8KJAj7BBD7BCITMzEuMTAuMjAxNCAwMzo0MDowMCkAAAAAAADwPwokCPwEEPwEIhMzMS4xMC4yMDE0IDAzOjEwOjAwKQAAAAAAAPA/CiQI/QQQ/QQiEzMxLjEwLjIwMTQgMDI6NDA6MDApAAAAAAAA8D8KJAj+BBD+BCITMzEuMTAuMjAxNCAwMjoyMDowMCkAAAAAAADwPwokCP8EEP8EIhMzMS4xMC4yMDE0IDAyOjAwOjAwKQAAAAAAAPA/CiQIgAUQgAUiEzMxLjEwLjIwMTQgMDE6NDA6MDApAAAAAAAA8D8KJAiBBRCBBSITMzEuMTAuMjAxNCAwMToxMDowMCkAAAAAAADwPwokCIIFEIIFIhMzMS4xMC4yMDE0IDAwOjUwOjAwKQAAAAAAAPA/CiQIgwUQgwUiEzMxLjEwLjIwMTQgMDA6NDA6MDApAAAAAAAA8D8KJAiEBRCEBSITMzEuMTAuMjAxNCAwMDozMDowMCkAAAAAAADwPwokCIUFEIUFIhMzMS4xMC4yMDE0IDAwOjIwOjAwKQAAAAAAAPA/CiQIhgUQhgUiEzMxLjEwLjIwMTQgMDA6MTA6MDApAAAAAAAA8D8KJAiHBRCHBSITMzEuMTAuMjAxNCAwMDowMDowMCkAAAAAAADwPwokCIgFEIgFIhMzMS4xMC4yMDEzIDIzOjQwOjAwKQAAAAAAAPA/CiQIiQUQiQUiEzMxLjEwLjIwMTMgMjM6MjA6MDApAAAAAAAA8D8KJAiKBRCKBSITMzEuMTAuMjAxMyAyMjo1MDowMCkAAAAAAADwPwokCIsFEIsFIhMzMS4xMC4yMDEzIDIyOjIwOjAwKQAAAAAAAPA/CiQIjAUQjAUiEzMxLjEwLjIwMTMgMjE6MjA6MDApAAAAAAAA8D8KJAiNBRCNBSITMzEuMTAuMjAxMyAyMDoyMDowMCkAAAAAAADwPwokCI4FEI4FIhMzMS4xMC4yMDEzIDIwOjAwOjAwKQAAAAAAAPA/CiQIjwUQjwUiEzMxLjEwLjIwMTMgMTg6MzA6MDApAAAAAAAA8D8KJAiQBRCQBSITMzEuMTAuMjAxMyAxODoxMDowMCkAAAAAAADwPwokCJEFEJEFIhMzMS4xMC4yMDEzIDE3OjMwOjAwKQAAAAAAAPA/CiQIkgUQkgUiEzMxLjEwLjIwMTMgMTY6NTA6MDApAAAAAAAA8D8KJAiTBRCTBSITMzEuMTAuMjAxMyAxNjowMDowMCkAAAAAAADwPwokCJQFEJQFIhMzMS4xMC4yMDEzIDE1OjUwOjAwKQAAAAAAAPA/CiQIlQUQlQUiEzMxLjEwLjIwMTMgMTU6NDA6MDApAAAAAAAA8D8KJAiWBRCWBSITMzEuMTAuMjAxMyAxNToyMDowMCkAAAAAAADwPwokCJcFEJcFIhMzMS4xMC4yMDEzIDE1OjAwOjAwKQAAAAAAAPA/CiQImAUQmAUiEzMxLjEwLjIwMTMgMTQ6NDA6MDApAAAAAAAA8D8KJAiZBRCZBSITMzEuMTAuMjAxMyAxNDozMDowMCkAAAAAAADwPwokCJoFEJoFIhMzMS4xMC4yMDEzIDEyOjUwOjAwKQAAAAAAAPA/CiQImwUQmwUiEzMxLjEwLjIwMTMgMTI6MzA6MDApAAAAAAAA8D8KJAicBRCcBSITMzEuMTAuMjAxMyAxMjowMDowMCkAAAAAAADwPwokCJ0FEJ0FIhMzMS4xMC4yMDEzIDExOjIwOjAwKQAAAAAAAPA/CiQIngUQngUiEzMxLjEwLjIwMTMgMTE6MTA6MDApAAAAAAAA8D8KJAifBRCfBSITMzEuMTAuMjAxMyAxMDowMDowMCkAAAAAAADwPwokCKAFEKAFIhMzMS4xMC4yMDEzIDA5OjQwOjAwKQAAAAAAAPA/CiQIoQUQoQUiEzMxLjEwLjIwMTMgMDg6NDA6MDApAAAAAAAA8D8KJAiiBRCiBSITMzEuMTAuMjAxMyAwODozMDowMCkAAAAAAADwPwokCKMFEKMFIhMzMS4xMC4yMDEzIDA1OjAwOjAwKQAAAAAAAPA/CiQIpAUQpAUiEzMxLjEwLjIwMTMgMDQ6NTA6MDApAAAAAAAA8D8KJAilBRClBSITMzEuMTAuMjAxMyAwNDoxMDowMCkAAAAAAADwPwokCKYFEKYFIhMzMS4xMC4yMDEzIDA0OjAwOjAwKQAAAAAAAPA/CiQIpwUQpwUiEzMxLjEwLjIwMTMgMDM6NDA6MDApAAAAAAAA8D8KJAioBRCoBSITMzEuMTAuMjAxMyAwMzozMDowMCkAAAAAAADwPwokCKkFEKkFIhMzMS4xMC4yMDEzIDAzOjAwOjAwKQAAAAAAAPA/CiQIqgUQqgUiEzMxLjEwLjIwMTMgMDI6MTA6MDApAAAAAAAA8D8KJAirBRCrBSITMzEuMTAuMjAxMyAwMTo0MDowMCkAAAAAAADwPwokCKwFEKwFIhMzMS4xMC4yMDEzIDAwOjMwOjAwKQAAAAAAAPA/CiQIrQUQrQUiEzMxLjEwLjIwMTMgMDA6MTA6MDApAAAAAAAA8D8KJAiuBRCuBSITMzEuMTAuMjAxMiAyMzo1MDowMCkAAAAAAADwPwokCK8FEK8FIhMzMS4xMC4yMDEyIDIzOjMwOjAwKQAAAAAAAPA/CiQIsAUQsAUiEzMxLjEwLjIwMTIgMjM6MTA6MDApAAAAAAAA8D8KJAixBRCxBSITMzEuMTAuMjAxMiAyMzowMDowMCkAAAAAAADwPwokCLIFELIFIhMzMS4xMC4yMDEyIDIyOjIwOjAwKQAAAAAAAPA/CiQIswUQswUiEzMxLjEwLjIwMTIgMjI6MTA6MDApAAAAAAAA8D8KJAi0BRC0BSITMzEuMTAuMjAxMiAyMToxMDowMCkAAAAAAADwPwokCLUFELUFIhMzMS4xMC4yMDEyIDIwOjEwOjAwKQAAAAAAAPA/CiQItgUQtgUiEzMxLjEwLjIwMTIgMTk6MzA6MDApAAAAAAAA8D8KJAi3BRC3BSITMzEuMTAuMjAxMiAxOToyMDowMCkAAAAAAADwPwokCLgFELgFIhMzMS4xMC4yMDEyIDE4OjUwOjAwKQAAAAAAAPA/CiQIuQUQuQUiEzMxLjEwLjIwMTIgMTg6MzA6MDApAAAAAAAA8D8KJAi6BRC6BSITMzEuMTAuMjAxMiAxODowMDowMCkAAAAAAADwPwokCLsFELsFIhMzMS4xMC4yMDEyIDE3OjIwOjAwKQAAAAAAAPA/CiQIvAUQvAUiEzMxLjEwLjIwMTIgMTY6NDA6MDApAAAAAAAA8D8KJAi9BRC9BSITMzEuMTAuMjAxMiAxNToxMDowMCkAAAAAAADwPwokCL4FEL4FIhMzMS4xMC4yMDEyIDE1OjAwOjAwKQAAAAAAAPA/CiQIvwUQvwUiEzMxLjEwLjIwMTIgMTQ6NTA6MDApAAAAAAAA8D8KJAjABRDABSITMzEuMTAuMjAxMiAxNDozMDowMCkAAAAAAADwPwokCMEFEMEFIhMzMS4xMC4yMDEyIDEyOjUwOjAwKQAAAAAAAPA/CiQIwgUQwgUiEzMxLjEwLjIwMTIgMTI6NDA6MDApAAAAAAAA8D8KJAjDBRDDBSITMzEuMTAuMjAxMiAxMjoyMDowMCkAAAAAAADwPwokCMQFEMQFIhMzMS4xMC4yMDEyIDEyOjEwOjAwKQAAAAAAAPA/CiQIxQUQxQUiEzMxLjEwLjIwMTIgMTI6MDA6MDApAAAAAAAA8D8KJAjGBRDGBSITMzEuMTAuMjAxMiAxMTo1MDowMCkAAAAAAADwPwokCMcFEMcFIhMzMS4xMC4yMDEyIDExOjQwOjAwKQAAAAAAAPA/CiQIyAUQyAUiEzMxLjEwLjIwMTIgMTE6MzA6MDApAAAAAAAA8D8KJAjJBRDJBSITMzEuMTAuMjAxMiAxMTowMDowMCkAAAAAAADwPwokCMoFEMoFIhMzMS4xMC4yMDEyIDEwOjMwOjAwKQAAAAAAAPA/CiQIywUQywUiEzMxLjEwLjIwMTIgMTA6MjA6MDApAAAAAAAA8D8KJAjMBRDMBSITMzEuMTAuMjAxMiAxMDowMDowMCkAAAAAAADwPwokCM0FEM0FIhMzMS4xMC4yMDEyIDA4OjMwOjAwKQAAAAAAAPA/CiQIzgUQzgUiEzMxLjEwLjIwMTIgMDg6MjA6MDApAAAAAAAA8D8KJAjPBRDPBSITMzEuMTAuMjAxMiAwODowMDowMCkAAAAAAADwPwokCNAFENAFIhMzMS4xMC4yMDEyIDA3OjAwOjAwKQAAAAAAAPA/CiQI0QUQ0QUiEzMxLjEwLjIwMTIgMDY6NDA6MDApAAAAAAAA8D8KJAjSBRDSBSITMzEuMTAuMjAxMiAwNToyMDowMCkAAAAAAADwPwokCNMFENMFIhMzMS4xMC4yMDEyIDA1OjAwOjAwKQAAAAAAAPA/CiQI1AUQ1AUiEzMxLjEwLjIwMTIgMDQ6NTA6MDApAAAAAAAA8D8KJAjVBRDVBSITMzEuMTAuMjAxMiAwNDo0MDowMCkAAAAAAADwPwokCNYFENYFIhMzMS4xMC4yMDEyIDA0OjMwOjAwKQAAAAAAAPA/CiQI1wUQ1wUiEzMxLjEwLjIwMTIgMDQ6MDA6MDApAAAAAAAA8D8KJAjYBRDYBSITMzEuMTAuMjAxMiAwMzo1MDowMCkAAAAAAADwPwokCNkFENkFIhMzMS4xMC4yMDEyIDAzOjQwOjAwKQAAAAAAAPA/CiQI2gUQ2gUiEzMxLjEwLjIwMTIgMDM6MzA6MDApAAAAAAAA8D8KJAjbBRDbBSITMzEuMTAuMjAxMiAwMzowMDowMCkAAAAAAADwPwokCNwFENwFIhMzMS4xMC4yMDEyIDAyOjUwOjAwKQAAAAAAAPA/CiQI3QUQ3QUiEzMxLjEwLjIwMTIgMDI6MTA6MDApAAAAAAAA8D8KJAjeBRDeBSITMzEuMTAuMjAxMiAwMTozMDowMCkAAAAAAADwPwokCN8FEN8FIhMzMS4xMC4yMDEyIDAxOjIwOjAwKQAAAAAAAPA/CiQI4AUQ4AUiEzMxLjEwLjIwMTIgMDA6MjA6MDApAAAAAAAA8D8KJAjhBRDhBSITMzEuMTAuMjAxMiAwMDowMDowMCkAAAAAAADwPwokCOIFEOIFIhMzMS4xMC4yMDExIDIzOjUwOjAwKQAAAAAAAPA/CiQI4wUQ4wUiEzMxLjEwLjIwMTEgMjM6NDA6MDApAAAAAAAA8D8KJAjkBRDkBSITMzEuMTAuMjAxMSAyMzoxMDowMCkAAAAAAADwPwokCOUFEOUFIhMzMS4xMC4yMDExIDIyOjQwOjAwKQAAAAAAAPA/CiQI5gUQ5gUiEzMxLjEwLjIwMTEgMjI6MDA6MDApAAAAAAAA8D8KJAjnBRDnBSITMzEuMTAuMjAxMSAxODo1MDowMCkAAAAAAADwPwokCOgFEOgFIhMzMS4xMC4yMDExIDE3OjUwOjAwKQAAAAAAAPA/CiQI6QUQ6QUiEzMxLjEwLjIwMTEgMTc6MTA6MDApAAAAAAAA8D8KJAjqBRDqBSITMzEuMTAuMjAxMSAxNTo0MDowMCkAAAAAAADwPwokCOsFEOsFIhMzMS4xMC4yMDExIDE0OjMwOjAwKQAAAAAAAPA/CiQI7AUQ7AUiEzMxLjEwLjIwMTEgMTM6NDA6MDApAAAAAAAA8D8KJAjtBRDtBSITMzEuMTAuMjAxMSAxMzoyMDowMCkAAAAAAADwPwokCO4FEO4FIhMzMS4xMC4yMDExIDEzOjEwOjAwKQAAAAAAAPA/CiQI7wUQ7wUiEzMxLjEwLjIwMTEgMTI6NDA6MDApAAAAAAAA8D8KJAjwBRDwBSITMzEuMTAuMjAxMSAxMjozMDowMCkAAAAAAADwPwokCPEFEPEFIhMzMS4xMC4yMDExIDExOjUwOjAwKQAAAAAAAPA/CiQI8gUQ8gUiEzMxLjEwLjIwMTEgMTE6MzA6MDApAAAAAAAA8D8KJAjzBRDzBSITMzEuMTAuMjAxMSAxMToxMDowMCkAAAAAAADwPwokCPQFEPQFIhMzMS4xMC4yMDExIDA5OjUwOjAwKQAAAAAAAPA/CiQI9QUQ9QUiEzMxLjEwLjIwMTEgMDk6MjA6MDApAAAAAAAA8D8KJAj2BRD2BSITMzEuMTAuMjAxMSAwODoyMDowMCkAAAAAAADwPwokCPcFEPcFIhMzMS4xMC4yMDExIDA4OjEwOjAwKQAAAAAAAPA/CiQI+AUQ+AUiEzMxLjEwLjIwMTEgMDg6MDA6MDApAAAAAAAA8D8KJAj5BRD5BSITMzEuMTAuMjAxMSAwNzo1MDowMCkAAAAAAADwPwokCPoFEPoFIhMzMS4xMC4yMDExIDA3OjMwOjAwKQAAAAAAAPA/CiQI+wUQ+wUiEzMxLjEwLjIwMTEgMDc6MTA6MDApAAAAAAAA8D8KJAj8BRD8BSITMzEuMTAuMjAxMSAwNjoyMDowMCkAAAAAAADwPwokCP0FEP0FIhMzMS4xMC4yMDExIDA2OjEwOjAwKQAAAAAAAPA/CiQI/gUQ/gUiEzMxLjEwLjIwMTEgMDY6MDA6MDApAAAAAAAA8D8KJAj/BRD/BSITMzEuMTAuMjAxMSAwNTo1MDowMCkAAAAAAADwPwokCIAGEIAGIhMzMS4xMC4yMDExIDA1OjQwOjAwKQAAAAAAAPA/CiQIgQYQgQYiEzMxLjEwLjIwMTEgMDU6MzA6MDApAAAAAAAA8D8KJAiCBhCCBiITMzEuMTAuMjAxMSAwNToxMDowMCkAAAAAAADwPwokCIMGEIMGIhMzMS4xMC4yMDExIDA1OjAwOjAwKQAAAAAAAPA/CiQIhAYQhAYiEzMxLjEwLjIwMTEgMDQ6NTA6MDApAAAAAAAA8D8KJAiFBhCFBiITMzEuMTAuMjAxMSAwNDo0MDowMCkAAAAAAADwPwokCIYGEIYGIhMzMS4xMC4yMDExIDA0OjMwOjAwKQAAAAAAAPA/CiQIhwYQhwYiEzMxLjEwLjIwMTEgMDQ6MTA6MDApAAAAAAAA8D8KJAiIBhCIBiITMzEuMTAuMjAxMSAwMzozMDowMCkAAAAAAADwPwokCIkGEIkGIhMzMS4xMC4yMDExIDAxOjAwOjAwKQAAAAAAAPA/CiQIigYQigYiEzMxLjEwLjIwMTEgMDA6NTA6MDApAAAAAAAA8D8KJAiLBhCLBiITMzEuMTAuMjAxMSAwMDo0MDowMCkAAAAAAADwPwokCIwGEIwGIhMzMS4xMC4yMDExIDAwOjIwOjAwKQAAAAAAAPA/CiQIjQYQjQYiEzMxLjEwLjIwMTAgMjM6NDA6MDApAAAAAAAA8D8KJAiOBhCOBiITMzEuMTAuMjAxMCAyMzoxMDowMCkAAAAAAADwPwokCI8GEI8GIhMzMS4xMC4yMDEwIDIyOjMwOjAwKQAAAAAAAPA/CiQIkAYQkAYiEzMxLjEwLjIwMTAgMjI6MjA6MDApAAAAAAAA8D8KJAiRBhCRBiITMzEuMTAuMjAxMCAyMjoxMDowMCkAAAAAAADwPwokCJIGEJIGIhMzMS4xMC4yMDEwIDIyOjAwOjAwKQAAAAAAAPA/CiQIkwYQkwYiEzMxLjEwLjIwMTAgMjE6NDA6MDApAAAAAAAA8D8KJAiUBhCUBiITMzEuMTAuMjAxMCAyMToyMDowMCkAAAAAAADwPwokCJUGEJUGIhMzMS4xMC4yMDEwIDIxOjAwOjAwKQAAAAAAAPA/CiQIlgYQlgYiEzMxLjEwLjIwMTAgMjA6NDA6MDApAAAAAAAA8D8KJAiXBhCXBiITMzEuMTAuMjAxMCAyMDozMDowMCkAAAAAAADwPwokCJgGEJgGIhMzMS4xMC4yMDEwIDIwOjEwOjAwKQAAAAAAAPA/CiQImQYQmQYiEzMxLjEwLjIwMTAgMTk6MjA6MDApAAAAAAAA8D8KJAiaBhCaBiITMzEuMTAuMjAxMCAxOToxMDowMCkAAAAAAADwPwokCJsGEJsGIhMzMS4xMC4yMDEwIDE5OjAwOjAwKQAAAAAAAPA/CiQInAYQnAYiEzMxLjEwLjIwMTAgMTg6NTA6MDApAAAAAAAA8D8KJAidBhCdBiITMzEuMTAuMjAxMCAxODo0MDowMCkAAAAAAADwPwokCJ4GEJ4GIhMzMS4xMC4yMDEwIDE4OjEwOjAwKQAAAAAAAPA/CiQInwYQnwYiEzMxLjEwLjIwMTAgMTg6MDA6MDApAAAAAAAA8D8KJAigBhCgBiITMzEuMTAuMjAxMCAxNzo1MDowMCkAAAAAAADwPwokCKEGEKEGIhMzMS4xMC4yMDEwIDE3OjQwOjAwKQAAAAAAAPA/CiQIogYQogYiEzMxLjEwLjIwMTAgMTc6MTA6MDApAAAAAAAA8D8KJAijBhCjBiITMzEuMTAuMjAxMCAxNjo0MDowMCkAAAAAAADwPwokCKQGEKQGIhMzMS4xMC4yMDEwIDE2OjEwOjAwKQAAAAAAAPA/CiQIpQYQpQYiEzMxLjEwLjIwMTAgMTY6MDA6MDApAAAAAAAA8D8KJAimBhCmBiITMzEuMTAuMjAxMCAxNTo0MDowMCkAAAAAAADwPwokCKcGEKcGIhMzMS4xMC4yMDEwIDE1OjMwOjAwKQAAAAAAAPA/CiQIqAYQqAYiEzMxLjEwLjIwMTAgMTQ6NTA6MDApAAAAAAAA8D8KJAipBhCpBiITMzEuMTAuMjAxMCAxMzozMDowMCkAAAAAAADwPwokCKoGEKoGIhMzMS4xMC4yMDEwIDEzOjAwOjAwKQAAAAAAAPA/CiQIqwYQqwYiEzMxLjEwLjIwMTAgMTI6MzA6MDApAAAAAAAA8D8KJAisBhCsBiITMzEuMTAuMjAxMCAxMjoxMDowMCkAAAAAAADwPwokCK0GEK0GIhMzMS4xMC4yMDEwIDEyOjAwOjAwKQAAAAAAAPA/CiQIrgYQrgYiEzMxLjEwLjIwMTAgMTE6MTA6MDApAAAAAAAA8D8KJAivBhCvBiITMzEuMTAuMjAxMCAxMDoyMDowMCkAAAAAAADwPwokCLAGELAGIhMzMS4xMC4yMDEwIDA5OjQwOjAwKQAAAAAAAPA/CiQIsQYQsQYiEzMxLjEwLjIwMTAgMDg6NTA6MDApAAAAAAAA8D8KJAiyBhCyBiITMzEuMTAuMjAxMCAwNzoxMDowMCkAAAAAAADwPwokCLMGELMGIhMzMS4xMC4yMDEwIDA3OjAwOjAwKQAAAAAAAPA/CiQItAYQtAYiEzMxLjEwLjIwMTAgMDY6NDA6MDApAAAAAAAA8D8KJAi1BhC1BiITMzEuMTAuMjAxMCAwNjoyMDowMCkAAAAAAADwPwokCLYGELYGIhMzMS4xMC4yMDEwIDA1OjUwOjAwKQAAAAAAAPA/CiQItwYQtwYiEzMxLjEwLjIwMTAgMDU6MDA6MDApAAAAAAAA8D8KJAi4BhC4BiITMzEuMTAuMjAxMCAwNDoxMDowMCkAAAAAAADwPwokCLkGELkGIhMzMS4xMC4yMDEwIDAzOjIwOjAwKQAAAAAAAPA/CiQIugYQugYiEzMxLjEwLjIwMTAgMDM6MDA6MDApAAAAAAAA8D8KJAi7BhC7BiITMzEuMTAuMjAxMCAwMjo1MDowMCkAAAAAAADwPwokCLwGELwGIhMzMS4xMC4yMDEwIDAyOjQwOjAwKQAAAAAAAPA/CiQIvQYQvQYiEzMxLjEwLjIwMTAgMDI6MTA6MDApAAAAAAAA8D8KJAi+BhC+BiITMzEuMTAuMjAxMCAwMTo1MDowMCkAAAAAAADwPwokCL8GEL8GIhMzMS4xMC4yMDEwIDAxOjQwOjAwKQAAAAAAAPA/CiQIwAYQwAYiEzMxLjEwLjIwMTAgMDA6NTA6MDApAAAAAAAA8D8KJAjBBhDBBiITMzEuMTAuMjAxMCAwMDoyMDowMCkAAAAAAADwPwokCMIGEMIGIhMzMS4xMC4yMDA5IDIzOjUwOjAwKQAAAAAAAPA/CiQIwwYQwwYiEzMxLjEwLjIwMDkgMjM6MzA6MDApAAAAAAAA8D8KJAjEBhDEBiITMzEuMTAuMjAwOSAyMzoxMDowMCkAAAAAAADwPwokCMUGEMUGIhMzMS4xMC4yMDA5IDIyOjUwOjAwKQAAAAAAAPA/CiQIxgYQxgYiEzMxLjEwLjIwMDkgMjA6MTA6MDApAAAAAAAA8D8KJAjHBhDHBiITMzEuMTAuMjAwOSAxODoyMDowMCkAAAAAAADwPwokCMgGEMgGIhMzMS4xMC4yMDA5IDE3OjQwOjAwKQAAAAAAAPA/CiQIyQYQyQYiEzMxLjEwLjIwMDkgMTY6NTA6MDApAAAAAAAA8D8KJAjKBhDKBiITMzEuMTAuMjAwOSAxNjowMDowMCkAAAAAAADwPwokCMsGEMsGIhMzMS4xMC4yMDA5IDE1OjUwOjAwKQAAAAAAAPA/CiQIzAYQzAYiEzMxLjEwLjIwMDkgMTU6MjA6MDApAAAAAAAA8D8KJAjNBhDNBiITMzEuMTAuMjAwOSAxNToxMDowMCkAAAAAAADwPwokCM4GEM4GIhMzMS4xMC4yMDA5IDE0OjUwOjAwKQAAAAAAAPA/CiQIzwYQzwYiEzMxLjEwLjIwMDkgMTQ6NDA6MDApAAAAAAAA8D8KJAjQBhDQBiITMzEuMTAuMjAwOSAxNDoyMDowMCkAAAAAAADwPwokCNEGENEGIhMzMS4xMC4yMDA5IDE0OjAwOjAwKQAAAAAAAPA/CiQI0gYQ0gYiEzMxLjEwLjIwMDkgMTM6MjA6MDApAAAAAAAA8D8KJAjTBhDTBiITMzEuMTAuMjAwOSAxMzoxMDowMCkAAAAAAADwPwokCNQGENQGIhMzMS4xMC4yMDA5IDEyOjAwOjAwKQAAAAAAAPA/CiQI1QYQ1QYiEzMxLjEwLjIwMDkgMTE6MzA6MDApAAAAAAAA8D8KJAjWBhDWBiITMzEuMTAuMjAwOSAxMToyMDowMCkAAAAAAADwPwokCNcGENcGIhMzMS4xMC4yMDA5IDExOjEwOjAwKQAAAAAAAPA/CiQI2AYQ2AYiEzMxLjEwLjIwMDkgMDk6NDA6MDApAAAAAAAA8D8KJAjZBhDZBiITMzEuMTAuMjAwOSAwOToxMDowMCkAAAAAAADwPwokCNoGENoGIhMzMS4xMC4yMDA5IDA4OjQwOjAwKQAAAAAAAPA/CiQI2wYQ2wYiEzMxLjEwLjIwMDkgMDc6NDA6MDApAAAAAAAA8D8KJAjcBhDcBiITMzEuMTAuMjAwOSAwNzoxMDowMCkAAAAAAADwPwokCN0GEN0GIhMzMS4xMC4yMDA5IDA2OjUwOjAwKQAAAAAAAPA/CiQI3gYQ3gYiEzMxLjEwLjIwMDkgMDY6NDA6MDApAAAAAAAA8D8KJAjfBhDfBiITMzEuMTAuMjAwOSAwNjozMDowMCkAAAAAAADwPwokCOAGEOAGIhMzMS4xMC4yMDA5IDA2OjAwOjAwKQAAAAAAAPA/CiQI4QYQ4QYiEzMxLjEwLjIwMDkgMDU6NTA6MDApAAAAAAAA8D8KJAjiBhDiBiITMzEuMTAuMjAwOSAwNDoxMDowMCkAAAAAAADwPwokCOMGEOMGIhMzMS4xMC4yMDA5IDAyOjUwOjAwKQAAAAAAAPA/CiQI5AYQ5AYiEzMxLjEwLjIwMDkgMDI6MzA6MDApAAAAAAAA8D8KJAjlBhDlBiITMzEuMTAuMjAwOSAwMjoyMDowMCkAAAAAAADwPwokCOYGEOYGIhMzMS4xMC4yMDA5IDAxOjUwOjAwKQAAAAAAAPA/CiQI5wYQ5wYiEzMxLjEwLjIwMDkgMDE6MzA6MDApAAAAAAAA8D8KJAjoBhDoBiITMzEuMTAuMjAwOSAwMToyMDowMCkAAAAAAADwPwokCOkGEOkGIhMzMS4xMC4yMDA5IDAxOjAwOjAwKQAAAAAAAPA/CiQI6gYQ6gYiEzMxLjEwLjIwMDkgMDA6MTA6MDApAAAAAAAA8D8KJAjrBhDrBiITMzEuMTAuMjAwOSAwMDowMDowMCkAAAAAAADwPwokCOwGEOwGIhMzMS4wOC4yMDE2IDIyOjMwOjAwKQAAAAAAAPA/CiQI7QYQ7QYiEzMxLjA4LjIwMTYgMjI6MTA6MDApAAAAAAAA8D8KJAjuBhDuBiITMzEuMDguMjAxNiAyMjowMDowMCkAAAAAAADwPwokCO8GEO8GIhMzMS4wOC4yMDE2IDIxOjQwOjAwKQAAAAAAAPA/CiQI8AYQ8AYiEzMxLjA4LjIwMTYgMjE6MDA6MDApAAAAAAAA8D8KJAjxBhDxBiITMzEuMDguMjAxNiAyMDoyMDowMCkAAAAAAADwPwokCPIGEPIGIhMzMS4wOC4yMDE2IDIwOjAwOjAwKQAAAAAAAPA/CiQI8wYQ8wYiEzMxLjA4LjIwMTYgMTk6MzA6MDApAAAAAAAA8D8KJAj0BhD0BiITMzEuMDguMjAxNiAxODo1MDowMCkAAAAAAADwPwokCPUGEPUGIhMzMS4wOC4yMDE2IDE4OjMwOjAwKQAAAAAAAPA/CiQI9gYQ9gYiEzMxLjA4LjIwMTYgMTg6MTA6MDApAAAAAAAA8D8KJAj3BhD3BiITMzEuMDguMjAxNiAxNzo0MDowMCkAAAAAAADwPwokCPgGEPgGIhMzMS4wOC4yMDE2IDE3OjIwOjAwKQAAAAAAAPA/CiQI+QYQ+QYiEzMxLjA4LjIwMTYgMTc6MTA6MDApAAAAAAAA8D8KJAj6BhD6BiITMzEuMDguMjAxNiAxNzowMDowMCkAAAAAAADwPwokCPsGEPsGIhMzMS4wOC4yMDE2IDE2OjMwOjAwKQAAAAAAAPA/CiQI/AYQ/AYiEzMxLjA4LjIwMTYgMTY6MjA6MDApAAAAAAAA8D8KJAj9BhD9BiITMzEuMDguMjAxNiAxNjoxMDowMCkAAAAAAADwPwokCP4GEP4GIhMzMS4wOC4yMDE2IDE1OjMwOjAwKQAAAAAAAPA/CiQI/wYQ/wYiEzMxLjA4LjIwMTYgMTU6MTA6MDApAAAAAAAA8D8KJAiABxCAByITMzEuMDguMjAxNiAxNDo0MDowMCkAAAAAAADwPwokCIEHEIEHIhMzMS4wOC4yMDE2IDE0OjIwOjAwKQAAAAAAAPA/CiQIggcQggciEzMxLjA4LjIwMTYgMTQ6MDA6MDApAAAAAAAA8D8KJAiDBxCDByITMzEuMDguMjAxNiAxMzozMDowMCkAAAAAAADwPwokCIQHEIQHIhMzMS4wOC4yMDE2IDEzOjIwOjAwKQAAAAAAAPA/CiQIhQcQhQciEzMxLjA4LjIwMTYgMTM6MTA6MDApAAAAAAAA8D8KJAiGBxCGByITMzEuMDguMjAxNiAxMjo0MDowMCkAAAAAAADwPwokCIcHEIcHIhMzMS4wOC4yMDE2IDEyOjMwOjAwKQAAAAAAAPA/CiQIiAcQiAciEzMxLjA4LjIwMTYgMTI6MjA6MDApAAAAAAAA8D8KJAiJBxCJByITMzEuMDguMjAxNiAxMjoxMDowMCkAAAAAAADwPwokCIoHEIoHIhMzMS4wOC4yMDE2IDExOjUwOjAwKQAAAAAAAPA/CiQIiwcQiwciEzMxLjA4LjIwMTYgMTE6MjA6MDApAAAAAAAA8D8KJAiMBxCMByITMzEuMDguMjAxNiAxMTowMDowMCkAAAAAAADwPwokCI0HEI0HIhMzMS4wOC4yMDE2IDEwOjAwOjAwKQAAAAAAAPA/CiQIjgcQjgciEzMxLjA4LjIwMTYgMDk6NTA6MDApAAAAAAAA8D8KJAiPBxCPByITMzEuMDguMjAxNiAwOTo0MDowMCkAAAAAAADwPwokCJAHEJAHIhMzMS4wOC4yMDE2IDA5OjIwOjAwKQAAAAAAAPA/CiQIkQcQkQciEzMxLjA4LjIwMTYgMDg6NDA6MDApAAAAAAAA8D8KJAiSBxCSByITMzEuMDguMjAxNiAwODoyMDowMCkAAAAAAADwPwokCJMHEJMHIhMzMS4wOC4yMDE2IDA3OjQwOjAwKQAAAAAAAPA/CiQIlAcQlAciEzMxLjA4LjIwMTYgMDc6MTA6MDApAAAAAAAA8D8KJAiVBxCVByITMzEuMDguMjAxNiAwNzowMDowMCkAAAAAAADwPwokCJYHEJYHIhMzMS4wOC4yMDE2IDA2OjIwOjAwKQAAAAAAAPA/CiQIlwcQlwciEzMxLjA4LjIwMTYgMDY6MTA6MDApAAAAAAAA8D8KJAiYBxCYByITMzEuMDguMjAxNiAwNTo1MDowMCkAAAAAAADwPwokCJkHEJkHIhMzMS4wOC4yMDE2IDA1OjMwOjAwKQAAAAAAAPA/CiQImgcQmgciEzMxLjA4LjIwMTYgMDU6MTA6MDApAAAAAAAA8D8KJAibBxCbByITMzEuMDguMjAxNiAwNDo1MDowMCkAAAAAAADwPwokCJwHEJwHIhMzMS4wOC4yMDE2IDA0OjAwOjAwKQAAAAAAAPA/CiQInQcQnQciEzMxLjA4LjIwMTYgMDM6NDA6MDApAAAAAAAA8D8KJAieBxCeByITMzEuMDguMjAxNiAwMzozMDowMCkAAAAAAADwPwokCJ8HEJ8HIhMzMS4wOC4yMDE2IDAyOjUwOjAwKQAAAAAAAPA/CiQIoAcQoAciEzMxLjA4LjIwMTYgMDI6MzA6MDApAAAAAAAA8D8KJAihBxChByITMzEuMDguMjAxNiAwMjoyMDowMCkAAAAAAADwPwokCKIHEKIHIhMzMS4wOC4yMDE2IDAyOjEwOjAwKQAAAAAAAPA/CiQIowcQowciEzMxLjA4LjIwMTYgMDI6MDA6MDApAAAAAAAA8D8KJAikBxCkByITMzEuMDguMjAxNiAwMTozMDowMCkAAAAAAADwPwokCKUHEKUHIhMzMS4wOC4yMDE2IDAwOjIwOjAwKQAAAAAAAPA/CiQIpgcQpgciEzMxLjA4LjIwMTUgMjM6NTA6MDApAAAAAAAA8D8KJAinBxCnByITMzEuMDguMjAxNSAyMjozMDowMCkAAAAAAADwPwokCKgHEKgHIhMzMS4wOC4yMDE1IDIyOjIwOjAwKQAAAAAAAPA/CiQIqQcQqQciEzMxLjA4LjIwMTUgMjE6NTA6MDApAAAAAAAA8D8KJAiqBxCqByITMzEuMDguMjAxNSAyMToyMDowMCkAAAAAAADwPwokCKsHEKsHIhMzMS4wOC4yMDE1IDIxOjEwOjAwKQAAAAAAAPA/CiQIrAcQrAciEzMxLjA4LjIwMTUgMjE6MDA6MDApAAAAAAAA8D8KJAitBxCtByITMzEuMDguMjAxNSAyMDozMDowMCkAAAAAAADwPwokCK4HEK4HIhMzMS4wOC4yMDE1IDIwOjAwOjAwKQAAAAAAAPA/CiQIrwcQrwciEzMxLjA4LjIwMTUgMTk6NDA6MDApAAAAAAAA8D8KJAiwBxCwByITMzEuMDguMjAxNSAxOToyMDowMCkAAAAAAADwPwokCLEHELEHIhMzMS4wOC4yMDE1IDE4OjQwOjAwKQAAAAAAAPA/CiQIsgcQsgciEzMxLjA4LjIwMTUgMTg6MzA6MDApAAAAAAAA8D8KJAizBxCzByITMzEuMDguMjAxNSAxNzozMDowMCkAAAAAAADwPwokCLQHELQHIhMzMS4wOC4yMDE1IDE3OjEwOjAwKQAAAAAAAPA/CiQItQcQtQciEzMxLjA4LjIwMTUgMTY6NDA6MDApAAAAAAAA8D8KJAi2BxC2ByITMzEuMDguMjAxNSAxNjozMDowMCkAAAAAAADwPwokCLcHELcHIhMzMS4wOC4yMDE1IDE2OjIwOjAwKQAAAAAAAPA/CiQIuAcQuAciEzMxLjA4LjIwMTUgMTY6MDA6MDApAAAAAAAA8D8KJAi5BxC5ByITMzEuMDguMjAxNSAxNTozMDowMCkAAAAAAADwPwokCLoHELoHIhMzMS4wOC4yMDE1IDE1OjEwOjAwKQAAAAAAAPA/CiQIuwcQuwciEzMxLjA4LjIwMTUgMTQ6NTA6MDApAAAAAAAA8D8KJAi8BxC8ByITMzEuMDguMjAxNSAxNDo0MDowMCkAAAAAAADwPwokCL0HEL0HIhMzMS4wOC4yMDE1IDE0OjMwOjAwKQAAAAAAAPA/CiQIvgcQvgciEzMxLjA4LjIwMTUgMTM6NDA6MDApAAAAAAAA8D8KJAi/BxC/ByITMzEuMDguMjAxNSAxMzozMDowMCkAAAAAAADwPwokCMAHEMAHIhMzMS4wOC4yMDE1IDExOjAwOjAwKQAAAAAAAPA/CiQIwQcQwQciEzMxLjA4LjIwMTUgMTA6NTA6MDApAAAAAAAA8D8KJAjCBxDCByITMzEuMDguMjAxNSAxMDowMDowMCkAAAAAAADwPwokCMMHEMMHIhMzMS4wOC4yMDE1IDA5OjUwOjAwKQAAAAAAAPA/CiQIxAcQxAciEzMxLjA4LjIwMTUgMDk6NDA6MDApAAAAAAAA8D8KJAjFBxDFByITMzEuMDguMjAxNSAwOTozMDowMCkAAAAAAADwPwokCMYHEMYHIhMzMS4wOC4yMDE1IDA4OjMwOjAwKQAAAAAAAPA/CiQIxwcQxwciEzMxLjA4LjIwMTUgMDc6NDA6MDApAAAAAAAA8D8KJAjIBxDIByITMzEuMDguMjAxNSAwNzozMDowMCkAAAAAAADwPwokCMkHEMkHIhMzMS4wOC4yMDE1IDA3OjIwOjAwKQAAAAAAAPA/CiQIygcQygciEzMxLjA4LjIwMTUgMDY6NTA6MDApAAAAAAAA8D8KJAjLBxDLByITMzEuMDguMjAxNSAwNDo0MDowMCkAAAAAAADwPwokCMwHEMwHIhMzMS4wOC4yMDE1IDA0OjMwOjAwKQAAAAAAAPA/CiQIzQcQzQciEzMxLjA4LjIwMTUgMDQ6MjA6MDApAAAAAAAA8D8KJAjOBxDOByITMzEuMDguMjAxNSAwNDoxMDowMCkAAAAAAADwPwokCM8HEM8HIhMzMS4wOC4yMDE1IDA0OjAwOjAwKQAAAAAAAPA/CiQI0AcQ0AciEzMxLjA4LjIwMTUgMDM6NDA6MDApAAAAAAAA8D8KJAjRBxDRByITMzEuMDguMjAxNSAwMzoyMDowMCkAAAAAAADwPwokCNIHENIHIhMzMS4wOC4yMDE1IDAzOjEwOjAwKQAAAAAAAPA/CiQI0wcQ0wciEzMxLjA4LjIwMTUgMDM6MDA6MDApAAAAAAAA8D8KJAjUBxDUByITMzEuMDguMjAxNSAwMjo1MDowMCkAAAAAAADwPwokCNUHENUHIhMzMS4wOC4yMDE1IDAyOjMwOjAwKQAAAAAAAPA/CiQI1gcQ1gciEzMxLjA4LjIwMTUgMDI6MjA6MDApAAAAAAAA8D8KJAjXBxDXByITMzEuMDguMjAxNSAwMjoxMDowMCkAAAAAAADwPwokCNgHENgHIhMzMS4wOC4yMDE1IDAxOjQwOjAwKQAAAAAAAPA/CiQI2QcQ2QciEzMxLjA4LjIwMTUgMDE6MzA6MDApAAAAAAAA8D8KJAjaBxDaByITMzEuMDguMjAxNSAwMToxMDowMCkAAAAAAADwPwokCNsHENsHIhMzMS4wOC4yMDE1IDAwOjUwOjAwKQAAAAAAAPA/CiQI3AcQ3AciEzMxLjA4LjIwMTUgMDA6NDA6MDApAAAAAAAA8D8KJAjdBxDdByITMzEuMDguMjAxNSAwMDoyMDowMCkAAAAAAADwPwokCN4HEN4HIhMzMS4wOC4yMDE1IDAwOjEwOjAwKQAAAAAAAPA/CiQI3wcQ3wciEzMxLjA4LjIwMTQgMjM6NTA6MDApAAAAAAAA8D8KJAjgBxDgByITMzEuMDguMjAxNCAyMzozMDowMCkAAAAAAADwPwokCOEHEOEHIhMzMS4wOC4yMDE0IDIyOjUwOjAwKQAAAAAAAPA/CiQI4gcQ4gciEzMxLjA4LjIwMTQgMjI6MzA6MDApAAAAAAAA8D8KJAjjBxDjByITMzEuMDguMjAxNCAyMjowMDowMCkAAAAAAADwPwokCOQHEOQHIhMzMS4wOC4yMDE0IDIwOjMwOjAwKQAAAAAAAPA/CiQI5QcQ5QciEzMxLjA4LjIwMTQgMTk6NDA6MDApAAAAAAAA8D8KJAjmBxDmByITMzEuMDguMjAxNCAxOTozMDowMCkAAAAAAADwPwokCOcHEOcHIhMzMS4wOC4yMDE0IDE5OjIwOjAwKQAAAAAAAPA/QgsKCURhdGUgVGltZRrMBxABGrQHCrgCCPvMCBgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAIAFA+8wIEbrj8Pv3TSNAGWATQnSU9RBAKQAAAKBwPeo/MQAAAIDC9SFAOQAAAMAehTxAQqICGhsJAAAAoHA96j8RzczM8FG4DEAhThMcP8Qet0AaGwnNzMzwUbgMQBHNzMzco3AZQCHMujxmnJbdQBobCc3MzNyjcBlAEZqZmWCPQiJAIbbUbixOeuFAGhsJmpmZYI9CIkARzczM0szMJ0Ah5QIf9cOX20AaGwnNzMzSzMwnQBEAAABFClctQCHAvO/BYYHUQBobCQAAAEUKVy1AEZqZmdujcDFAITqZbhmwkMhAGhsJmpmZ26NwMUARMzOzlMI1NEAhQZVcEwZJtUAaGwkzM7OUwjU0QBHNzMxN4fo2QCHxpwReKnOWQBobCc3MzE3h+jZAEWdm5gYAwDlAIRhX+V2g+l1AGhsJZ2bmBgDAOUARAAAAwB6FPEAhyIshQ6LpUkBCpAIaGwkAAACgcD3qPxEAAACAwvUSQCFmZmZmJobLQBobCQAAAIDC9RJAEQAAAOCjcBdAIWZmZmYmhstAGhsJAAAA4KNwF0ARAAAAQDMzG0AhZmZmZiaGy0AaGwkAAABAMzMbQBEAAACgcD0fQCFmZmZmJobLQBobCQAAAKBwPR9AEQAAAIDC9SFAIWZmZmYmhstAGhsJAAAAgML1IUARAAAAgBSuJEAhZmZmZiaGy0AaGwkAAACAFK4kQBEAAACAwnUnQCFmZmZmJobLQBobCQAAAIDCdSdAEQAAAKBwvSpAIWZmZmYmhstAGhsJAAAAoHC9KkARAAAAAClcL0AhZmZmZiaGy0AaGwkAAAAAKVwvQBEAAADAHoU8QCFmZmZmJobLQCABQhEKD0gyT0MgKG1tb2wvbW9sKRrHBxABGrYHCrgCCPvMCBgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAIAFA+8wIEcnGFBjE+CJAGV58UQDx2iBAICUpAAAAANejNsAxAAAA4KPwIkA5AAAAoEeBQkBCogIaGwkAAAAA16M2wBFmZmbGzKwwwCE91dl1JyRhQBobCWZmZsbMrDDAEZqZmRmFayXAIT8JlUn/tpBAGhsJmpmZGYVrJcAR0MzMTOH6EsAhffIHvbccsUAaGwnQzMxM4foSwBFgZmZmHoXzPyFLnu2n0AfSQBobCWBmZmYehfM/EQAAAIBwvRxAIXRSfaUwEeBAGhsJAAAAgHC9HEARMDMzs8xMKkAh3TjFLwkr4UAaGwkwMzOzzEwqQBEyMzOTcB0zQCGDnxrnD8LdQBobCTIzM5NwHTNAEczMzMx6FDlAIeaZb89cpstAGhsJzMzMzHoUOUARZmZmBoULP0Ah8OAcoQSVrEAaGwlmZmYGhQs/QBEAAACgR4FCQCE9NAj60jaAQEKkAhobCQAAAADXozbAEQAAAEAK1/O/IWZmZmYmhstAGhsJAAAAQArX878RAAAAQOF6AEAhZmZmZiaGy0AaGwkAAABA4XoAQBEAAAAgXI8SQCFmZmZmJobLQBobCQAAACBcjxJAEQAAAIDrURxAIWZmZmYmhstAGhsJAAAAgOtRHEARAAAA4KPwIkAhZmZmZiaGy0AaGwkAAADgo/AiQBEAAADAzMwnQCFmZmZmJobLQBobCQAAAMDMzCdAEQAAAKCZmSxAIWZmZmYmhstAGhsJAAAAoJmZLEARAAAAACncMEAhZmZmZiaGy0AaGwkAAAAAKdwwQBEAAABAClc0QCFmZmZmJobLQBobCQAAAEAKVzRAEQAAAKBHgUJAIWZmZmYmhstAIAFCCgoIVCAoZGVnQykaygcQARq2Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBE4Uc7Ay+QTQBnkFSWdAe8aQCBEKQAAAIDCtTjAMQAAAAAAABVAOQAAAOCj8DZAQqICGhsJAAAAgMK1OMARZmZmduvxM8AhtSZF0RAyXUAaGwlmZmZ26/EzwBGamZnZKFwuwCFWQ1rgAtaBQBobCZqZmdkoXC7AEWdmZsZ61CTAIcX4PgdERJtAGhsJZ2ZmxnrUJMARaGZmZpmZFsAhSoAJQLQut0AaGwloZmZmmZkWwBEAAAAA6lHsvyFdYdVxSUnSQBobCQAAAADqUey/EcjMzMw9Cg9AIa0SELCrbeBAGhsJyMzMzD0KD0ARZGZmhj1KIUAhnrtz8CG04EAaGwlkZmaGPUohQBGYmZmZ69EqQCGZrRzuxqHeQBobCZiZmZnr0SpAEWZmZtbMLDJAIfDwDmfJGMtAGhsJZmZm1swsMkARAAAA4KPwNkAh5aOOZob7hkBCpAIaGwkAAACAwrU4wBEAAAAA16MMwCFmZmZmJobLQBobCQAAAADXowzAEQAAAIA9Cue/IWZmZmYmhstAGhsJAAAAgD0K578RAAAAYLge9T8hZmZmZiaGy0AaGwkAAABguB71PxEAAADA9SgKQCFmZmZmJobLQBobCQAAAMD1KApAEQAAAAAAABVAIWZmZmYmhstAGhsJAAAAAAAAFUARAAAAQDMzHUAhZmZmZiaGy0AaGwkAAABAMzMdQBEAAADAzEwiQCFmZmZmJobLQBobCQAAAMDMTCJAEQAAAEAzMyZAIWZmZmYmhstAGhsJAAAAQDMzJkARAAAAgD0KK0AhZmZmZiaGy0AaGwkAAACAPQorQBEAAADgo/A2QCFmZmZmJobLQCABQg0KC1RkZXcgKGRlZ0MpGsUHEAEatAcKuAII+8wIGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AgAUD7zAgRAOMGs3W4cUAZTfsvTsACIUApAAAAIFxfb0AxAAAAACm4cUA5AAAAoHB1c0BCogIaGwkAAAAgXF9vQBHNzMyEQRBwQCHkLM7ik7RpQBobCc3MzIRBEHBAEZqZmfnUcHBAIdyU1jrrxJBAGhsJmpmZ+dRwcEARZmZmbmjRcEAhBrtd4q6usEAaGwlmZmZuaNFwQBEzMzPj+zFxQCHdsnLd2orRQBobCTMzM+P7MXFAEQAAAFiPknFAIRJUoNfP8t9AGhsJAAAAWI+ScUARzczMzCLzcUAhd9RRNcd24UAaGwnNzMzMIvNxQBGamZlBtlNyQCEa9E0e/87dQBobCZqZmUG2U3JAEWZmZrZJtHJAITUZ8LM178tAGhsJZmZmtkm0ckARMzMzK90Uc0AhSIALV9UKrEAaGwkzMzMr3RRzQBEAAACgcHVzQCFoX+0i1QWAQEKkAhobCQAAACBcX29AEQAAACBcC3FAIWZmZmYmhstAGhsJAAAAIFwLcUARAAAAoHBBcUAhZmZmZiaGy0AaGwkAAACgcEFxQBEAAAAAKWxxQCFmZmZmJobLQBobCQAAAAApbHFAEQAAAEAKk3FAIWZmZmYmhstAGhsJAAAAQAqTcUARAAAAACm4cUAhZmZmZiaGy0AaGwkAAAAAKbhxQBEAAABguN5xQCFmZmZmJobLQBobCQAAAGC43nFAEQAAAKBwBXJAIWZmZmYmhstAGhsJAAAAoHAFckARAAAAYLguckAhZmZmZiaGy0AaGwkAAABguC5yQBEAAAAgrmdyQCFmZmZmJobLQBobCQAAACCuZ3JAEQAAAKBwdXNAIWZmZmYmhstAIAFCCgoIVHBvdCAoSykayQcQARq0Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBHI02FQbhcjQBlYcnEwHcEQQCkAAAAghevpPzEAAABgj8IhQDkAAACAPQo8QEKiAhobCQAAACCF6+k/EZqZmY2VQwxAIYW+Wpbvn7ZAGhsJmpmZjZVDDEARmpmZ6SQGGUAhaQotzog+3UAaGwmamZnpJAYZQBE0MzOGP/UhQCFIDYMV227hQBobCTQzM4Y/9SFAEZqZmZdsZydAIXGN1qLRedtAGhsJmpmZl2xnJ0ARAAAAqZnZLEAhmVqAGdWs1EAaGwkAAACpmdksQBE0MzNd4yUxQCENJAyRvPjIQBobCTQzM13jJTFAEWdm5uX53jNAIUzA5lMgFbZAGhsJZ2bm5fneM0ARmpmZbhCYNkAhtX0p1SHYl0AaGwmamZluEJg2QBHNzEz3JlE5QCFL3nl1MaBgQBobCc3MTPcmUTlAEQAAAIA9CjxAITOq9SGHdVNAQqQCGhsJAAAAIIXr6T8RAAAAYI/CEkAhZmZmZiaGy0AaGwkAAABgj8ISQBEAAABAMzMXQCFmZmZmJobLQBobCQAAAEAzMxdAEQAAAKBH4RpAIWZmZmYmhstAGhsJAAAAoEfhGkARAAAAoEfhHkAhZmZmZiaGy0AaGwkAAACgR+EeQBEAAABgj8IhQCFmZmZmJobLQBobCQAAAGCPwiFAEQAAAEDheiRAIWZmZmYmhstAGhsJAAAAQOF6JEARAAAA4FE4J0AhZmZmZiaGy0AaGwkAAADgUTgnQBEAAACAwnUqQCFmZmZmJobLQBobCQAAAIDCdSpAEQAAAMAeBS9AIWZmZmYmhstAGhsJAAAAwB4FL0ARAAAAgD0KPEAhZmZmZiaGy0AgAUIOCgxWUGFjdCAobWJhcikasQcQARqcBwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBECypqFGEAQQBkAf4QlgqITQCC5BDEAAACgmZkBQDkAAAAA18NGQEKZAhoSEZqZmZlFNhJAITYkZxpgavhAGhsJmpmZmUU2EkARmpmZmUU2IkAhrKP+2ANT1kAaGwmamZmZRTYiQBFnZmZmaFErQCEc47RsUX7DQBobCWdmZmZoUStAEZqZmZlFNjJAIclfvvz2krJAGhsJmpmZmUU2MkARAAAAANfDNkAhvohS6FzwnUAaGwkAAAAA18M2QBFnZmZmaFE7QCFS4gJZrYuIQBobCWdmZmZoUTtAEc7MzMz53j9AISXbV6L2J3VAGhsJzszMzPneP0ARmpmZmUU2QkAhItgf/jp1ZEAaGwmamZmZRTZCQBHNzMxMDn1EQCGZQeMHvmdNQBobCc3MzEwOfURAEQAAAADXw0ZAIZlB4we+Z01AQpsCGhIRAAAAgD0K1z8hZmZmZiaGy0AaGwkAAACAPQrXPxEAAABgj8LlPyFmZmZmJobLQBobCQAAAGCPwuU/EQAAACCuR/E/IWZmZmYmhstAGhsJAAAAIK5H8T8RAAAAgML1+D8hZmZmZiaGy0AaGwkAAACAwvX4PxEAAACgmZkBQCFmZmZmJobLQBobCQAAAKCZmQFAEQAAACBcjwhAIWZmZmYmhstAGhsJAAAAIFyPCEARAAAAIFyPEUAhZmZmZiaGy0AaGwkAAAAgXI8RQBEAAACgcD0aQCFmZmZmJobLQBobCQAAAKBwPRpAEQAAAKCZGSVAIWZmZmYmhstAGhsJAAAAoJkZJUARAAAAANfDRkAhZmZmZiaGy0AgAUIOCgxWUGRlZiAobWJhcikayQcQARq0Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBFd/NVzhDcrQBmSBWAdevweQCkAAAAAKVzvPzEAAADgUbgnQDkAAADAzGxPQEKiAhobCQAAAAApXO8/ETMzMwMCqxxAIej8O/v2TtxAGhsJMzMzAwKrHEARMzMzcz+1KkAh4y1hvo476UAaGwkzMzNzP7UqQBFmZmbyfoozQCHrBna/GkHgQBobCWZmZvJ+ijNAETMzMyteujlAIWPKIy2C2s9AGhsJMzMzK166OUARAAAAZD3qP0AhISUfSTxtuUAaGwkAAABkPeo/QBFmZmZODg1DQCEwusp2ty6kQBobCWZmZk4ODUNAEc3MzOr9JEZAIeDgX93zqI5AGhsJzczM6v0kRkARMzMzh+08SUAh7kOw7t1yeEAaGwkzMzOH7TxJQBGZmZkj3VRMQCEWwBwHcLpdQBobCZmZmSPdVExAEQAAAMDMbE9AIYXitrVqQVNAQqQCGhsJAAAAAClc7z8RAAAAIK5HFkAhZmZmZiaGy0AaGwkAAAAgrkcWQBEAAAAAKVwcQCFmZmZmJobLQBobCQAAAAApXBxAEQAAAMAeBSFAIWZmZmYmhstAGhsJAAAAwB4FIUARAAAAgBQuJEAhZmZmZiaGy0AaGwkAAACAFC4kQBEAAADgUbgnQCFmZmZmJobLQBobCQAAAOBRuCdAEQAAAKBH4StAIWZmZmYmhstAGhsJAAAAoEfhK0ARAAAAgOtRMEAhZmZmZiaGy0AaGwkAAACA61EwQBEAAACgcD0zQCFmZmZmJobLQBobCQAAAKBwPTNAEQAAACCF6zdAIWZmZmYmhstAGhsJAAAAIIXrN0ARAAAAwMxsT0AhZmZmZiaGy0AgAUIOCgxWUG1heCAobWJhcikazQcQARq3Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBH1n/5kGOMIQBk2MDTmsVNQQCCUASkAAAAAgIfDwDEAAAAghesHQDkAAAAAAIA3QEKiAhobCQAAAACAh8PAEQAAAABgksHAIRq7JBQ3QCxAGhsJAAAAAGCSwcARAAAAAIA6v8AhGrskFDdALEAaGwkAAAAAgDq/wBEAAAAAQFC7wCEauyQUN0AsQBobCQAAAABAULvAEQAAAAAAZrfAIRq7JBQ3QCxAGhsJAAAAAABmt8ARAAAAAMB7s8AhGrskFDdALEAaGwkAAAAAwHuzwBEAAAAAACOvwCEauyQUN0AsQBobCQAAAAAAI6/AEQAAAACATqfAIRq7JBQ3QCxAGhsJAAAAAIBOp8ARAAAAAAD0nsAhGrskFDdALEAaGwkAAAAAAPSewBEAAAAAAJaOwCEauyQUN0AsQBobCQAAAAAAlo7AEQAAAAAAgDdAIdUqQfjeLwFBQqQCGhsJAAAAAICHw8ARAAAAIIXr8T8hZmZmZiaGy0AaGwkAAAAghevxPxEAAACAwvX4PyFmZmZmJobLQBobCQAAAIDC9fg/EQAAAAAAAABAIWZmZmYmhstAGhsJAAAAAAAAAEARAAAAgBSuA0AhZmZmZiaGy0AaGwkAAACAFK4DQBEAAAAghesHQCFmZmZmJobLQBobCQAAACCF6wdAEQAAAADXowxAIWZmZmYmhstAGhsJAAAAANejDEARAAAAQDMzEUAhZmZmZiaGy0AaGwkAAABAMzMRQBEAAACAwvUUQCFmZmZmJobLQBobCQAAAIDC9RRAEQAAACCF6xpAIWZmZmYmhstAGhsJAAAAIIXrGkARAAAAAACAN0AhZmZmZiaGy0AgAUIPCg1tYXguIHd2IChtL3MpGsUHEAEatAcKuAII+8wIGAEgAS0AAIA/MqQCGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AgAUD7zAgRo9fwx6zpjkAZQ2VTSGesIEApAAAAwPV0jUAxAAAAYLjsjkA5AAAA4FG6j0BCogIaGwkAAADA9XSNQBEAAACQGK+NQCFT15X0zylTQBobCQAAAJAYr41AEQAAAGA76Y1AITB0jbUKp2FAGhsJAAAAYDvpjUARAAAAMF4jjkAhEzwa9vrehEAaGwkAAAAwXiOOQBEAAAAAgV2OQCGKHaXrNtSlQBobCQAAAACBXY5AEQAAANCjl45AIfDL+SA5IMZAGhsJAAAA0KOXjkARAAAAoMbRjkAhlkd7rOUK30AaGwkAAACgxtGOQBEAAABw6QuPQCEEzScqdC3pQBobCQAAAHDpC49AEQAAAEAMRo9AITx3jVkmmt9AGhsJAAAAQAxGj0ARAAAAEC+Aj0AhHqLceumRwUAaGwkAAAAQL4CPQBEAAADgUbqPQCHpnHTTO9ySQEKkAhobCQAAAMD1dI1AEQAAAMDMlI5AIWZmZmYmhstAGhsJAAAAwMyUjkARAAAAgBS2jkAhZmZmZiaGy0AaGwkAAACAFLaOQBEAAACAPcyOQCFmZmZmJobLQBobCQAAAIA9zI5AEQAAACCF3Y5AIWZmZmYmhstAGhsJAAAAIIXdjkARAAAAYLjsjkAhZmZmZiaGy0AaGwkAAABguOyOQBEAAAAghfuOQCFmZmZmJobLQBobCQAAACCF+45AEQAAAIA9DI9AIWZmZmYmhstAGhsJAAAAgD0Mj0ARAAAAANcfj0AhZmZmZiaGy0AaGwkAAAAA1x+PQBEAAADAzDqPQCFmZmZmJobLQBobCQAAAMDMOo9AEQAAAOBRuo9AIWZmZmYmhstAIAFCCgoIcCAobWJhcikawwcQARq0Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBGlJtLsyftSQBmNLvQa8IMwQCkAAACAPQorQDEAAADAzMxTQDkAAAAAAABZQEKiAhobCQAAAIA9CitAETMzMxMCKzZAIVpHUiZ8+1VAGhsJMzMzEwIrNkARZmZmZuXQPkAhJFnBDmj7d0AaGwlmZmZm5dA+QBHMzMxcZLtDQCFiSpJEMv2nQBobCczMzFxku0NAEWZmZgZWDkhAIUw0MtLBsr1AGhsJZmZmBlYOSEARAAAAsEdhTEAhM/2pCtHRxEAaGwkAAACwR2FMQBHMzMysHFpQQCFHJsU7uDbLQBobCczMzKwcWlBAEZmZmYGVg1JAITfYHpTlQtNAGhsJmZmZgZWDUkARZmZmVg6tVEAhXv01pvjd2UAaGwlmZmZWDq1UQBEzMzMrh9ZWQCE6GsOsw0beQBobCTMzMyuH1lZAEQAAAAAAAFlAIWtQMJyZUNtAQqQCGhsJAAAAgD0KK0ARAAAAIFxvSUAhZmZmZiaGy0AaGwkAAAAgXG9JQBEAAACgcH1OQCFmZmZmJobLQBobCQAAAKBwfU5AEQAAACCuJ1FAIWZmZmYmhstAGhsJAAAAIK4nUUARAAAAoJmZUkAhZmZmZiaGy0AaGwkAAACgmZlSQBEAAADAzMxTQCFmZmZmJobLQBobCQAAAMDMzFNAEQAAAKCZ2VRAIWZmZmYmhstAGhsJAAAAoJnZVEARAAAAAADgVUAhZmZmZiaGy0AaGwkAAAAAAOBVQBEAAABAM9NWQCFmZmZmJobLQBobCQAAAEAz01ZAEQAAAAAAwFdAIWZmZmYmhstAGhsJAAAAAADAV0ARAAAAAAAAWUAhZmZmZiaGy0AgAUIICgZyaCAoJSkayQcQARq0Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBE5vgIumP+SQBlPQ+YPx/ZDQCkAAACgmTCRQDEAAABA4faSQDkAAACAPcKVQEKiAhobCQAAAKCZMJFAEZqZmWmQpZFAIatF/HwfmpBAGhsJmpmZaZClkUARMzMzM4cakkAh6r2Mq/p9v0AaGwkzMzMzhxqSQBHNzMz8fY+SQCEXv6nsjTjaQBobCc3MzPx9j5JAEWZmZsZ0BJNAITjJ91+WEeNAGhsJZmZmxnQEk0ARAAAAkGt5k0AhDAAo6Oit4EAaGwkAAACQa3mTQBGamZlZYu6TQCFTW/4GBwjVQBobCZqZmVli7pNAETMzMyNZY5RAIbAO3+XY9r5AGhsJMzMzI1ljlEARzczM7E/YlEAhgJmxKIqEl0AaGwnNzMzsT9iUQBFmZma2Rk2VQCHUfXWI4yd6QBobCWZmZrZGTZVAEQAAAIA9wpVAIbr/KtBb23VAQqQCGhsJAAAAoJkwkUARAAAAYLg4kkAhZmZmZiaGy0AaGwkAAABguDiSQBEAAACgmXWSQCFmZmZmJobLQBobCQAAAKCZdZJAEQAAAOBRo5JAIWZmZmYmhstAGhsJAAAA4FGjkkARAAAAwPXMkkAhZmZmZiaGy0AaGwkAAADA9cySQBEAAABA4faSQCFmZmZmJobLQBobCQAAAEDh9pJAEQAAAKCZIZNAIWZmZmYmhstAGhsJAAAAoJkhk0ARAAAAAABQk0AhZmZmZiaGy0AaGwkAAAAAAFCTQBEAAAAAKYmTQCFmZmZmJobLQBobCQAAAAApiZNAEQAAAOB60pNAIWZmZmYmhstAGhsJAAAA4HrSk0ARAAAAgD3ClUAhZmZmZiaGy0AgAUIOCgxyaG8gKGcvbSoqMykaxgcQARq0Bwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBGD1sHYsR4YQBmW4T3/g0UFQCkAAACA61HgPzEAAADgo3AWQDkAAACAFO4xQEKiAhobCQAAAIDrUeA/EWZmZpYYBAJAIc9SSQ7IubdAGhsJZmZmlhgEAkARzczMTLbzD0Ahy0WYhRou3kAaGwnNzMxMtvMPQBGamZkBqvEWQCGsmyiXNmzhQBobCZqZmQGq8RZAEc3MzNx46R1AIfhPzThtsNtAGhsJzczM3HjpHUARAAAA3KNwIkAhCIwI5Vkw1EAaGwkAAADco3AiQBGamZlJi+wlQCHhmnvqExrIQBobCZqZmUmL7CVAETMzM7dyaClAIeUajGB+xbRAGhsJMzMzt3JoKUARzczMJFrkLEAhL002XyW5lUAaGwnNzMwkWuQsQBE0MzPJIDAwQCFA4R7CRU1cQBobCTQzM8kgMDBAEQAAAIAU7jFAIcpJ+pcBtlJAQqQCGhsJAAAAgOtR4D8RAAAAoJmZB0AhZmZmZiaGy0AaGwkAAACgmZkHQBEAAABAMzMNQCFmZmZmJobLQBobCQAAAEAzMw1AEQAAAIDC9RBAIWZmZmYmhstAGhsJAAAAgML1EEARAAAAwB6FE0AhZmZmZiaGy0AaGwkAAADAHoUTQBEAAADgo3AWQCFmZmZmJobLQBobCQAAAOCjcBZAEQAAAEAK1xlAIWZmZmYmhstAGhsJAAAAQArXGUARAAAAgOtRHUAhZmZmZiaGy0AaGwkAAACA61EdQBEAAADgUbggQCFmZmZmJobLQBobCQAAAOBRuCBAEQAAAGC4niNAIWZmZmYmhstAGhsJAAAAYLieI0ARAAAAgBTuMUAhZmZmZiaGy0AgAUILCglzaCAoZy9rZykarQcQARqcBwq4Agj7zAgYASABLQAAgD8ypAIaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQCABQPvMCBErftv8zNVlQBnRXNcQE7hVQCCUATEAAABAM8NoQDkAAAAAAIB2QEKZAhoSEQAAAAAAAEJAIajPUqNj9dBAGhsJAAAAAAAAQkARAAAAAAAAUkAh+GwMP5WNx0AaGwkAAAAAAABSQBEAAAAAAABbQCFXh7S4+rOuQBobCQAAAAAAAFtAEQAAAAAAAGJAISJC6hetNbhAGhsJAAAAAAAAYkARAAAAAACAZkAhpw102vhI0EAaGwkAAAAAAIBmQBEAAAAAAABrQCEbL90kTnrhQBobCQAAAAAAAGtAEQAAAAAAgG9AIa0cCr+YZ9lAGhsJAAAAAACAb0ARAAAAAAAAckAhgJayWvkzzkAaGwkAAAAAAAByQBEAAAAAAEB0QCGRzXAg1marQBobCQAAAAAAQHRAEQAAAAAAgHZAIWZXr1sOla5AQpsCGhIRAAAAwB6FPkAhZmZmZiaGy0AaGwkAAADAHoU+QBEAAABAM0NQQCFmZmZmJobLQBobCQAAAEAzQ1BAEQAAAAAAAGNAIWZmZmYmhstAGhsJAAAAAAAAY0ARAAAAYGaGZkAhZmZmZiaGy0AaGwkAAABgZoZmQBEAAABAM8NoQCFmZmZmJobLQBobCQAAAEAzw2hAEQAAAGBmRmpAIWZmZmYmhstAGhsJAAAAYGZGakARAAAAoJn5a0AhZmZmZiaGy0AaGwkAAACgmflrQBEAAABAM6NuQCFmZmZmJobLQBobCQAAAEAzo25AEQAAAMDMdHBAIWZmZmYmhstAGhsJAAAAwMx0cEARAAAAAACAdkAhZmZmZiaGy0AgAUIKCgh3ZCAoZGVnKRrIBxABGrcHCrgCCPvMCBgBIAEtAACAPzKkAhobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAGhsJAAAAAAAA8D8RAAAAAAAA8D8hZmZmZiaGy0AaGwkAAAAAAADwPxEAAAAAAADwPyFmZmZmJobLQBobCQAAAAAAAPA/EQAAAAAAAPA/IWZmZmYmhstAIAFA+8wIEXelKT++lP0/GeVIvyX8pkpAIKQBKQAAAACAh8PAMQAAAMD1KPw/OQAAAKBwfTxAQqICGhsJAAAAAICHw8ARzczEICCSwcAh6L5u4NBDLEAaGwnNzMQgIJLBwBEzMxODgDm/wCHwvm7g0EMsQBobCTMzE4OAOb/AEc3MnMTATrvAIei+buDQQyxAGhsJzcycxMBOu8ARZmYmBgFkt8Ah8L5u4NBDLEAaGwlmZiYGAWS3wBEAALBHQXmzwCHovm7g0EMsQBobCQAAsEdBebPAETQzcxIDHa/AIei+buDQQyxAGhsJNDNzEgMdr8ARZmaGlYNHp8Ah8L5u4NBDLEAaGwlmZoaVg0enwBE0MzMxCOSewCHovm7g0EMsQBobCTQzMzEI5J7AETAzs24Sco7AIfC+buDQQyxAGhsJMDOzbhJyjsARAAAAoHB9PEAhbXCgdt4vAUFCpAIaGwkAAAAAgIfDwBEAAACgcD3iPyFmZmZmJobLQBobCQAAAKBwPeI/EQAAAMAehes/IWZmZmYmhstAGhsJAAAAwB6F6z8RAAAAoHA98j8hZmZmZiaGy0AaGwkAAACgcD3yPxEAAACgR+H2PyFmZmZmJobLQBobCQAAAKBH4fY/EQAAAMD1KPw/IWZmZmYmhstAGhsJAAAAwPUo/D8RAAAAgD0KAUAhZmZmZiaGy0AaGwkAAACAPQoBQBEAAAAA16MEQCFmZmZmJobLQBobCQAAAADXowRAEQAAAOCjcAlAIWZmZmYmhstAGhsJAAAA4KNwCUARAAAAYI/CEEAhZmZmZiaGy0AaGwkAAABgj8IQQBEAAACgcH08QCFmZmZmJobLQCABQgoKCHd2IChtL3Mp"></facets-overview>';
        facets_iframe.srcdoc = facets_html;
         facets_iframe.id = "";
         setTimeout(() => {
           facets_iframe.setAttribute('height', facets_iframe.contentWindow.document.body.offsetHeight + 'px')
         }, 1500)
         </script>


From the charts above, you might notice that the minimum value for `wv (m/s)` is `-9999`. Those are pretty intense winds and based on the other data points, this just looks like a faulty measurement. You can also use the utilities below to inspect the dataset. You will notice this `-9999` value as an outlier in the `wv (m/s)` plot.


```python
# Visualization Utilities
import matplotlib.pyplot as plt

# Color Palette
colors = [
    "blue",
    "orange",
    "green",
    "red",
    "purple",
    "brown",
    "pink",
    "gray",
    "olive",
    "cyan",
]

# Dataset Columns
feature_keys = [
    "p (mbar)",
    "T (degC)",
    "Tpot (K)",
    "Tdew (degC)", 
    "rh (%)", 
    "VPmax (mbar)", 
    "VPact (mbar)", 
    "VPdef (mbar)", 
    "sh (g/kg)",
    "H2OC (mmol/mol)",
    "rho (g/m**3)",
    "wv (m/s)",
    "max. wv (m/s)",
    "wd (deg)",
]

# Plots each column as a time series
def visualize_plots(dataset, columns):
    features = dataset[columns]
    fig, axes = plt.subplots(
        nrows=len(columns)//2 + len(columns)%2, ncols=2, figsize=(15, 20), dpi=80, facecolor="w", edgecolor="k"
    )
    for i, col in enumerate(columns):
        c = colors[i % (len(colors))]
        t_data = dataset[col]
        t_data.index = dataset.index
        t_data.head()
        ax = t_data.plot(
            ax=axes[i // 2, i % 2],
            color=c,
            title="{}".format(col),
            rot=25,
        )
    ax.legend([col])
    plt.tight_layout()
```


```python
# Visualize the dataset
visualize_plots(df, feature_keys)
```


    
![png](output_21_0.png)
    


In real projects, you will need to clean this up. If you want, you can drop those rows from the CSV and ingest the data again through ExampleGen. For this exercise however, we will just proceed to the next step.

## SchemaGen

You will now infer the schema based on the statistics artifact. For the version of TFX you are using, you will have to explicitly set `infer_feature_shape=True` so the downstream TFX components (e.g. Transform) will parse input as a `Tensor` and not `SparseTensor`. If not set, you will have compatibility issues later when you run the transform.


```python
# Instantiate SchemaGen with the StatisticsGen ingested dataset
schema_gen = SchemaGen(
    statistics=statistics_gen.outputs['statistics'], 
    infer_feature_shape=True
    )

# Run the component
context.run(schema_gen)
```




<style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object expanded"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExecutionResult</span><span class="deemphasize"> at 0x7f27d74ff730</span></div><table class="attr-table"><tr><td class="attr-name">.execution_id</td><td class = "attrvalue">3</td></tr><tr><td class="attr-name">.component</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">SchemaGen</span><span class="deemphasize"> at 0x7f275b9e7310</span></div><table class="attr-table"><tr><td class="attr-name">.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.exec_properties</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['infer_feature_shape']</td><td class = "attrvalue">True</td></tr><tr><td class="attr-name">['exclude_splits']</td><td class = "attrvalue">[]</td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">.component.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.component.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr></table></div>




```python
# Visualize the schema
context.show(schema_gen.outputs['schema'])
```


<b>Artifact at ./pipeline/SchemaGen/schema/3</b><br/><br/>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Presence</th>
      <th>Valency</th>
      <th>Domain</th>
    </tr>
    <tr>
      <th>Feature name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>'Date Time'</th>
      <td>BYTES</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'H2OC (mmol/mol)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'T (degC)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'Tdew (degC)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'Tpot (K)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'VPact (mbar)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'VPdef (mbar)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'VPmax (mbar)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'max. wv (m/s)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'p (mbar)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'rh (%)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'rho (g/m**3)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'sh (g/kg)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'wd (deg)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
    <tr>
      <th>'wv (m/s)'</th>
      <td>FLOAT</td>
      <td>required</td>
      <td></td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>


Again, for the purpose of this exercise, we will accept this initial version of the schema. In actual projects though, you may want to restrict the domain (e.g. numeric range) so you can avoid invalid data from going into your training set.

## ExampleValidator

Let's check for anomalies to ensure our dataset conforms to the schema.


```python
# Instantiate ExampleValidator with the StatisticsGen and SchemaGen ingested data
example_validator = ExampleValidator(
    statistics=statistics_gen.outputs['statistics'],
    schema=schema_gen.outputs['schema'])

# Run the component.
context.run(example_validator)
```




<style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object expanded"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExecutionResult</span><span class="deemphasize"> at 0x7f275b9e75b0</span></div><table class="attr-table"><tr><td class="attr-name">.execution_id</td><td class = "attrvalue">4</td></tr><tr><td class="attr-name">.component</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExampleValidator</span><span class="deemphasize"> at 0x7f266d8d65e0</span></div><table class="attr-table"><tr><td class="attr-name">.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['anomalies']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleAnomalies'</span> (1 artifact)<span class="deemphasize"> at 0x7f266d8d65b0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleAnomalies</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleAnomalies'</span> (uri: ./pipeline/ExampleValidator/anomalies/4)<span class="deemphasize"> at 0x7f275b9e74f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleAnomalies&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/ExampleValidator/anomalies/4</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.exec_properties</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['exclude_splits']</td><td class = "attrvalue">[]</td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">.component.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['statistics']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleStatistics'</span> (1 artifact)<span class="deemphasize"> at 0x7f27d7807130</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleStatistics</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleStatistics'</span> (uri: ./pipeline/StatisticsGen/statistics/2)<span class="deemphasize"> at 0x7f27f049a1f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleStatistics&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/StatisticsGen/statistics/2</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.component.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['anomalies']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'ExampleAnomalies'</span> (1 artifact)<span class="deemphasize"> at 0x7f266d8d65b0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">ExampleAnomalies</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'ExampleAnomalies'</span> (uri: ./pipeline/ExampleValidator/anomalies/4)<span class="deemphasize"> at 0x7f275b9e74f0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.ExampleAnomalies&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/ExampleValidator/anomalies/4</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr></table></div>




```python
# Visualize the results
context.show(example_validator.outputs['anomalies'])
```


<b>Artifact at ./pipeline/ExampleValidator/anomalies/4</b><br/><br/>



<div><b>'train' split:</b></div><br/>



<h4 style="color:green;">No anomalies found.</h4>



<div><b>'eval' split:</b></div><br/>



<h4 style="color:green;">No anomalies found.</h4>


## Transform

Now you will be doing feature engineering. There are several things to note before doing the transformation:

### Correlated features

You may want to drop redundant features to reduce the complexity of your model. Let's see what features are highly correlated with each other by plotting the correlation matrix.


```python
import seaborn as sns

def show_correlation_heatmap(dataframe):
    plt.figure(figsize=(20,20))
    cor = dataframe.corr()
    sns.heatmap(cor, annot=True, cmap=plt.cm.PuBu)
    plt.show()
```


```python
show_correlation_heatmap(df)
```


    
![png](output_34_0.png)
    


You can observe that `Tpot (K)`, `Tdew (degC)`, `VPmax(mbar)`, `Vpact(mbar)`, `VPdef (mbar)`, `sh(g/kg)` and `H2OC` are highly positively correlated to the target `T (degC)`. Likewise, `rho` is highly negatively correlated to the target. 

In the features that are positively correlated, you can see that `VPmax (mbar)` is highly correlated to some features like `Vpact (mbar)`, `Tdew (degC)` and `Tpot (K)`. Hence, for the sake of this exercise you can drop these features and retain `VPmax (mbar)`. This step will be done in the Transform module.

#### Distribution of Wind Data

The last column of the data, `wd (deg)`, gives the wind direction in units of degrees. However, angles in this current format do not make good model inputs. 360° and 0° should be close to each other and wrap around smoothly. Direction shouldn't matter if the wind is not blowing. This will be easier for the model to interpret if you convert the wind direction and velocity columns to a wind vector. Observe how sine and cosine are used to generate wind vector features (`Wx` and `Wy`) in the Transform module below.

#### Date Time Feature

Similarly, the `Date Time` column is very useful but not in the current string format. First, you need to convert it to to seconds. Being weather data, it has clear daily and yearly periodicity, and you need to take that into account.

A simple approach to convert it to a usable signal is to again use sine and cosine to convert the time to clear "Time of day" (`Day sin`, `Day cos`) and "Time of year" (`Year sin`, `Year cos`) signals. 

### Transform Module

With the three points above considered, you can now build the transform module.


```python
# Set the constants module filename
_weather_constants_module_file = 'weather_constants.py'
```


```python
%%writefile {_weather_constants_module_file}

# Selected numeric features to transform
SELECTED_NUMERIC_FEATURES = ['T (degC)', 'VPmax (mbar)', 'VPdef (mbar)', 'sh (g/kg)','rho (g/m**3)']

# Utility function for renaming the feature
def transformed_name(key):
    return key + '_xf'
```

    Writing weather_constants.py



```python
# Set the transform module filename
_weather_transform_module_file = 'weather_transform.py'
```


```python
%%writefile {_weather_transform_module_file}

import tensorflow as tf
import tensorflow_transform as tft

import weather_constants
import tensorflow_addons as tfa

import math as m

# Features to filter out
FEATURES_TO_REMOVE = ["Tpot (K)", "Tdew (degC)","VPact (mbar)" , "H2OC (mmol/mol)", "max. wv (m/s)"]

# Unpack the contents of the constants module
_SELECTED_NUMERIC_FEATURE_KEYS = weather_constants.SELECTED_NUMERIC_FEATURES
_transformed_name = weather_constants.transformed_name

# Define the transformations
def preprocessing_fn(inputs):
    """Preprocess input columns into transformed columns."""

    outputs = inputs.copy()

    # Filter redundant features
    for key in FEATURES_TO_REMOVE:
        del outputs[key]

    # Convert degrees to radians
    pi = tf.constant(m.pi)
    wd_rad = inputs['wd (deg)'] * pi / 180.0

    # Calculate the wind x and y components.
    outputs['Wx'] = inputs['wv (m/s)'] * tf.math.cos(wd_rad)
    outputs['Wy'] = inputs['wv (m/s)'] * tf.math.sin(wd_rad)

    # Delete `wv (m/s)` after getting the wind vector
    del outputs['wv (m/s)']

    # Get day and year in seconds
    day = tf.cast(24*60*60, tf.float32)
    year = tf.cast((365.2425)*day, tf.float32)

    # Convert `Date Time` column into timestamps in seconds (using tfa helper function)
    timestamp_s = tfa.text.parse_time(outputs['Date Time'], time_format='%d.%m.%Y %H:%M:%S', output_unit='SECOND')
    timestamp_s = tf.cast(timestamp_s, tf.float32)
    
    # Convert timestamps into periodic signals
    outputs['Day sin'] = tf.math.sin(timestamp_s * (2 * pi / day))
    outputs['Day cos'] = tf.math.cos(timestamp_s * (2 * pi / day))
    outputs['Year sin'] = tf.math.sin(timestamp_s * (2 * pi / year))
    outputs['Year cos'] = tf.math.cos(timestamp_s * (2 * pi / year))

    # Delete unneeded columns
    del outputs['Date Time']
    del outputs['wd (deg)']

    # Final feature list
    FINAL_FEATURE_LIST =  ["p (mbar)",
    "T (degC)",
    "rh (%)", 
    "VPmax (mbar)", 
    "VPdef (mbar)", 
    "sh (g/kg)",
    "rho (g/m**3)",
    "Wx",
    "Wy",
    "Day sin",
    'Day cos',
    'Year sin',
    'Year cos'
    ]

    # Scale selected numeric features
    for key in _SELECTED_NUMERIC_FEATURE_KEYS:
        outputs[key] = tft.scale_to_0_1(outputs[key])

    return outputs
```

    Writing weather_transform.py


Run the `Transform` component below to perform the transformations.


```python
# Ignore TF warning messages
tf.get_logger().setLevel('ERROR')

# Instantiate the Transform component
transform = Transform(
    examples=example_gen.outputs['examples'],
    schema=schema_gen.outputs['schema'],
    module_file=os.path.abspath(_weather_transform_module_file))

# Run the component
context.run(transform)
```

    WARNING:root:This output type hint will be ignored and not used for type-checking purposes. Typically, output type hints for a PTransform are single (or nested) types wrapped by a PCollection, PDone, or None. Got: Tuple[Dict[str, Union[NoneType, _Dataset]], Union[Dict[str, Dict[str, PCollection]], NoneType]] instead.
    WARNING:root:This output type hint will be ignored and not used for type-checking purposes. Typically, output type hints for a PTransform are single (or nested) types wrapped by a PCollection, PDone, or None. Got: Tuple[Dict[str, Union[NoneType, _Dataset]], Union[Dict[str, Dict[str, PCollection]], NoneType]] instead.
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring send_type hint: <class 'NoneType'>
    WARNING:apache_beam.typehints.typehints:Ignoring return_type hint: <class 'NoneType'>





<style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object expanded"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">ExecutionResult</span><span class="deemphasize"> at 0x7f276cca6100</span></div><table class="attr-table"><tr><td class="attr-name">.execution_id</td><td class = "attrvalue">5</td></tr><tr><td class="attr-name">.component</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Transform</span><span class="deemphasize"> at 0x7f2674070490</span></div><table class="attr-table"><tr><td class="attr-name">.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['transform_graph']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'TransformGraph'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070190</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">TransformGraph</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'TransformGraph'</span> (uri: ./pipeline/Transform/transform_graph/5)<span class="deemphasize"> at 0x7f276ccb88b0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.TransformGraph&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/transform_graph/5</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['transformed_examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070af0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/Transform/transformed_examples/5)<span class="deemphasize"> at 0x7f276ccb8c70</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/transformed_examples/5</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['updated_analyzer_cache']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'TransformCache'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070370</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">TransformCache</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'TransformCache'</span> (uri: ./pipeline/Transform/updated_analyzer_cache/5)<span class="deemphasize"> at 0x7f276ccb82e0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.TransformCache&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/updated_analyzer_cache/5</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.exec_properties</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['module_file']</td><td class = "attrvalue">/home/jovyan/work/weather_transform.py</td></tr><tr><td class="attr-name">['preprocessing_fn']</td><td class = "attrvalue">None</td></tr><tr><td class="attr-name">['custom_config']</td><td class = "attrvalue">null</td></tr><tr><td class="attr-name">['splits_config']</td><td class = "attrvalue">None</td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">.component.inputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f27f049a3d0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/CsvExampleGen/examples/1)<span class="deemphasize"> at 0x7f27d79d6340</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/CsvExampleGen/examples/1</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['schema']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Schema'</span> (1 artifact)<span class="deemphasize"> at 0x7f275b9e76a0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Schema</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Schema'</span> (uri: ./pipeline/SchemaGen/schema/3)<span class="deemphasize"> at 0x7f27d7442670</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Schema&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/SchemaGen/schema/3</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr><tr><td class="attr-name">.component.outputs</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">['transform_graph']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'TransformGraph'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070190</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">TransformGraph</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'TransformGraph'</span> (uri: ./pipeline/Transform/transform_graph/5)<span class="deemphasize"> at 0x7f276ccb88b0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.TransformGraph&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/transform_graph/5</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['transformed_examples']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'Examples'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070af0</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">Examples</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'Examples'</span> (uri: ./pipeline/Transform/transformed_examples/5)<span class="deemphasize"> at 0x7f276ccb8c70</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.Examples&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/transformed_examples/5</td></tr><tr><td class="attr-name">.span</td><td class = "attrvalue">0</td></tr><tr><td class="attr-name">.split_names</td><td class = "attrvalue">[&quot;train&quot;, &quot;eval&quot;]</td></tr><tr><td class="attr-name">.version</td><td class = "attrvalue">0</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr><tr><td class="attr-name">['updated_analyzer_cache']</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Channel</span> of type <span class="class-name">'TransformCache'</span> (1 artifact)<span class="deemphasize"> at 0x7f2674070370</span></div><table class="attr-table"><tr><td class="attr-name">.type_name</td><td class = "attrvalue">TransformCache</td></tr><tr><td class="attr-name">._artifacts</td><td class = "attrvalue"><table class="attr-table"><tr><td class="attr-name">[0]</td><td class = "attrvalue"><style>
.tfx-object.expanded {
  padding: 4px 8px 4px 8px;
  background: white;
  border: 1px solid #bbbbbb;
  box-shadow: 4px 4px 2px rgba(0,0,0,0.05);
}
.tfx-object, .tfx-object * {
  font-size: 11pt;
}
.tfx-object > .title {
  cursor: pointer;
}
.tfx-object .expansion-marker {
  color: #999999;
}
.tfx-object.expanded > .title > .expansion-marker:before {
  content: '▼';
}
.tfx-object.collapsed > .title > .expansion-marker:before {
  content: '▶';
}
.tfx-object .class-name {
  font-weight: bold;
}
.tfx-object .deemphasize {
  opacity: 0.5;
}
.tfx-object.collapsed > table.attr-table {
  display: none;
}
.tfx-object.expanded > table.attr-table {
  display: block;
}
.tfx-object table.attr-table {
  border: 2px solid white;
  margin-top: 5px;
}
.tfx-object table.attr-table td.attr-name {
  vertical-align: top;
  font-weight: bold;
}
.tfx-object table.attr-table td.attrvalue {
  text-align: left;
}
</style>
<script>
function toggleTfxObject(element) {
  var objElement = element.parentElement;
  if (objElement.classList.contains('collapsed')) {
    objElement.classList.remove('collapsed');
    objElement.classList.add('expanded');
  } else {
    objElement.classList.add('collapsed');
    objElement.classList.remove('expanded');
  }
}
</script>
<div class="tfx-object collapsed"><div class = "title" onclick="toggleTfxObject(this)"><span class="expansion-marker"></span><span class="class-name">Artifact</span> of type <span class="class-name">'TransformCache'</span> (uri: ./pipeline/Transform/updated_analyzer_cache/5)<span class="deemphasize"> at 0x7f276ccb82e0</span></div><table class="attr-table"><tr><td class="attr-name">.type</td><td class = "attrvalue">&lt;class &#x27;tfx.types.standard_artifacts.TransformCache&#x27;&gt;</td></tr><tr><td class="attr-name">.uri</td><td class = "attrvalue">./pipeline/Transform/updated_analyzer_cache/5</td></tr></table></div></td></tr></table></td></tr></table></div></td></tr></table></td></tr></table></div>



As a sanity check, let's preview the results in the following cells.


```python
# Get the URI of the output artifact representing the transformed examples
train_uri = os.path.join(transform.outputs['transformed_examples'].get()[0].uri, 'train')

# Get the list of files in this directory (all compressed TFRecord files)
tfrecord_filenames = [os.path.join(train_uri, name)
                      for name in os.listdir(train_uri)]

# Create a `TFRecordDataset` to read these files
transformed_dataset = tf.data.TFRecordDataset(tfrecord_filenames, compression_type="GZIP")
```


```python
# Define a helper function to get individual examples
def get_records(dataset, num_records):
    '''Extracts records from the given dataset.
    Args:
        dataset (TFRecordDataset): dataset saved by ExampleGen
        num_records (int): number of records to preview
    '''
    
    # initialize an empty list
    records = []
    
    # Use the `take()` method to specify how many records to get
    for tfrecord in dataset.take(num_records):
        
        # Get the numpy property of the tensor
        serialized_example = tfrecord.numpy()
        
        # Initialize a `tf.train.Example()` to read the serialized data
        example = tf.train.Example()
        
        # Read the example data (output is a protocol buffer message)
        example.ParseFromString(serialized_example)
        
        # convert the protocol bufffer message to a Python dictionary
        example_dict = (MessageToDict(example))
        
        # append to the records list
        records.append(example_dict)
        
    return records
```


```python
# Get 3 records from the dataset
sample_records_xf = get_records(transformed_dataset, 3)

# Print the output
pp.pprint(sample_records_xf)
```

    [{'features': {'feature': {'Day cos': {'floatList': {'value': [0.9988126]}},
                               'Day sin': {'floatList': {'value': [0.048717435]}},
                               'T (degC)': {'floatList': {'value': [0.2486316]}},
                               'VPdef (mbar)': {'floatList': {'value': [0.0047815694]}},
                               'VPmax (mbar)': {'floatList': {'value': [0.03788602]}},
                               'Wx': {'floatList': {'value': [-0.9119556]}},
                               'Wy': {'floatList': {'value': [0.47878695]}},
                               'Year cos': {'floatList': {'value': [0.9999552]}},
                               'Year sin': {'floatList': {'value': [0.009468557]}},
                               'p (mbar)': {'floatList': {'value': [996.52]}},
                               'rh (%)': {'floatList': {'value': [93.3]}},
                               'rho (g/m**3)': {'floatList': {'value': [0.7432129]}},
                               'sh (g/kg)': {'floatList': {'value': [0.081678964]}}}}},
     {'features': {'feature': {'Day cos': {'floatList': {'value': [0.9909451]}},
                               'Day sin': {'floatList': {'value': [0.1342675]}},
                               'T (degC)': {'floatList': {'value': [0.2405042]}},
                               'VPdef (mbar)': {'floatList': {'value': [0.0043468815]}},
                               'VPmax (mbar)': {'floatList': {'value': [0.035975803]}},
                               'Wx': {'floatList': {'value': [-0.18796174]}},
                               'Wy': {'floatList': {'value': [0.02775571]}},
                               'Year cos': {'floatList': {'value': [0.999953]}},
                               'Year sin': {'floatList': {'value': [0.009697429]}},
                               'p (mbar)': {'floatList': {'value': [996.53]}},
                               'rh (%)': {'floatList': {'value': [93.9]}},
                               'rho (g/m**3)': {'floatList': {'value': [0.7506659]}},
                               'sh (g/kg)': {'floatList': {'value': [0.07827567]}}}}},
     {'features': {'feature': {'Day cos': {'floatList': {'value': [0.98356515]}},
                               'Day sin': {'floatList': {'value': [0.18055356]}},
                               'T (degC)': {'floatList': {'value': [0.2438215]}},
                               'VPdef (mbar)': {'floatList': {'value': [0.0041295374]}},
                               'VPmax (mbar)': {'floatList': {'value': [0.036771726]}},
                               'Wx': {'floatList': {'value': [-0.32335916]}},
                               'Wy': {'floatList': {'value': [-0.10506593]}},
                               'Year cos': {'floatList': {'value': [0.99995166]}},
                               'Year sin': {'floatList': {'value': [0.0098347515]}},
                               'p (mbar)': {'floatList': {'value': [996.51]}},
                               'rh (%)': {'floatList': {'value': [94.2]}},
                               'rho (g/m**3)': {'floatList': {'value': [0.7475229]}},
                               'sh (g/kg)': {'floatList': {'value': [0.08054453]}}}}}]


## Prepare Training Datasets from TFTransformOutput ¶


Now that you have the transformed dataset, you can process this further depending on the model you will be training. For time series data, it makes sense to group a fixed-length series of measurements and map that to the label found in a future time step. For example, 3 days of data can be used the predict the next day's humidity. You can use the [tf.data.Dataset.window()](https://www.tensorflow.org/api_docs/python/tf/data/Dataset#window) method to implement these groupings.

In this exercise, you will use data from the last 5 days to predict the temperature 12 hours into the future. 

* You already know that data is taken every 10 minutes so there will be 720 data points for 5 days. 
* You will also assume that drastic change is not expected within an hour so you will downsample the 720 data points to 120 by just getting the data every hour. Thus, you will use a *stride* (or step size) of 6 when getting the data points. This makes the `HISTORY_SIZE` for the feature window equal to 120. 
* For this single step prediction model (forecasting), the label for a dataset window will be the temperature 12 hours into the future.
* By default, the `window()` method moves `size` (i.e. window size) steps at a time. For example, if you have a dataset with elements `[1, 2, 3, 4]` and you have `size=2`, then your results will look like: `[1, 2], [3, 4]`. You can reconfigure this behavior and move at smaller or larger steps with the `shift` parameter. For the same sample dataset with window `size=2` but with `shift=1`, the results will look like `[1, 2], [2,3], [3,4]` because the window is moving `1` element at a time.


```python
# Constants to prepare the transformed data for modeling

WORKING_DIR = transform.outputs['transform_graph'].get()[0].uri
LABEL_KEY = 'T (degC)'
OBSERVATIONS_PER_HOUR = 6
HISTORY_SIZE = 120
FUTURE_TARGET = 12
BATCH_SIZE = 72
SHIFT = 1
```

You first need to get a wrapper to the transform graph so you can get information from it. That is done with the `tft.TFTransformOutput()` method and we can use it to extract the index of our label.


```python
import tensorflow_transform as tft

# Get the output of the Transform component
tf_transform_output = tft.TFTransformOutput(os.path.join(WORKING_DIR))

# Get the index of the label key
index_of_label = list(tf_transform_output.transformed_feature_spec().keys()).index(LABEL_KEY)
print(index_of_label)
```

    2


Next, you will define several helper functions to extract the data from your transformed dataset and group it into windows. First, this `parse_function()` will help in getting the transformed features and rearranging them so that the label values (i.e. `T (degC)`) is at the end of the tensor.


```python
def parse_function(example_proto):
    
    feature_spec = tf_transform_output.transformed_feature_spec()
    
    # Define features with the example_proto (transformed data) and the feature_spec using tf.io.parse_single_example 
    features = tf.io.parse_single_example(example_proto, feature_spec)
    values = list(features.values())
    values[index_of_label], values[len(features) - 1] = values[len(features) - 1], values[index_of_label]
    
    # Stack the values along the first axis
    stacked_features = tf.stack(values, axis=0)

    return stacked_features
```

Next, this function will separate the features and target values into a tuple.


```python
def map_features_target(elements):
    features = elements[:HISTORY_SIZE]
    target = elements[-1:,-1]
    return (features, target)
```

Finally, you can define the dataset window with the function below. It uses the parameters defined above and also the helper functions to produce the batched feature-target mappings.


```python
def get_dataset(path):
        
    # Instantiate a tf.data.TFRecordDataset passing in the appropiate path
    dataset = tf.data.TFRecordDataset(path, compression_type='GZIP')
    
    # Use the dataset's map method to map the parse_function
    dataset = dataset.map(parse_function)
    
    # Use the window method with expected total size. Define stride and set drop_remainder to True
    dataset = dataset.window(HISTORY_SIZE + FUTURE_TARGET, shift=SHIFT, stride=OBSERVATIONS_PER_HOUR, drop_remainder=True)
    
    # Use the flat_map method passing in an anonymous function that given a window returns window.batch(HISTORY_SIZE + FUTURE_TARGET)
    dataset = dataset.flat_map(lambda window: window.batch(HISTORY_SIZE + FUTURE_TARGET))
    
    # Use the map method passing in the previously defined map_features_target function
    dataset = dataset.map(map_features_target) 
    
    # Use the batch method and pass in the appropiate batch size
    dataset = dataset.batch(BATCH_SIZE)

    return dataset
```

You can now use the `get_dataset()` function on your transformed examples to produce the dataset windows.


```python
# Get the URI of the transformed examples
working_dir = transform.outputs['transformed_examples'].get()[0].uri

# Get the filename of the compressed examples
train_tfrecord_files = os.listdir(working_dir + '/train')[0]

# Full path string to the training tfrecord files
path_to_train_tfrecord_files = os.path.join(working_dir, 'train', train_tfrecord_files)

# Get the window datasets by passing the full path to the get_dataset function
train_dataset = get_dataset(path_to_train_tfrecord_files)
```

Let's preview the resulting shapes of the data windows. If we print out the shapes of the tensors in a single batch, you'll notice that it indeed produced the required dimensions. It has 72 examples per batch where each contain 120 measurements for each of the 13 features in the transformed dataset. The target tensor shape only has one feature per example in the batch as expected (i.e. only `T (degC)`).


```python
for features, target in train_dataset.take(1):
    print(f'Shape of input features for a batch: {features.shape}')
    print(f'Shape of targets for a batch: {target.shape}')
```

    Shape of input features for a batch: (72, 120, 13, 1)
    Shape of targets for a batch: (72, 1, 1)


## Wrap Up

In this notebook, you got to see how you may want to prepare seasonal data. It shows how you can handle periodicity and produce batches of dataset windows. You will be doing something similar in the next lab with sensor data. This time though, the measurements are taken at a much higher rate (20 Hz). The labels are also categorical so you will be handling that differently.

On to the next!
